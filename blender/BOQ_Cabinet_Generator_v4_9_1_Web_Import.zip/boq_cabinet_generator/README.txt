v4.9.1 — Web app import + corner filler fix (based on v4.9.0)
BLENDER TARGET: 5.2.3. Blender GUI was not available in the build environment; test in Blender before fabrication.

- NEW: BOQ-Cabinet > 1. Cabinet Model > "Import Web App Project (.json)". Loads a project saved with
  "Export to Blender (.json)" in the BOQ web app: kitchen and wall layout, sizes, finishes, colours,
  drawer banks with each drawer's pull, sinks, backsplash, smart-corner settings and shared THB prices.
  Web-only items (tall units, dishwasher openings) are listed in the system console and not modelled.
  The web app's blind-corner rule and corner countertop infill are not part of the add-on yet, so the
  add-on BOQ can be higher for L/U layouts.
- FIX (corner_safety.py): the collision proxy for the corner filler was placed one board thickness on
  the room side of the real filler panel. Drawers in the column next to an L/U corner were reported as
  blocked and the auto filler grew to its 425 mm cap, leaving a gap at the corner. The proxy now matches
  the panel built by make_layout().
- Colour ids in the web app now match this add-on (OAK, ASH, WALNUT, WHITE, GREY, SAGE, BLUE, CHARCOAL);
  older web exports using NAVY/BLACK are mapped to BLUE/CHARCOAL.

v4.9.0 — Smart Corner & Drawer Collision Prevention (based on v4.8.4)
BLENDER TARGET: 5.2.3. The Blender GUI/runtime is not available in the build environment; test in Blender before fabrication.

NEW (optional; OFF by default to preserve prior projects):
- For L and U layouts enable "Smart Corner Collision Prevention" in Kitchen Cabinet or Wall Cabinet.
- "Auto Size Corner Filler" reserves a finish-matched face filler at each return. The auto width targets the FULL design travel of installed drawer slides; it DOES NOT resize while you animate the pull sliders.
- Manual Left/Right Filler controls are offered when Auto Size is disabled. The width is capped to keep a minimum return depth/width. With very tight returns you may need to reduce door/frame counts.
- In Smart mode the return runs are SHORTENED by the filler width; changing to Smart mode therefore changes the 3D cabinet/door/BOQ quantities. The same filler appears as a 3D object and a separately named CARCASS panel item in that return run's BOQ.
- The maximum safe travel of each drawer bank (mm) is calculated from an approximate swept 2D envelope of the box, front and handle against the perpendicular cabinet carcass and filler.
- Individual unsafe pull sliders are limited ONLY IN GENERATED GEOMETRY; the user's requested input is left intact, with a warning and effective safe distance shown. When the original value is edited again, geometry updates live.
- Swing doors are tested by leaf (including protruding handles) at 5-degree intervals. Only interfering leaves are restricted; unblocked leaves still swing. Secondary return doors also check the approved main-run swinging envelope. Wall cabinet swing angles are independent of kitchen cabinet swing angles.
- "Validate Model" lists filler sizes and any clamped drawer/door movement. The 3D sidebar also shows per-bank maximum pull.
- Material & Cost Library, project overrides, THB/SGD/USD, CSV and formula-based Editable Excel BOQ remain from v4.8.4.

ENGINEERING/BUILDABILITY LIMITATION:
The prevention uses conservative axis-aligned 2D swept boxes. It is not exact swept-mesh intersection, mechanical hinge/slide engineering, or an automatic cabinet redesign. It does not select certified soft-close hardware, test installation tolerances, or guarantee physical interference-free fabrication. Check corner clearances, handles, countertop/appliance paths, and hardware manufacturer requirements in the final shop drawings. If a door is blocked even with a large filler, move its hinge/column or revise the corner module.

UPGRADE:
Disable old BOQ Cabinet Generator v4.8.4, install ZIP through Blender > Preferences > Get Extensions > Install from Disk, then enable extension. Existing projects retain their geometries until Smart Corner is enabled. Refresh Model after modifying settings. Do not install two same-ID versions simultaneously.

v4.8.4 — L/U drawer selection & corner clearance diagnostics

- Apply independent pull-out drawer banks to MAIN, LEFT RETURN or RIGHT RETURN
  (L: one return; U: both returns).
- New dedicated Add button for each available run, plus existing Auto add.
- Each bank keeps its own drawer quantity and six independent pull positions;
  swing doors remain independently operable in unaffected columns.
- Return runs inherit their own auto/custom door-column counts, and drawer
  placements use each run's rotated 3D coordinate system.
- Drawer hardware & panel quantities continue to appear in CSV and editable
  Excel BOQ, grouped by the existing run names and currency totals.
- Corner warning in drawer UI and Validate Model when an opened drawer box
  overlaps another run's plan footprint. This is a conservative guide;
  confirm collision clearances visually before fabrication.
- v4.8.3 price library and Excel currency/total reconciliation retained.
- Tested with code-level validation; Blender 5.2.3 GUI testing not available
  in this environment.

v4.8.3 — Blender-matching Excel totals & currency
- Export Editable Excel BOQ now uses the current Kitchen/Wall price library/overrides and currency selection.
- Settings has THB, SGD, USD dropdown and independent editable THB-per-SGD / THB-per-USD rates.
- Selected currency exchange rate updates automatically when the currency is switched inside Excel.
- Summary highlights Kitchen, Wall and Combined totals in the selected currency with a Blender export-time snapshot.
- BOQ retains THB editable unit rates, plus selected-currency per-line rates and amounts.
- Per-run cost formulas preserve the model calculation structure for L/U returns and backsplash.
- Quantities retain full precision in formulas instead of rounding before multiplying prices.
- Four sheets: BOQ, Summary, Settings, Run Costs. Excel formulas recalculate upon user edits.
- Previously saved models, doors, multi-drawers, materials, layouts and CSV exports are untouched.
- Blender 5.2.3 intended; full GUI test still recommended.

v4.8.2 - Real Drawer + Swing Door Row/Divider Fix (Blender 5.2.3 target)

- Fixed Door Rows and Horizontal Dividers resetting to 1 and 0 when Real Pull-Out Drawers is enabled.
- Door Rows set the number of stacked swing-door leaves in non-drawer columns only.
- Horizontal Dividers form shelves only in non-drawer columns; drawer cavities stay clear.
- Every drawer column replaces all swing doors, hinges and handles for that column in the BOQ.
- Nose-gap rails are segmented around drawer bays when using mixed doors and drawers.
- Preserved independent drawer pull, layouts, materials, pricing library, BOQ and Excel/CSV exports.
- Fixed row/divider behavior is optional by drawer presence and does not change cabinets with drawers disabled.

v4.8.1 — Material & Cost Library UI Fix
- Fixed v4.8.0 UI regression: all rate editors were accidentally inside the Project Price Override condition and were hidden when no override was active.
- Expanding 2. Material & Cost Library now always shows currency settings, all four material/cost sections, price-library import/export, and project overrides.
- UI categories: Board / Laminate Prices, Countertop / Glass Prices, Hinges / Drawer Slides / Handles, Labour / Installation / Waste.
- Prices stay stored in THB and BOQ recalculates immediately without changing cabinet geometry; project overrides still work.
- Retains v4.7 drawer features, v4.8 separated price catalog and previous editable Excel/CSV export.

v4.8.0 - Separated Model & Material Price Library (based directly on v4.7.0):
- The Model sections now contain only cabinet and component geometry/material selections, sink layouts, and door/drawer controls. All editable THB costs, FX, and waste allowance live under the central Material & Cost Library section.
- Kitchen and Wall use ONE shared scene-level Price Library by default. Each property name is a stable price ID. Changing a rate or currency immediately updates BOQ totals (without re-creating cabinet meshes).
- Optional project-specific Kitchen/Wall overrides are editable in the Price Library. Opening a previous .blend migrates its v4.7 Kitchen rates into the library and preserves a differently priced Wall using an enabled Wall override. Use "Use Shared Prices for Both" to unify.
- Price Library Export/Import JSON reuses the shared rates in new projects. Validated import requires all known rate IDs; import does not overwrite optional project overrides.
- Generated cabinets keep a THB price snapshot in collection custom properties. Export CSV and formula-based Editable Excel BOQ keep their formats and calculate using the currently selected library or explicit overrides. Excel is not a live connection back to Blender.
- Legacy price fields remain hidden in the cabinet property definitions for loading old .blend files; they are not used as the source of new calculations.
- Pricing changes redraw BOQ totals without rebuilding 3D geometry. New generated models and Load Selected continue to support drawer bank animation controls, Straight/L/U, Shaker, sinks and validation.
- All default unit rates and FX are illustrative, not supplier quotes. Check fabrication prices before issuing a quote.

v4.7.0 - Independent Real Drawers, Reliable Live Opening, Simplified Hardware:
- One drawer mode only: enabling Real Pull-Out Drawers creates a bank, and more banks may be added. The old single/multiple toggle is gone.
- Independent distance input for every drawer in every bank; other cabinet doors retain their separate swing control.
- Drawer travel clamps to the selected drawer-box depth: max(0, min(900, depth-35mm, 95% depth)). For 400mm depth this is 365mm. Invalid 900mm entries no longer stop the live-preview refresh.
- Only manual pull handles + two-part slide runners are offered. Push-to-Open and Slides Only are removed from the visible UI and from new 3D/BOQ generation.
- Prior saved v4.5/v4.6 cabinet data, including the single-bank controls, is migrated on loading. Legacy enum values are accepted but generate the new standard handles/slides.
- Drawer fronts, box panels and moving runners use the individual pull value. Fixed guides remain in the carcass. BOQ counts slides/handles by drawer; CSV and formula-driven Excel are unchanged.
- NOTE: Drawers are visualization and BOQ geometry, not a mechanical animation or hardware engineering validation. Verify actual slide stroke and load ratings before fabrication.

v4.6.0 - Multi-bank drawers and simultaneous swinging doors:
- Fix: invalid Drawer Column (e.g. 3 when there are only 2 door bays) now auto-clamps when updating/rebuilding preview, and drawer dividers align in drawer mode.
- Switch on Enable Real Drawer Bank + Multiple Drawer Banks / Independent Pull.
- Add Drawer Bank as many times as needed. For each bank choose MAIN/LEFT/RIGHT run, door column, number of drawers and opening hardware (Pull Handle, Push-to-Open or Slides Only).
- Adjust individual Drawer 1..6 Pull sliders. Independent drawer fronts/boxes/moving runner pieces slide; fixed runners stay attached to the carcass. Remaining door bays still follow Door Opening Angle simultaneously.
- New bank rows use the existing box depth, clearances, materials and global hardware unit rates.
- Mixed door/drawer BOQ: removed doors/hinges/handles per replaced column, added drawer fronts/box panels/bottoms/slide pairs/optional push latches or handles. CSV + editable Excel export preserved.
- Legacy single-bank workflow remains available (multiple-bank switch OFF) to preserve prior projects.
- The sliders show 3D positions, not Blender physics or automatic mechanical motion. Verify real hardware clearances before fabrication.

v4.5.0 (based on v4.4.0): Optional real pull-out drawer bank and hardware.
- Kitchen base cabinet: one selected front column per chosen run (MAIN / LEFT / RIGHT).
- Adjustable 1-6 drawer fronts, box thickness/bottom, depth, slide clearances, extension, and opening hardware (handle / push-to-open / none).
- Stationary runner and moving slide modeled separately. Slider moves box, fronts, handles and moving rail.
- Drawer bank requires one door row, no horizontal dividers, and one vertical divider between each pair of door columns.
- Costs of front, 4 box walls, bottom, full-extension slides, handles/push sets appear as editable BOQ/Excel rows.
- Drawer pull travel is visual/parametric, not a realtime collision simulator. Only one drawer column per run in this version.
- Prices are illustrative only. Verify hardware clearances and manufacturer's requirements before fabrication.

v4.4.0: Added editable formula-driven .xlsx BOQ with kitchen/wall summaries, automatic quantities, edge banding, waste and THB/SGD/USD conversions; original CSV remains available.
v4.3.0 — Model Validation (separate branch from v3.9.3)
Use BOQ-Cabinet > 6. Live 3D Model > Validate Model. This non-destructive diagnostic reports errors, warnings, and layout notes for kitchen and wall cabinet runs, including door/divider mismatch, door widths, sink/partition clearance, backsplash and BOQ sanity, and kitchen/wall vertical clearance. Does not replace fabrication review.

v3.9.3 — Screenshot-matched startup defaults (November 12, 2026):
- Kitchen and wall: LEFT L-shape, 1800 mm main width, 4 door columns, 3 vertical dividers, flat doors, wood laminate Warm White, Natural Oak carcass, 18 mm carcass, 6 mm back, 12 mm back inset, 3 mm door gap, 2 hinges per door.
- Kitchen: left return total 1500 mm, 600 mm depth, 900 mm height, 50 mm plinth (60 mm setback); no sink; quartz countertop and sage backsplash retained.
- Wall: left return total 1800 mm, 350 mm depth, 720 mm height, bottom 1450 mm above FFL; 25 mm nose gap enabled.
- Same presets load from Load Default L Kitchen. Newly initialized scenes only: previously configured scene data stays intact until explicitly reset.
- The existing features and BOQ currency remain unchanged.

v3.9.2 — Default L-shaped Kitchen + Wall model (based on user reference screenshot):
- On a NEW scene, the live preview starts with matching L layouts (right return), 2400 mm main runs and 1800 mm total returns, blue flat-panel doors and carcasses, 4 door columns/3 internal dividers along main runs.
- Base: depth 600 mm, overall height 900 mm, recessed plinth 100 mm, light gray quartz countertop 20 mm, sage backsplash covering the 530 mm gap up to the wall cabinet, no sink and no handles.
- Wall: depth 350 mm, height 720 mm, cabinet bottom 1450 mm above floor, backs aligned to the kitchen rear wall plane, no handles.
- A new 'Load Default L Kitchen' button above the Kitchen Cabinet section reapplies this model to an existing scene on demand. It does not delete previously generated objects. Currency, material prices, FX rates, and existing saved configurations are never reset automatically.
- Straight and U shapes, all Shaker door styles, sinks, BOQ and export features stay available.
- To see the new starter in an old project, click Load Default L Kitchen. In a new .blend it is the startup preview.

v3.9.1 — L/U Door Column and Vertical Divider Alignment Fix:
- The automatic return-run door count is proportional to the main leaf width, not to 250mm increments. Example: main 2400mm / 3 doors, return 850mm => 1 door / 0 dividers (previously 3 doors / 1 divider).
- New "Match Dividers to Door Columns" switch (default ON for L/U only). Each run with N doors generates N-1 internal vertical dividers on the MAIN and manually configured LEFT/RIGHT return runs; the BOQ and 3D geometry use exactly the same calculated settings.
- Switch OFF to retain independently editable door-column and vertical-divider settings for the main and customized return runs. Automatic return runs always use matched counts. Open-front cabinet settings are not overridden.
- UI displays the effective automatic door/divider quantities and hides unused vertical-divider inputs while matching is enabled. Existing Straight layouts are unchanged.
- Other models, doors, glass, sink models, currency settings, back panels and backsplash code are unchanged. Please refresh the live preview or regenerate older cabinet geometry after installing. Requires Blender viewport testing.

v3.9.0 — 1 or 2 separately positioned sink models (based on v3.8.0):
- Kitchen Countertop > Sink / Countertop Cutout > Sink Models: 1 Sink or 2 Sinks. Existing single-sink projects default to 1 automatically.
- Sink 1 and Sink 2 each have independent cutout width/depth, basin depth, run (Main / Left / Right), offset along the run, and setback from the countertop front edge.
- One actual countertop through-cutout plus one cabinet top-panel cutout per sink, including when both sinks are on the SAME main/return run. Two openings in one slab form one shared-vertex watertight mesh; no destructive Blender Boolean modifier is required.
- 3D models: one separate stainless-steel bowl and rim for each sink. Sink 2 may be on the same run or a different run in L/U layouts. This is two independently installed basins, not a manufacturer-specific double-bowl fixture.
- BOQ: one sink supply, one opening fabrication charge and one installation charge PER sink. Gross slab area remains the default; Net method optionally deducts the sum of both openings. Existing per-sink THB rates and SGD/USD conversion still apply.
- Clear warnings if two sink openings overlap, are less than 35mm apart, are too near the countertop/carcass edges, or if an unavailable L/U return is chosen. Large models may need longer run dimensions to fit two sinks.
- No changes to cabinet door options, wall positioning, corner backsplash or default straight cabinet geometry. Blender viewport verification is recommended.

v3.8.0 — L/U Continuous Backsplash + Independent Return Frames + Sink/BOQ:
- L and U layout backsplashes are built as continuous rear-wall and side-wall panels with non-overlapping butt joints. This fills the previously missing return-corner section; the BOQ measures each segment once. Straight layouts are unchanged.
- Kitchen and Wall each have Custom Return Run Details (off by default). When enabled, left and right returns have independent door columns (frame/leaf counts), door rows, vertical and horizontal cabinet divisions, door styles, and optional Shaker frame widths. Default off preserves v3.7 automatic sizing for saved models.
- Add one adjustable sink on Main/Left/Right cabinet countertop run. Cutout Width, Depth, Run Offset, Front Setback and Bowl Depth are editable. Countertop and carcass top-panel meshes have actual through-holes. Stainless sink basin/rim is a schematic 3D model, not a manufacturer-specific appliance or plumbing design.
- Countertop BOQ pricing basis: Gross Slab (default) charges full purchased/blank area, since a sink cutout generally creates unusable offcut; Net Area is optional and records a NEGATIVE area deduction for measured-on-site billing only. In both modes, sink supply, countertop cutout/fabrication and sink installation are separate editable THB unit rates. Existing THB/SGD/USD conversion applies automatically.
- Sink dimensions and position must leave at least 35mm countertop border and appropriate cabinet top-panel clearance. Sink controls are kitchen-only; wall cabinets do not include sinks.
- All rates are illustrative and editable, not supplier quotations; sink installation excludes plumbing unless included in custom rates.
- L/U countertops are still individual straight-run slabs with visible butt joints (existing behavior); sink opening is cut into the chosen run only.
- Models are not automatically saved to the .blend; Refresh Model to rebuild live preview and regenerate old completed cabinets.
- Python syntax, geometry arithmetic and ZIP contents are checked, but Blender GUI viewport rendering is not available in this environment.

v3.7.0 — Flat Panel + Classic Shaker Door Styles (based on v3.6.0):
- New independent Door Panel Style selectors under Kitchen and Wall sections: Modern Flat Panel (legacy geometry), Shaker Recessed Panel, Shaker Glass Panel, Shaker Double Panel.
- Shaker door construction uses independent 3D frame stiles and rails plus physically inset center panel(s); Glass Panel has visible transparent glass in Material Preview/Rendered view. Adjustable frame width, panel recess depth and glass thickness.
- All Shaker door pieces and their handles rotate together around the original hinge axis; hinges remain in place. Works with independently set Kitchen and Wall door opening angles, Straight/L/U modular layouts, live preview and generated cabinets.
- BOQ automatically distinguishes stile, rail, recessed panel and glass components, retains cutting dimensions and piece counts, and applies editable Glass THB/m² rate with THB / SGD / USD conversion. Existing flat-door BOQ remains unchanged.
- Existing .blend settings without Door Panel Style default to Flat. Cabinet carcass, countertop, back-panel matching, and installation geometry retained.
- Use Refresh Model or regenerate existing cabinets after install. 3D glass transparency is best assessed in Material Preview/Rendered mode.
- Flat Panel is the default for backward compatibility.

v3.6.0 — New features based on v3.5.4:
- Separate Plan Layout selectors for kitchen and wall units: Straight (default), L (left or right return) and U (both returns).
- Main Width is the straight back-wall run. Return Total lengths are measured from the rear wall plane and include the cabinet depth. Returns begin beyond the main front, so the cabinet carcasses do not overlap. Doors of return runs face the center.
- All modules generate as editable mesh collections and all runs are included in the detailed BOQ and CSV export.
- BOQ Currency: THB / SGD / USD. THB remains the editable base rate for ALL existing price fields. Choose a manual rate (THB per 1 SGD/USD) for display and export conversion. DEFAULTS 25 THB/SGD and 33 THB/USD ARE ILLUSTRATIVE, NOT LIVE FX QUOTES.
- Export CSV includes currency, conversion rate, converted unit rates and totals, plus original THB values for audit.
- Independent kitchen/wall opening, rear-wall alignment and matching back panel finish preserved.
- Straight mode has the original geometry unchanged. L/U are modular straight cabinet runs meeting at right angles (separate countertops may have visible seams; no custom diagonal/curved corner cabinet).
- Tested for Python syntax and layout BOQ arithmetic. Full Blender GUI visual validation is recommended.

v3.5.4: Back panels use the exact same Blender laminate material (finish and tone) as the side/carcass panels in all kitchen and wall cabinet configurations, including open-front options. Preserve independent backboard thickness and backboard BOQ rate; annotate matching finish in BOQ. No geometry or door-function changes.
v3.5.3: Fix Live Preview moving both kitchen and wall cabinets together. Use separate preview collections so only the wall unit aligns to the rear wall. Preserve the wall position when updating existing generated cabinets. Also ensures independently opened wall doors are found when Blender appends numeric name suffixes. Other features unchanged.
v3.5.2: Wall cabinet rear is aligned to the wall plane behind the backsplash, in both live preview and starter pair. All other features retained.
v3.5.1: Fix door swing hinge pivot so opened doors stay tight to the cabinet front with no unwanted gap.
v3.5: Kitchen and Wall door opening angles are independent (stored in scene.igz_cabinet and scene.igz_wall). Correct outward hinge-axis swing, exact object matching, automatic live preview. Refresh Model to rebuild.\n