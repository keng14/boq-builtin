"""Import a project exported by the BOQ ตู้บิวท์อิน web app (format boq-cabinet-web).

Pure Python (no Blender API) so it can be tested outside Blender. The operator
in __init__.py applies the returned plan to scene.igz_cabinet / igz_wall and the
shared price library.
"""

FORMAT = 'boq-cabinet-web'

# Cabinet properties that exist in IGZCabinetSettings and mean the same thing
# in the web app. UI-only and legacy price fields are left out on purpose.
CABINET_KEYS = (
    'front_style', 'cabinet_type', 'installation_height', 'base_type', 'layout_shape', 'l_corner_side',
    'return_left_length', 'return_right_length', 'layout_align_dividers', 'corner_smart_enabled',
    'corner_auto_filler', 'corner_min_filler_mm', 'corner_max_filler_mm', 'corner_manual_left_mm',
    'corner_manual_right_mm', 'customize_return_runs', 'return_left_door_columns', 'return_right_door_columns',
    'return_left_door_rows', 'return_right_door_rows', 'return_left_vertical_divisions',
    'return_right_vertical_divisions', 'return_left_horizontal_divisions', 'return_right_horizontal_divisions',
    'return_left_door_style', 'return_right_door_style', 'return_left_frame_width', 'return_right_frame_width',
    'width', 'depth', 'height', 'carcass_thickness', 'back_thickness', 'vertical_divisions',
    'horizontal_divisions', 'door_columns', 'door_rows', 'door_gap', 'show_handles', 'use_nose_gap',
    'nose_gap_height', 'back_inset', 'plinth_height', 'plinth_setback', 'carcass_finish', 'carcass_tone',
    'door_finish', 'door_tone', 'door_style', 'shaker_frame_width', 'shaker_recess_depth',
    'shaker_glass_thickness', 'include_backsplash', 'backsplash_height', 'backsplash_thickness',
    'include_countertop', 'include_sink', 'sink_quantity', 'sink_run', 'sink_width', 'sink_depth',
    'sink_bowl_depth', 'sink_x_offset', 'sink_front_setback', 'sink2_run', 'sink2_width', 'sink2_depth',
    'sink2_bowl_depth', 'sink2_x_offset', 'sink2_front_setback', 'countertop_cost_basis',
    'countertop_material', 'countertop_thickness', 'countertop_front_overhang', 'countertop_side_overhang',
    'wall_back_offset', 'drawer_box_thickness', 'drawer_bottom_thickness', 'drawer_slide_clearance',
    'drawer_depth', 'door_open_angle', 'hinges_per_door')

RATE_KEYS = (
    'wood_laminate_rate', 'color_laminate_rate', 'carcass_rate', 'back_rate', 'door_rate', 'shaker_glass_rate',
    'backsplash_rate', 'countertop_composite_rate', 'countertop_quartz_rate', 'countertop_terrazzo_rate',
    'countertop_granite_rate', 'hinge_rate', 'handle_rate', 'drawer_slide_rate', 'drawer_handle_rate',
    'drawer_push_rate', 'nose_gap_rate', 'shelf_support_rate', 'mount_bracket_rate', 'mount_rail_rate',
    'edge_rate', 'plinth_rate', 'kickstand_rate', 'sink_unit_rate', 'sink_cutout_rate', 'sink_install_rate',
    'labor_rate', 'waste_percent')

TONES = {'OAK', 'ASH', 'WALNUT', 'WHITE', 'GREY', 'SAGE', 'BLUE', 'CHARCOAL'}
TONE_FIX = {'NAVY': 'BLUE', 'BLACK': 'CHARCOAL'}
WEB_ONLY = {
    'talls': 'tall units (fridge / oven / storage towers)',
    'appliances': 'dishwasher openings',
}


def _cabinet(src, skipped, label):
    out = {}
    for key in CABINET_KEYS:
        if key not in src:
            continue
        val = src[key]
        if key in ('carcass_tone', 'door_tone'):
            val = TONE_FIX.get(val, val)
            if val not in TONES:
                skipped.append(f'{label}.{key}={val} (unknown colour)')
                continue
        if key == 'sink_quantity':
            val = str(int(val or 1))
        out[key] = val
    return out


def plan_web_import(payload):
    """Return {'base','wall','banks','rates','skipped','notes'} or raise ValueError."""
    if not isinstance(payload, dict) or payload.get('format') != FORMAT:
        raise ValueError('Not a BOQ web export (expected format "boq-cabinet-web")')
    if int(payload.get('version', 0)) != 1:
        raise ValueError('Unsupported web export version %r' % payload.get('version'))
    base_src = payload.get('base') or {}
    skipped, notes = [], []
    base = _cabinet(base_src, skipped, 'base')
    base.update(cabinet_type='BASE', enabled=True)
    banks = []
    for b in base_src.get('drawer_banks') or []:
        run = b.get('run', 'MAIN')
        if run not in ('MAIN', 'LEFT', 'RIGHT'):
            skipped.append(f'drawer bank on run {run}')
            continue
        pulls = [float(v) for v in (b.get('pulls') or [])][:6] + [0.0] * 6
        banks.append(dict(run=run, column=int(b.get('column', 1)), count=max(1, min(6, int(b.get('count', 3)))),
                          pulls=pulls[:6]))
    base['enable_drawers'] = bool(banks)
    base['drawer_multi_bank_mode'] = True
    rates = {k: float(base_src[k]) for k in RATE_KEYS if k in base_src}
    for key, what in WEB_ONLY.items():
        if base_src.get(key):
            skipped.append(f'{what}: not modelled by the add-on')
    if base_src.get('layout_shape') in ('L', 'U'):
        notes.append('Blind-corner doors and the corner countertop infill are web-app rules; '
                     'the add-on still prices a door in the hidden corner bay.')
    wall_src = payload.get('wall')
    wall = None
    if wall_src:
        wall = _cabinet(wall_src, skipped, 'wall')
        wall.update(cabinet_type='WALL', base_type='NONE', enabled=True, enable_drawers=False,
                    include_countertop=False, include_sink=False)
    return dict(base=base, wall=wall, banks=banks, rates=rates, skipped=skipped, notes=notes)


def as_settings(plan_part, banks=None):
    """Flatten a plan section into the dict shape calculate()/calculate_layout() use."""
    d = dict(plan_part)
    d['drawer_banks'] = [dict(run=b['run'], column=b['column'], count=b['count'], hardware='HANDLE',
                              pulls=list(b['pulls'])) for b in (banks or [])]
    return d
