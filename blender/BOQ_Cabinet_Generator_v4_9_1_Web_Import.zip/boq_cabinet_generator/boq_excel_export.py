"""Formula-driven Excel BOQ export (stdlib OOXML; no Blender-side Excel deps).

v4.8.3: Mirrors Blender's active price library, source-currency conversion and
per-run edge/waste rounding. The FX selector updates formulas automatically.
The workbook remains editable and recalculates when quantities/rates change.
"""
from xml.sax.saxutils import escape
from zipfile import ZipFile, ZIP_DEFLATED
from datetime import datetime, timezone
import math

PANEL_CATEGORIES = ('CARCASS','BACK','DOOR','GLASS','BACKSPLASH','COUNTERTOP',
                    'DRAWER_FRONT','DRAWER_BOX','DRAWER_BOTTOM')
HEADERS = ('Cabinet','Category','Description','Length mm','Width mm','Thickness mm',
           'Pieces','Unit','Quantity','Edge sides','Edge m','Unit Rate (THB)',
           'Amount (THB)','Amount (selected)','Notes','Run','Unit Rate (selected)')


def _s(value):
    return escape(str(value), {'"':'&quot;', "'":'&apos;'})


def _cell(addr, val, style=0, formula=False, cached=None):
    st = f' s="{style}"' if style else ''
    if formula:
        cached_xml=''
        typ=''
        if cached is not None:
            if isinstance(cached, str):
                typ=' t="str"'
                cached_xml=f'<v>{_s(cached)}</v>'
            elif isinstance(cached, (int,float)) and math.isfinite(float(cached)):
                cached_xml=f'<v>{cached}</v>'
        return f'<c r="{addr}"{st}{typ}><f>{_s(str(val).lstrip("="))}</f>{cached_xml}</c>'
    if val is None:
        return ''
    if isinstance(val,(int,float)) and not isinstance(val,bool):
        if not math.isfinite(float(val)):
            raise ValueError('Non-finite BOQ value in cell '+addr)
        return f'<c r="{addr}"{st}><v>{val}</v></c>'
    return f'<c r="{addr}" t="inlineStr"{st}><is><t xml:space="preserve">{_s(val)}</t></is></c>'


def _row(index, values, styles=None, formulas=None, caches=None):
    styles, formulas, caches = styles or {}, formulas or set(), caches or {}
    return '<row r="%d">%s</row>' % (index, ''.join(
        _cell(f'{column}{index}',value,styles.get(column,0),
              column in formulas,caches.get(column)) for column,value in values.items()))


def _worksheet(rows,widths,freeze=0,autofilter=None,validation=None):
    cols=''.join(f'<col min="{i}" max="{i}" width="{width}" customWidth="1"/>'
                 for i,width in enumerate(widths,1))
    pane=(f'<sheetViews><sheetView workbookViewId="0"><pane ySplit="{freeze}" '
          f'topLeftCell="A{freeze+1}" activePane="bottomLeft" state="frozen"/>'
          '</sheetView></sheetViews>' if freeze else
          '<sheetViews><sheetView workbookViewId="0"/></sheetViews>')
    flt=f'<autoFilter ref="{autofilter}"/>' if autofilter else ''
    check=(f'<dataValidations count="1"><dataValidation type="list" allowBlank="0" '
           f'showErrorMessage="1" errorTitle="Invalid currency" error="Choose THB, SGD or USD" '
           f'sqref="{validation}"><formula1>"THB,SGD,USD"</formula1></dataValidation></dataValidations>'
           if validation else '')
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            +pane+'<cols>'+cols+'</cols><sheetData>'+''.join(rows)+'</sheetData>'
            +flt+check+'</worksheet>')


def _run_for_part(part):
    # v4.8.2 layout labels every L/U sub-run with "Main | " or
    # "Return Left | ". The extra continuous backsplash uses different names.
    label=str(part.get('name','')).split(' | ',1)[0].strip().upper()
    if label == 'MAIN':
        return 'MAIN'
    if label in ('RETURN LEFT','RETURN RIGHT'):
        return label.replace(' ','_')
    if label in ('MAIN REAR WALL','LEFT SIDE WALL','RIGHT SIDE WALL'):
        return 'BACKSPLASH_'+label.replace(' ','_')
    return 'MAIN'


def _raw_quantity(part):
    unit=part['unit']
    if unit=='m2':
        sign=-1 if float(part['quantity'])<0 else 1
        return sign*float(part['length_mm'])*float(part['width_mm'])*float(part['pieces'])/1e6
    if unit=='m':
        return float(part['length_mm'])*float(part['pieces'])/1000
    return float(part['pieces'])


def _edge_formula(index, sides):
    present=(sides or '').split(',')
    nl=sum(e in present for e in ('L1','L2'))
    nw=sum(e in present for e in ('W1','W2'))
    return f'=ROUND((D{index}*{nl}+E{index}*{nw})*G{index}/1000,4)'


def export_boq_xlsx(path, rows, kitchen_settings, wall_settings,
                    currency, thb_per_unit, blender_totals=None,
                    fx_thb_per_sgd=None, fx_thb_per_usd=None):
    """rows: (KITCHEN|WALL, calculate_layout part).

    blender_totals: optional dict with source totals in THB, used as a labelled
    export-time snapshot, not as a substitute for live Excel formulas.
    FX: both manual library rates passed separately so changing Settings B2
    recalculates rate + ALL totals automatically.
    """
    rows=list(rows)
    if len(rows)>15000:
        raise ValueError('BOQ exceeds 15000 entries; export in smaller groups')
    if currency not in ('THB','SGD','USD') or thb_per_unit<=0:
        raise ValueError('Invalid currency or exchange rate')
    fx_sgd=float(fx_thb_per_sgd if fx_thb_per_sgd is not None else
                 thb_per_unit if currency=='SGD' else 25.0)
    fx_usd=float(fx_thb_per_usd if fx_thb_per_usd is not None else
                 thb_per_unit if currency=='USD' else 33.0)
    if not all(math.isfinite(x) and x>0 for x in (fx_sgd,fx_usd,thb_per_unit)):
        raise ValueError('FX values must be positive and finite')
    if abs(({'THB':1.0,'SGD':fx_sgd,'USD':fx_usd}[currency])-float(thb_per_unit))>1e-6:
        raise ValueError('The selected exchange rate must match Blender Price Library')
    blender_totals=blender_totals or {}
    # SETTINGS: independent FX inputs and automatic rate selector prevent
    # B2 currency/rate mismatch when the user changes currency in Excel.
    settings=[
        _row(1,{'A':'BOQ SETTINGS — BLUE CELLS ARE EDITABLE'},{'A':1}),
        _row(2,{'A':'BOQ Currency','B':currency},{'A':2,'B':4}),
        _row(3,{'A':'THB per 1 SGD','B':fx_sgd},{'A':2,'B':4}),
        _row(4,{'A':'THB per 1 USD','B':fx_usd},{'A':2,'B':4}),
        _row(5,{'A':'THB per selected currency','B':'=IF(B2="SGD",B3,IF(B2="USD",B4,1))'},
             {'A':2,'B':3},{'B'},{'B':thb_per_unit}),
        _row(6,{'A':'Kitchen edge rate (THB/m)','B':kitchen_settings['edge_rate']},{'A':2,'B':4}),
        _row(7,{'A':'Kitchen waste (%)','B':kitchen_settings['waste_percent']},{'A':2,'B':4}),
        _row(8,{'A':'Wall edge rate (THB/m)','B':wall_settings['edge_rate']},{'A':2,'B':4}),
        _row(9,{'A':'Wall waste (%)','B':wall_settings['waste_percent']},{'A':2,'B':4}),
        _row(11,{'A':'Source','B':'Rates and selected currency exported from Blender Material & Cost Library'}),
        _row(12,{'A':'Change currency','B':'Select THB, SGD or USD in B2. The conversion rate in B5 changes automatically.'}),
        _row(13,{'A':'Update costs','B':'Edit the blue numeric BOQ inputs and THB unit rates; Summary formulas recalculate.'}),
        _row(14,{'A':'Rounding','B':'Quantities keep full precision for costs; visible quantities use 4 decimals. Edge and waste round per run.'}),
        _row(15,{'A':'BOQ vs Blender','B':'Totals match the Blender calculation at export. Subsequent Excel edits do not modify the 3D model.'}),
        _row(16,{'A':'FX basis','B':'1 selected currency unit = B5 THB; rates are manually maintained, not live market FX.'})]
    detail=[_row(1,{chr(65+i):v for i,v in enumerate(HEADERS)},
                 {chr(65+i):1 for i in range(len(HEADERS))} | {'N':1,'Q':1})]
    # Dynamic selected-currency header; snapshot in Excel is explicit.
    detail[0]=_row(1,{**{chr(65+i):v for i,v in enumerate(HEADERS)},
                      'N':'="Amount ("&Settings!B2&")"',
                      'Q':'="Unit Rate ("&Settings!B2&")"'},
                  {chr(65+i):1 for i in range(len(HEADERS))},{'N','Q'},
                  {'N':f'Amount ({currency})','Q':f'Unit Rate ({currency})'})
    run_groups={}
    for index,(cabinet,part) in enumerate(rows,2):
        if cabinet not in ('KITCHEN','WALL'):
            raise ValueError('Unexpected BOQ cabinet id: '+str(cabinet))
        label=_run_for_part(part)
        grp=(cabinet,label)
        run_groups.setdefault(grp,[]).append((index,part))
        unit=part['unit']
        if unit=='m2':
            sign='-' if float(part['quantity'])<0 else ''
            qty_formula=f'={sign}D{index}*E{index}*G{index}/1000000'
        elif unit=='m':
            qty_formula=f'=D{index}*G{index}/1000'
        else:
            qty_formula=f'=G{index}'
        edge_formula=_edge_formula(index,part.get('edge_sides',''))
        values={'A':cabinet,'B':part['category'],'C':part['name'],
                'D':part['length_mm'],'E':part['width_mm'],'F':part['thickness_mm'],
                'G':part['pieces'],'H':unit,'I':qty_formula,
                'J':part.get('edge_sides','') or '',
                'K':edge_formula,'L':part['unit_rate'],
                'M':f'=ROUND(I{index}*L{index},2)',
                'N':f'=IFERROR(ROUND(M{index}/Settings!$B$5,2),0)',
                'O':'Blue numeric cells: size, pieces, THB rate. Formulas recalculate.',
                'P':label,'Q':f'=IFERROR(ROUND(L{index}/Settings!$B$5,4),0)'}
        style={k:4 for k in ('D','E','F','G','L')}
        style.update({k:3 for k in ('I','K','M','N','Q')})
        detail.append(_row(index,values,style,{'I','K','M','N','Q'},
                           {'I':_raw_quantity(part),'K':part['edge_m'],
                            'M':part['material_cost'],
                            'N':round(part['material_cost']/thb_per_unit,2),
                            'Q':round(part['unit_rate']/thb_per_unit,4)}))
    last=max(2,len(rows)+1)
    maxref=max(15001,last)
    cabs=f'BOQ!$A$2:$A${maxref}'
    cats=f'BOQ!$B$2:$B${maxref}'
    runs=f'BOQ!$P$2:$P${maxref}'
    amounts=f'BOQ!$M$2:$M${maxref}'
    edges=f'BOQ!$K$2:$K${maxref}'
    # RUN COSTS: each layout module mirrors Blender's own per-module rounding.
    # Continuous backsplash wall segments count separately for L/U.
    run_rows=[_row(1,{'A':'Cabinet','B':'Run','C':'Supply (THB)',
                      'D':'Panel cost (THB)','E':'Edge length (m)',
                      'F':'Edge cost (THB)','G':'Waste (THB)',
                      'H':'Rounded run (THB)','I':'Total (selected)','J':'Raw total (THB)'},
                   {col:1 for col in 'ABCDEFGHI'})]
    per_cab_reference={'KITCHEN':0.0,'WALL':0.0}
    for idx,((cab,run),items) in enumerate(run_groups.items(),2):
        is_k=(cab=='KITCHEN')
        edge_ref=('Settings!$B$6' if is_k else 'Settings!$B$8')
        waste_ref=('Settings!$B$7' if is_k else 'Settings!$B$9')
        panel_parts=[item for _,item in items if item['category'] in PANEL_CATEGORIES]
        material=sum(float(part['material_cost']) for _,part in items)
        panel=sum(float(part['material_cost']) for part in panel_parts)
        length=sum(float(part['edge_m']) for _,part in items)
        edge=round(length*float(kitchen_settings['edge_rate'] if is_k else wall_settings['edge_rate']),2)
        waste=round(panel*float(kitchen_settings['waste_percent'] if is_k else wall_settings['waste_percent'])/100,2)
        calc_total=round(material+edge+waste,2)
        # Blender rounds each straight module subtotal, but on L/U layouts
        # it adds CONTINUOUS BACKSPLASH segments at raw precision before the
        # final layout total is rounded. Preserve that distinction here.
        if run.startswith('BACKSPLASH_'):
            raw_total=sum(_raw_quantity(part)*float(part['unit_rate'])*(1+float(
                kitchen_settings['waste_percent'] if is_k else wall_settings['waste_percent'])/100)
                for _,part in items)
        else:
            raw_total=calc_total
        per_cab_reference[cab]+=raw_total
        panel_formula='+'.join(f'SUMIFS({amounts},{cabs},$A{idx},{runs},$B{idx},{cats},"{category}")'
                               for category in PANEL_CATEGORIES)
        # Add separate run bookkeeping rather than summing edges/waste across
        # all returns (which can introduce a different rounding penny).
        raw_formula=(
            '='+'+'.join(f'(BOQ!I{line}*BOQ!L{line}*(1+{waste_ref}/100))'
                           for line,_ in items)
            if run.startswith('BACKSPLASH_')
            else f'=H{idx}')
        vals={'A':cab,'B':run,
              'C':f'=SUMIFS({amounts},{cabs},$A{idx},{runs},$B{idx})',
              'D':f'={panel_formula}',
              'E':f'=SUMIFS({edges},{cabs},$A{idx},{runs},$B{idx})',
              'F':f'=ROUND(E{idx}*{edge_ref},2)',
              'G':f'=ROUND(D{idx}*{waste_ref}/100,2)',
              'H':f'=ROUND(SUM(C{idx},F{idx},G{idx}),2)',
              'I':f'=IFERROR(ROUND(J{idx}/Settings!$B$5,2),0)',
              'J':raw_formula}
        run_rows.append(_row(idx,vals,{k:3 for k in 'CDEFGHIJ'},
                             set('CDEFGHIJ'),
                             {'C':material,'D':panel,'E':length,'F':edge,'G':waste,
                              'H':calc_total,'I':round(raw_total/thb_per_unit,2),
                              'J':raw_total}))
    rlast=max(2,len(run_groups)+1)
    # SUMMARY: selected currency totals as the main visible output.
    # All selected figures are derived from THB grand totals/FX (not the sum
    # of rounded converted BOQ rows), matching Blender's money_label().
    source_k=float(blender_totals.get('KITCHEN',per_cab_reference['KITCHEN']))
    source_w=float(blender_totals.get('WALL',per_cab_reference['WALL']))
    source_all=round(source_k+source_w,2)
    summary=[
        _row(1,{'A':'CABINET BOQ — SAME CURRENCY & TOTAL AS BLENDER'},{'A':1}),
        _row(2,{'A':'Currency','B':'=Settings!B2'},{'A':2,'B':3},{'B'},{'B':currency}),
        _row(3,{'A':'THB per selected currency','B':'=Settings!B5'},{'A':2,'B':3},{'B'},{'B':thb_per_unit}),
        _row(5,{'A':'PROJECT TOTALS (SELECTED CURRENCY)','B':'="Amount ("&Settings!B2&")"'},
             {'A':1,'B':1},{'B'},{'B':f'Amount ({currency})'}),
        _row(6,{'A':'Kitchen Cabinet','B':'=IFERROR(ROUND(B15/Settings!$B$5,2),0)'},
             {'A':2,'B':6},{'B'},{'B':round(source_k/thb_per_unit,2)}),
        _row(7,{'A':'Wall Cabinet','B':'=IFERROR(ROUND(C15/Settings!$B$5,2),0)'},
             {'A':2,'B':6},{'B'},{'B':round(source_w/thb_per_unit,2)}),
        _row(8,{'A':'GRAND TOTAL','B':'=IFERROR(ROUND(D15/Settings!$B$5,2),0)'},
             {'A':6,'B':6},{'B'},{'B':round(source_all/thb_per_unit,2)}),
        _row(10,{'A':'Cost component','B':'Kitchen (THB)','C':'Wall (THB)',
                 'D':'Combined (THB)','E':'="Total ("&Settings!B2&")"'},
             {k:1 for k in 'ABCDE'},{'E'},{'E':f'Total ({currency})'})]
    for idx,(title,source_col) in enumerate((('Materials / supply','C'),('Edge banding','F'),
                                              ('Waste allowance','G'),('Rounding alignment (L/U)',None),
                                              ('Total', 'J')),11):
        values={'A':title}
        cache={}
        for column,cab in (('B','KITCHEN'),('C','WALL')):
            if idx==14:
                values[column]=(f'=ROUND(SUMIF(\'Run Costs\'!$A$2:$A${rlast},"{cab}",'
                                f'\'Run Costs\'!$J$2:$J${rlast})-SUM({column}11:{column}13),2)')
            elif idx==15:
                values[column]=f'=ROUND(SUM({column}11:{column}14),2)'
            else:
                values[column]=f'=SUMIF(\'Run Costs\'!$A$2:$A${rlast},"{cab}",\'Run Costs\'!${source_col}$2:${source_col}${rlast})'
            if idx==15:
                cache[column]=(source_k if cab=='KITCHEN' else source_w)
            elif idx==14:
                cache[column]=round((source_k if cab=='KITCHEN' else source_w)-
                    sum(round(sum(p['material_cost'] for _,p in group) if j==0 else
                        round(sum(p['edge_m'] for _,p in group)*float(kitchen_settings['edge_rate'] if cab=='KITCHEN' else wall_settings['edge_rate']),2) if j==1 else
                        round(sum(p['material_cost'] for _,p in group if p['category'] in PANEL_CATEGORIES)*float(kitchen_settings['waste_percent'] if cab=='KITCHEN' else wall_settings['waste_percent'])/100,2),2)
                        for (sect,_),group in run_groups.items() if sect==cab for j in range(3)),2)
            else:
                col_map={'C':0,'F':1,'G':2}
                z=col_map[source_col]
                cache[column]=round(sum(
                    (sum(p['material_cost'] for _,p in parts) if z==0 else
                     round(sum(p['edge_m'] for _,p in parts)*float(kitchen_settings['edge_rate'] if cab=='KITCHEN' else wall_settings['edge_rate']),2) if z==1 else
                     round(sum(p['material_cost'] for _,p in parts if p['category'] in PANEL_CATEGORIES)*float(kitchen_settings['waste_percent'] if cab=='KITCHEN' else wall_settings['waste_percent'])/100,2))
                    for (section,_),parts in run_groups.items() if section==cab),2)
        values['D']=f'=SUM(B{idx}:C{idx})'
        values['E']=f'=IFERROR(ROUND(D{idx}/Settings!$B$5,2),0)'
        cache['D']=round(cache['B']+cache['C'],2)
        cache['E']=round(cache['D']/thb_per_unit,2)
        summary.append(_row(idx,values, {k:(6 if idx==15 else 3) for k in 'ABCDE'},
                            set('BCDE'),cache))
    summary.extend([
        _row(17,{'A':'EXPORT-TIME BLENDER SNAPSHOT','B':'Kitchen','C':'Wall','D':'Combined'},{'A':1,'B':1,'C':1,'D':1}),
        _row(18,{'A':'Blender total (THB)','B':source_k,'C':source_w,'D':source_all},
             {'A':2,'B':3,'C':3,'D':3}),
        _row(19,{'A':'Difference before Excel edits (THB)',
                 'B':'=ROUND(B15-B18,2)','C':'=ROUND(C15-C18,2)','D':'=ROUND(D15-D18,2)'},
             {'A':2,'B':3,'C':3,'D':3},{'B','C','D'},{'B':0,'C':0,'D':0}),
        _row(21,{'A':'Edit','B':'Blue BOQ inputs / THB rates and Settings FX; amounts and grand total recalculate.'}),
        _row(22,{'A':'Source','B':'Snapshot is for comparison only; it stays fixed after Excel edits.'}),
        _row(23,{'A':'Formula precision','B':'Area and linear quantity calculations retain full precision; display is rounded.'})])
    sheets=[
        ('BOQ',_worksheet(detail,[15,17,61,15,15,15,11,11,15,16,14,19,19,21,62,22,23],
                          freeze=1,autofilter=f'A1:Q{last}')),
        ('Summary',_worksheet(summary,[41,32,26,26,29])),
        ('Settings',_worksheet(settings,[38,105],validation='B2')),
        ('Run Costs',_worksheet(run_rows,[18,27,20,20,20,22,20,20,23,23],
                                freeze=1,autofilter=f'A1:I{rlast}'))]
    content_types=('<?xml version="1.0" encoding="UTF-8"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        +''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" '
                 'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                 for i in range(1,len(sheets)+1))+'</Types>')
    styles=('<?xml version="1.0" encoding="UTF-8"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<fonts count="3"><font><sz val="10"/><name val="Aptos"/></font>'
        '<font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Aptos"/></font>'
        '<font><b/><color rgb="FF1454A0"/><sz val="10"/><name val="Aptos"/></font></fonts>'
        '<fills count="4"><fill><patternFill patternType="none"/></fill>'
        '<fill><patternFill patternType="gray125"/></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FF18324C"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFE9F3FF"/></patternFill></fill></fills>'
        '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="7">'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
        '<xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
        '<xf numFmtId="4" fontId="2" fillId="3" borderId="0" xfId="0" applyFill="1" applyFont="1" applyNumberFormat="1"/>'
        '<xf numFmtId="4" fontId="2" fillId="3" borderId="0" xfId="0" applyFill="1" applyFont="1" applyNumberFormat="1"/>'
        '<xf numFmtId="4" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1" applyNumberFormat="1"/>'
        '</cellXfs></styleSheet>')
    workbook=('<?xml version="1.0" encoding="UTF-8"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheets>'+''.join(f'<sheet name="{_s(name)}" sheetId="{i}" r:id="rId{i}"/>'
                         for i,(name,_) in enumerate(sheets,1))+'</sheets>'
        '<calcPr calcId="191029" calcMode="auto" fullCalcOnLoad="1" '
        'forceFullCalc="1"/></workbook>')
    rels=('<?xml version="1.0" encoding="UTF-8"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        +''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                 f'Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))
        +f'<Relationship Id="rId{len(sheets)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
        'Target="styles.xml"/></Relationships>')
    root_rels=('<?xml version="1.0" encoding="UTF-8"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
        'Target="xl/workbook.xml"/></Relationships>')
    with ZipFile(path,'w',ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml',content_types)
        archive.writestr('_rels/.rels',root_rels)
        archive.writestr('xl/workbook.xml',workbook)
        archive.writestr('xl/_rels/workbook.xml.rels',rels)
        archive.writestr('xl/styles.xml',styles)
        for i,(_,data) in enumerate(sheets,1):
            archive.writestr(f'xl/worksheets/sheet{i}.xml',data)
    return len(rows)
