"""Conservative, dependency-free L/U corner clearance planning in millimetres.

Models 2D swept bounds of drawer boxes/fronts/handles and swing leaves/handles
against adjacent cabinet carcasses and corner filler panels. It is a layout
safety aid, not manufacturing collision certification. No Blender APIs.
"""
import math


def aabb(local, tx=0., ty=0., angle=0.):
    x0,x1,y0,y1=local
    co,si=math.cos(angle),math.sin(angle)
    pts=[(tx+co*x-si*y,ty+si*x+co*y) for x in (x0,x1) for y in (y0,y1)]
    return (min(v[0] for v in pts),max(v[0] for v in pts),
            min(v[1] for v in pts),max(v[1] for v in pts))


def intersects(a,b,margin=0.5):
    return (min(a[1],b[1])-max(a[0],b[0])>margin and
            min(a[3],b[3])-max(a[2],b[2])>margin)


def body_bounds(module):
    _,d,x,y,angle=module
    return aabb((-d['width']/2,d['width']/2,-d['depth']/2,d['depth']/2),x,y,angle)


def filler_bounds(d, side, f):
    """Vertical face filler between main front plane and recessed return end."""
    w,dep,t=float(d['width']),float(d['depth']),float(d['carcass_thickness'])
    inner=(-w/2+dep) if side=='LEFT' else (w/2-dep)
    # v4.9.1 fix: match make_layout(), which builds the filler INSIDE the
    # return envelope. The old proxy sat one board thickness on the room side,
    # so drawers in the column next to a corner looked blocked and the auto
    # filler grew to its 425 mm cap, leaving a gap in L/U corners.
    cx=inner-t/2 if side=='LEFT' else inner+t/2
    cy=-dep/2-f/2
    return (cx-t/2,cx+t/2,cy-f/2,cy+f/2)


def _local_drawer_boxes(run,col,count,pulls):
    gap=float(run['door_gap'])
    t=float(run['carcass_thickness'])
    w=float(run['width']); dep=float(run['depth']); cols=int(run['door_columns'])
    v=int(run['vertical_divisions'])
    inner=w-2*t
    bayw=(inner-v*t)/(v+1)
    if not 1<=col<=cols or col>v+1: return
    face_w=(w-(cols+1)*gap)/cols
    front_x=-w/2+gap+(col-.5)*face_w+(col-1)*gap
    box_x=-inner/2+(col-.5)*bayw+(col-1)*t
    boxw=bayw-2*float(run['drawer_slide_clearance'])
    boxd=float(run['drawer_depth'])
    for n in range(count):
        pull=float(pulls[n])
        # Complete swept envelope from CLOSED to requested extension.
        # Handles are represented by a conservative 20 mm projection.
        front=(front_x-face_w/2,front_x+face_w/2,
               -dep/2-t-pull-20,-dep/2)
        box=(box_x-boxw/2,box_x+boxw/2,
             -dep/2-pull,-dep/2+boxd)
        yield n+1, (front,box)


def drawer_interference(module, other_rects, bank, travel=None):
    _,run,x,y,angle=module
    pulls=list(bank['pulls'])
    if travel is not None:
        pulls=[travel if k+1==bank.get('_drawer_index',0) else 0.0 for k in range(len(pulls))]
    # For single-drawer testing we only need one sweep; caller uses one pull per check.
    for index,rects in _local_drawer_boxes(run,int(bank['column']),int(bank['count']),pulls):
        if bank.get('_drawer_index') and index!=bank['_drawer_index']: continue
        for rect in rects:
            world=aabb(rect,x,y,angle)
            if any(intersects(world,block) for block in other_rects):
                return index
    return 0


def _door_local_bounds(run,col,theta):
    w,dep,t=float(run['width']),float(run['depth']),float(run['carcass_thickness'])
    cols=int(run['door_columns']); gap=float(run['door_gap'])
    dw=(w-(cols+1)*gap)/cols
    center=-w/2+gap+(col-.5)*dw+(col-1)*gap
    side=-1 if (col-1)%2==0 else 1
    pivot_x=center+side*dw/2
    pivot_y=-dep/2
    ang=side*theta
    co,si=math.cos(ang),math.sin(ang)
    def transform(px,py):
        xx,yy=px-pivot_x,py-pivot_y
        return pivot_x+co*xx-si*yy,pivot_y+si*xx+co*yy
    pts=[transform(xx,yy) for xx in (center-dw/2,center+dw/2)
         for yy in (-dep/2-t,-dep/2)]
    # Handle modeled at 30% of width toward middle of pair, protruding 24 mm.
    if run.get('show_handles') and not run.get('use_nose_gap'):
        handle_x=center+(dw*.30 if (col-1)%2==0 else -dw*.30)
        pts.extend(transform(xx,yy) for xx in (handle_x-12,handle_x+12)
                   for yy in (-dep/2-t-24,-dep/2-t))
    return (min(p[0] for p in pts),max(p[0] for p in pts),
            min(p[1] for p in pts),max(p[1] for p in pts))


def door_interference(module, other_rects, col, angle):
    _,run,x,y,rot=module
    if angle<0.00001 or run.get('front_style','CLOSED')!='CLOSED': return False
    steps=max(2,math.ceil(math.degrees(angle)/5))
    for i in range(steps+1):
        theta=angle*i/steps
        rect=_door_local_bounds(run,col,theta)
        if any(intersects(aabb(rect,x,y,rot), block) for block in other_rects):
            return True
    return False


def blockers(modules, focus, base, fillers):
    other=[]
    for m in modules:
        if m[0]==focus: continue
        other.append(body_bounds(m))
    for side,f in fillers.items():
        if f>0: other.append(filler_bounds(base,side,f))
    return other


def problems(modules, base, fillers):
    """Return all requested moving parts which intersect adjacent run/filler proxy."""
    found=[]
    if len(modules)<2: return found
    for m in modules:
        name,run,_,_,_=m
        others=blockers(modules,name,base,fillers)
        if run.get('enable_drawers'):
            for bank in run.get('drawer_banks',[]):
                for ix in range(1,int(bank['count'])+1):
                    b=dict(bank,_drawer_index=ix)
                    hit=drawer_interference(m,others,b)
                    if hit:
                        found.append((name,'DRAWER',int(bank['column']),ix))
        if run.get('front_style','CLOSED')=='CLOSED':
            for col in range(1,int(run['door_columns'])+1):
                if any(int(b['column'])==col for b in run.get('drawer_banks',[]) if run.get('enable_drawers')):
                    continue
                if door_interference(m,others,col,float(run.get('door_open_angle',0))):
                    found.append((name,'DOOR',col,0))
    return found


def _safe_pull(module, others, bank, drawer_index, wanted):
    wanted=max(0.,wanted)
    if wanted<0.01:return 0.
    b=dict(bank,_drawer_index=drawer_index)
    low,high=0.,wanted
    # If the drawer face/handle already crosses a foreign cabinet or filler,
    # no safe travel can be approved by this conservative proxy.
    if drawer_interference(module,others,b,0.):return 0.
    if not drawer_interference(module,others,b,high):return high
    for _ in range(14):
        mid=(low+high)/2
        if drawer_interference(module,others,b,mid):high=mid
        else:low=mid
    return max(0.,low-1.)


def _safe_angle_column(module, others, col, wanted):
    """Constrain only a colliding leaf, leaving the other doors free to swing."""
    if wanted<=0.:return 0.
    if door_interference(module,others,col,0.001):return 0.
    if not door_interference(module,others,col,wanted):return wanted
    lo,hi=0.,wanted
    for _ in range(13):
        mid=(lo+hi)/2
        if door_interference(module,others,col,mid): hi=mid
        else:lo=mid
    return max(0.,lo-math.radians(0.2))


def _active_drawer_sweep(module):
    name,run,x,y,rotation=module
    rectangles=[]
    if not run.get('enable_drawers'): return rectangles
    for bank in run.get('drawer_banks',[]):
        for _,boxes in _local_drawer_boxes(run,int(bank['column']),
                                           int(bank['count']),bank['pulls']):
            for box in boxes:
                rectangles.append(aabb(box,x,y,rotation))
    return rectangles



def _door_sweep_rectangles(module,col,angle):
    """AABB envelopes of the leaf and its handle through the open motion."""
    name,run,x,y,rot=module
    if angle<=0.00001:return []
    steps=max(2,math.ceil(math.degrees(angle)/5.))
    return [aabb(_door_local_bounds(run,col,angle*i/steps),x,y,rot)
            for i in range(steps+1)]


def enforce(modules, base, fillers):
    """Copies run dicts and clamps individual drawers/door leaves, not UI values."""
    results=[]; notices=[]
    # First resolve drawer motion against perpendicular cabinet bodies and
    # fillers. Each drawer keeps its own safe limit.
    for m in modules:
        name,old,x,y,rot=m
        run=dict(old)
        others=blockers(modules,name,base,fillers)
        run['drawer_banks']=[dict(bank,pulls=list(bank['pulls'])) for bank in old.get('drawer_banks',[])]
        if run.get('enable_drawers'):
            for bank in run['drawer_banks']:
                bank['_corner_safe_limits_mm']=[]
                for ix in range(1,int(bank['count'])+1):
                    old_pull=float(bank['pulls'][ix-1])
                    limit=min(900.0,max(0.0,float(run['drawer_depth'])-35.0),float(run['drawer_depth'])*.95)
                    maximum=_safe_pull((name,run,x,y,rot),others,bank,ix,limit)
                    safe=min(old_pull,maximum)
                    bank['_corner_safe_limits_mm'].append(round(maximum,2))
                    bank['pulls'][ix-1]=round(safe,3)
                    if safe+0.5 < old_pull:
                        notices.append(f'{name} C{bank["column"]} drawer {ix}: {old_pull:.0f} -> {safe:.0f} mm safe pull')
        results.append((name,run,x,y,rot))
    # Per-leaf swing limits also account for drawers already pulled on OTHER
    # runs. No need to close an entire main run just because one corner door
    # has an obstruction.
    final=[]
    completed_door_sweeps=[]
    for m in results:
        name,run,x,y,rot=m
        others=blockers(results,name,base,fillers)
        for neighbor in results:
            if neighbor[0]!=name:
                others.extend(_active_drawer_sweep(neighbor))
        # Main run is processed first; later perpendicular returns avoid the
        # already approved main/other-return door-swing envelopes as well.
        others.extend(rect for owner,rect in completed_door_sweeps if owner!=name)
        wanted=float(run.get('door_open_angle',0.))
        drawer_cols={int(b['column']) for b in run.get('drawer_banks',[])} if run.get('enable_drawers') else set()
        angles={}
        if wanted>0 and run.get('front_style','CLOSED')=='CLOSED':
            for col in range(1,int(run['door_columns'])+1):
                if col in drawer_cols:continue
                safe=_safe_angle_column(m,others,col,wanted)
                angles[str(col)]=safe
                completed_door_sweeps.extend((name,rect) for rect in _door_sweep_rectangles(m,col,safe))
                if safe+math.radians(.3)<wanted:
                    notices.append(f'{name} swing C{col}: {math.degrees(wanted):.0f} -> {math.degrees(safe):.0f} deg')
        run['_corner_leaf_angles']=angles
        final.append((name,run,x,y,rot))
    return final,notices
