bl_info = {"name":"BOQ-Cabinet Generator", "author":"Integrazo / OpenAI", "version":(4,9,0), "blender":(4,2,0), "location":"View3D > Sidebar > BOQ-Cabinet", "description":"Parametric cabinet generator with independent components, live preview and detailed BOQ", "category":"Add Mesh"}

import bpy, csv, math, json, uuid
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty, PointerProperty, CollectionProperty)
from mathutils import Vector, Matrix
from . import corner_safety
from . import web_import

ROOT = 'INTEGRAZO_CABINET'
PREVIEW = '_LIVE_PREVIEW'
GENERATED = 'GENERATED_CABINETS'
PREFIX = 'IGZ_CAB_'
_REFRESHING = False
_TIMER_PENDING = False

PRICE_RATE_GROUPS = {
    'Laminate & Panels': (
        ('wood_laminate_rate', 'Wood Laminate', 'THB/m²', 1250.0),
        ('color_laminate_rate', 'Color Laminate', 'THB/m²', 1100.0),
        ('carcass_rate', 'Legacy Carcass Rate', 'THB/m²', 850.0),
        ('back_rate', 'Back Panel / Drawer Bottom', 'THB/m²', 280.0),
        ('door_rate', 'Legacy Door Rate', 'THB/m²', 1100.0),
        ('shaker_glass_rate', 'Shaker Glass', 'THB/m²', 850.0),
        ('backsplash_rate', 'Backsplash', 'THB/m²', 950.0),
    ),
    'Countertops': (
        ('countertop_composite_rate', 'Composite Surface', 'THB/m²', 2800.0),
        ('countertop_quartz_rate', 'Quartz', 'THB/m²', 4800.0),
        ('countertop_terrazzo_rate', 'Terrazzo', 'THB/m²', 3500.0),
        ('countertop_granite_rate', 'Granite', 'THB/m²', 6200.0),
    ),
    'Hardware': (
        ('hinge_rate', 'Hinge', 'THB/pc', 80.0),
        ('handle_rate', 'Door Handle', 'THB/pc', 150.0),
        ('drawer_slide_rate', 'Drawer Slide Pair', 'THB/pair', 450.0),
        ('drawer_handle_rate', 'Drawer Handle', 'THB/pc', 150.0),
        ('drawer_push_rate', 'Legacy Push-to-Open', 'THB/set', 180.0),
        ('nose_gap_rate', 'Nose Gap Rail', 'THB/m', 120.0),
        ('shelf_support_rate', 'Shelf Support', 'THB/pc', 8.0),
        ('mount_bracket_rate', 'Wall Mounting Bracket', 'THB/pc', 150.0),
        ('mount_rail_rate', 'Wall Mounting Rail', 'THB/m', 250.0),
    ),
    'Fabrication & Installation': (
        ('edge_rate', 'Edge Banding', 'THB/m', 30.0),
        ('plinth_rate', 'Plinth', 'THB/m', 200.0),
        ('kickstand_rate', 'Adjustable Foot', 'THB/pc', 120.0),
        ('sink_unit_rate', 'Sink Supply', 'THB/pc', 3000.0),
        ('sink_cutout_rate', 'Sink Cutout / Fabrication', 'THB/pc', 600.0),
        ('sink_install_rate', 'Sink Installation', 'THB/pc', 900.0),
        ('labor_rate', 'Cabinet Assembly', 'THB/set', 1200.0),
        ('waste_percent', 'Panel Waste Allowance', '%', 10.0),
    ),
}
PRICE_RATE_KEYS = tuple(key for items in PRICE_RATE_GROUPS.values() for key, _, _, _ in items)
PRICE_DEFAULTS = {key: default for items in PRICE_RATE_GROUPS.values() for key, _, _, default in items}


# Prices are illustrative editable THB rates, not verified supplier quotations.
# Currency conversions are manual (never automatic live FX quotes).
MATERIALS = {
    'WOOD_LAMINATE': ('Wood Laminate', (0.61,0.40,0.25,1), 1250.0),
    'COLOR_LAMINATE': ('Color Laminate', (0.79,0.83,0.79,1), 1100.0),
    'CARCASS': ('Carcass 18mm', (0.76,0.73,0.66,1), 850.0),
    'BACK': ('Backboard 6mm', (0.85,0.83,0.78,1), 280.0),
    'COUNTER_COMPOSITE': ('Composite solid-surface countertop', (0.87,0.85,0.81,1), 2800.0),
    'COUNTER_QUARTZ': ('Engineered quartz countertop', (0.83,0.84,0.83,1), 4800.0),
    'COUNTER_TERRAZZO': ('Terrazzo countertop', (0.87,0.85,0.79,1), 3500.0),
    'COUNTER_GRANITE': ('Natural granite countertop', (0.38,0.39,0.41,1), 6200.0),
    'COUNTER_WOOD': ('Wood laminate countertop', (0.61,0.40,0.25,1), 1250.0),
    'BACKSPLASH': ('Backsplash panel', (0.78,0.82,0.81,1), 950.0),
    'DOOR': ('Door 18mm', (0.94,0.92,0.86,1), 1100.0),
    'GLASS': ('Cabinet Door Glazing', (0.65,0.80,0.81,0.28), 850.0),
    'EDGE': ('Edge banding', (0.74,0.69,0.59,1), 30.0),
    'HARDWARE': ('Hardware', (0.24,0.27,0.30,1), 0.0),
    'PLINTH': ('Plinth', (0.42,0.43,0.44,1), 200.0),
    'KICKSTAND': ('Adjustable cabinet foot', (0.18,0.20,0.22,1), 120.0),
    'NOSE_GAP': ('Finger-pull recess', (0.30,0.31,0.31,1), 0.0),
    'MOUNT': ('Wall mounting bracket and rail', (0.40,0.42,0.44,1), 0.0),
    'SINK': ('Stainless-steel sink (schematic)', (0.67,0.71,0.75,1), 0.0),
}


def collection(name, parent=None):
    c = bpy.data.collections.get(name)
    if c is None:
        c = bpy.data.collections.new(name)
    parent = parent or bpy.context.scene.collection
    if c not in list(parent.children):
        try: parent.children.link(c)
        except RuntimeError: pass
    return c


def roots():
    root = collection(ROOT)
    return root, collection(PREVIEW, root), collection(GENERATED, root)


def remove_collection_contents(c):
    for child in list(c.children):
        remove_collection_contents(child)
        bpy.data.collections.remove(child)
    for obj in list(c.objects):
        bpy.data.objects.remove(obj, do_unlink=True)


def material(key):
    label, color, _ = MATERIALS[key]
    name = 'IGZ_Cabinet_' + key
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.diffuse_color = color
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get('Principled BSDF')
    if bsdf:
        bsdf.inputs['Base Color'].default_value = color
        bsdf.inputs['Roughness'].default_value = (0.27 if key == 'SINK' else 0.42 if key == 'HARDWARE' else 0.67)
        bsdf.inputs['Metallic'].default_value = (0.90 if key == 'SINK' else 0.8 if key == 'HARDWARE' else 0.0)
    return mat



def countertop_stone_material(key):
    """Procedural, UV-mapped terrazzo/granite countertop texture with visible chips."""
    name = 'IGZ_Cabinet_' + key
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    links = mat.node_tree.links
    out = nodes.new('ShaderNodeOutputMaterial')
    out.location = (750, 80)
    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    bsdf.location = (470, 80)
    bsdf.inputs['Metallic'].default_value = 0.0
    bsdf.inputs['Roughness'].default_value = 0.30 if key == 'COUNTER_GRANITE' else 0.42
    links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])

    tex = nodes.new('ShaderNodeTexCoord')
    tex.location = (-1000, 80)
    mapping = nodes.new('ShaderNodeVectorMath')
    mapping.operation = 'SCALE'
    mapping.location = (-790, 80)
    # UV coordinates are generated in metres on the cabinet geometry.
    mapping.inputs['Scale'].default_value = 11.0 if key == 'COUNTER_TERRAZZO' else 19.0
    links.new(tex.outputs['UV'], mapping.inputs['Vector'])

    base_noise = nodes.new('ShaderNodeTexNoise')
    base_noise.location = (-570, -240)
    base_noise.inputs['Scale'].default_value = 3.0
    base_noise.inputs['Detail'].default_value = 4.0
    links.new(mapping.outputs['Vector'], base_noise.inputs['Vector'])
    base = nodes.new('ShaderNodeValToRGB')
    base.location = (-330, -210)
    if key == 'COUNTER_TERRAZZO':
        base.color_ramp.elements[0].color = (0.65, 0.63, 0.59, 1)
        base.color_ramp.elements[1].color = (0.89, 0.86, 0.80, 1)
    else:
        base.color_ramp.elements[0].color = (0.11, 0.12, 0.13, 1)
        base.color_ramp.elements[1].color = (0.43, 0.44, 0.43, 1)
    links.new(base_noise.outputs['Fac'], base.inputs['Fac'])

    chips = nodes.new('ShaderNodeTexVoronoi')
    chips.location = (-560, 260)
    chips.inputs['Scale'].default_value = 34.0 if key == 'COUNTER_TERRAZZO' else 115.0
    links.new(mapping.outputs['Vector'], chips.inputs['Vector'])
    chip_mask = nodes.new('ShaderNodeValToRGB')
    chip_mask.location = (-320, 260)
    chip_mask.color_ramp.interpolation = 'CONSTANT'
    chip_mask.color_ramp.elements[0].position = 0.0
    chip_mask.color_ramp.elements[0].color = (1, 1, 1, 1)
    chip_mask.color_ramp.elements[1].position = 0.20 if key == 'COUNTER_TERRAZZO' else 0.11
    chip_mask.color_ramp.elements[1].color = (0, 0, 0, 1)
    links.new(chips.outputs['Distance'], chip_mask.inputs['Fac'])

    chip_palette = nodes.new('ShaderNodeValToRGB')
    chip_palette.location = (-120, 450)
    if key == 'COUNTER_TERRAZZO':
        chip_palette.color_ramp.elements[0].color = (0.27, 0.29, 0.27, 1)
        chip_palette.color_ramp.elements[1].color = (0.79, 0.72, 0.63, 1)
    else:
        chip_palette.color_ramp.elements[0].color = (0.48, 0.48, 0.46, 1)
        chip_palette.color_ramp.elements[1].color = (0.84, 0.82, 0.77, 1)
    links.new(chips.outputs['Color'], chip_palette.inputs['Fac'])

    blend = nodes.new('ShaderNodeMixRGB')
    blend.blend_type = 'MIX'
    blend.location = (170, 130)
    links.new(chip_mask.outputs['Color'], blend.inputs[0])
    links.new(base.outputs['Color'], blend.inputs[1])
    links.new(chip_palette.outputs['Color'], blend.inputs[2])
    links.new(blend.outputs['Color'], bsdf.inputs['Base Color'])

    bump = nodes.new('ShaderNodeBump')
    bump.location = (170, -180)
    bump.inputs['Strength'].default_value = 0.10 if key == 'COUNTER_TERRAZZO' else 0.06
    bump.inputs['Distance'].default_value = 0.0002
    links.new(base_noise.outputs['Fac'], bump.inputs['Height'])
    links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])
    mat.diffuse_color = MATERIALS[key][1]
    mat['igz_texture_type'] = 'Procedural Terrazzo Chips' if key == 'COUNTER_TERRAZZO' else 'Procedural Granite Speckles'
    return mat



def cabinet_door_glass_material():
    """Transparent neutral glass for the optional glazed Shaker center panel."""
    name = 'IGZ_Cabinet_GLASS'
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get('Principled BSDF')
    if bsdf:
        bsdf.inputs['Base Color'].default_value = (0.79, 0.91, 0.89, 1.0)
        bsdf.inputs['Roughness'].default_value = 0.08
        bsdf.inputs['Metallic'].default_value = 0.0
        transmission = bsdf.inputs.get('Transmission Weight') or bsdf.inputs.get('Transmission')
        if transmission is not None:
            transmission.default_value = 0.90
        if bsdf.inputs.get('IOR'):
            bsdf.inputs['IOR'].default_value = 1.46
        if bsdf.inputs.get('Alpha'):
            bsdf.inputs['Alpha'].default_value = 0.28
    # Blender 4.2+ material transparency in Material Preview / Rendered mode.
    try:
        mat.surface_render_method = 'DITHERED'
    except (AttributeError, TypeError, ValueError):
        pass
    mat.diffuse_color = (0.79, 0.91, 0.89, 0.28)
    return mat


def backsplash_tile_material():
    """Sage-green narrow vertical tile with pale grout, mapped in metres."""
    name = 'IGZ_Cabinet_BACKSPLASH'
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    links = mat.node_tree.links
    out = nodes.new('ShaderNodeOutputMaterial')
    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    bsdf.inputs['Roughness'].default_value = 0.27
    links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    tex = nodes.new('ShaderNodeTexCoord')
    sep = nodes.new('ShaderNodeSeparateXYZ')
    links.new(tex.outputs['UV'], sep.inputs['Vector'])
    # Narrow 50 mm tiles, with 2 mm grout. UV coordinates are metres.
    x = nodes.new('ShaderNodeMath')
    x.operation = 'PINGPONG'
    x.inputs[1].default_value = 0.05
    links.new(sep.outputs['X'], x.inputs[0])
    grout_x = nodes.new('ShaderNodeMath')
    grout_x.operation = 'LESS_THAN'
    grout_x.inputs[1].default_value = 0.002
    links.new(x.outputs[0], grout_x.inputs[0])
    y = nodes.new('ShaderNodeMath')
    y.operation = 'PINGPONG'
    y.inputs[1].default_value = 0.40
    links.new(sep.outputs['Y'], y.inputs[0])
    grout_y = nodes.new('ShaderNodeMath')
    grout_y.operation = 'LESS_THAN'
    grout_y.inputs[1].default_value = 0.002
    links.new(y.outputs[0], grout_y.inputs[0])
    mask = nodes.new('ShaderNodeMath')
    mask.operation = 'MAXIMUM'
    links.new(grout_x.outputs[0], mask.inputs[0])
    links.new(grout_y.outputs[0], mask.inputs[1])
    mix = nodes.new('ShaderNodeMixRGB')
    mix.inputs[1].default_value = (0.46,0.66,0.51,1)
    mix.inputs[2].default_value = (0.86,0.87,0.82,1)
    links.new(mask.outputs[0], mix.inputs[0])
    links.new(mix.outputs[0], bsdf.inputs['Base Color'])
    mat.diffuse_color = (0.46,0.66,0.51,1)
    return mat


def cabinet_finish_material(finish, tone, role):
    """Procedural, UV-driven PBR laminate. No external image dependencies."""
    is_wood = finish == 'WOOD'
    palette = {
        'OAK': ((0.52,0.32,0.17,1),(0.77,0.56,0.33,1)),
        'ASH': ((0.67,0.57,0.42,1),(0.86,0.77,0.62,1)),
        'WALNUT': ((0.20,0.105,0.065,1),(0.42,0.26,0.16,1)),
        'WHITE': ((0.86,0.85,0.81,1),(0.86,0.85,0.81,1)),
        'GREY': ((0.43,0.47,0.48,1),(0.43,0.47,0.48,1)),
        'SAGE': ((0.42,0.55,0.48,1),(0.42,0.55,0.48,1)),
        'BLUE': ((0.22,0.35,0.49,1),(0.22,0.35,0.49,1)),
        'CHARCOAL': ((0.17,0.18,0.19,1),(0.17,0.18,0.19,1)),
    }
    low, high = palette.get(tone,palette['OAK' if is_wood else 'WHITE'])
    name = f'IGZ_Laminate_{role}_{finish}_{tone}'
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.diffuse_color = high
    nodes = mat.node_tree.nodes
    nodes.clear()
    links = mat.node_tree.links
    out = nodes.new('ShaderNodeOutputMaterial')
    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    bsdf.inputs['Roughness'].default_value = 0.43 if is_wood else 0.51
    bsdf.inputs['Metallic'].default_value = 0.0
    links.new(bsdf.outputs['BSDF'],out.inputs['Surface'])
    if is_wood:
        uv=nodes.new('ShaderNodeTexCoord')
        mapping=nodes.new('ShaderNodeVectorMath'); mapping.operation='MULTIPLY'
        mapping.inputs[1].default_value=(3.0,42.0,1.0)
        links.new(uv.outputs['UV'],mapping.inputs[0])
        noise=nodes.new('ShaderNodeTexNoise')
        noise.inputs['Scale'].default_value=2.4
        noise.inputs['Detail'].default_value=3.0
        noise.inputs['Roughness'].default_value=0.68
        links.new(mapping.outputs['Vector'],noise.inputs['Vector'])
        ramp=nodes.new('ShaderNodeValToRGB')
        ramp.color_ramp.elements[0].position=0.28
        ramp.color_ramp.elements[0].color=low
        ramp.color_ramp.elements[1].position=0.75
        ramp.color_ramp.elements[1].color=high
        links.new(noise.outputs['Fac'],ramp.inputs['Fac'])
        links.new(ramp.outputs['Color'],bsdf.inputs['Base Color'])
        bump=nodes.new('ShaderNodeBump')
        bump.inputs['Strength'].default_value=0.065
        bump.inputs['Distance'].default_value=0.0006
        links.new(noise.outputs['Fac'],bump.inputs['Height'])
        links.new(bump.outputs['Normal'],bsdf.inputs['Normal'])
    else:
        bsdf.inputs['Base Color'].default_value=high
    mat['igz_finish']=finish
    mat['igz_tone']=tone
    return mat


def assign_auto_uv(obj):
    """Automatic six-face planar UV unwrap for parametric cuboid meshes.

    Unlike bpy.ops.uv.smart_project this runs safely from Blender timer callbacks,
    including without active selection or a VIEW_3D context. Each face has a
    distortion-free UV island in metres (1 UV unit = 1 metre).
    """
    mesh=obj.data
    uv=mesh.uv_layers.get('UVMap') or mesh.uv_layers.new(name='UVMap')
    for poly in mesh.polygons:
        n=poly.normal
        for li in poly.loop_indices:
            v=mesh.vertices[mesh.loops[li].vertex_index].co
            if abs(n.z)>=max(abs(n.x),abs(n.y)):
                coords=(v.x,v.y)
            elif abs(n.y)>=abs(n.x):
                coords=(v.x,v.z)
            else:
                coords=(v.y,v.z)
            uv.data[li].uv=coords
    obj['igz_uv_method']='AUTO_PLANAR_SMART_CUBOID'


def cube(c, name, loc_mm, dims_mm, mat_key, meta=None):
    # Explicit mesh creation; no bpy.ops calls in timer / preview rebuild.
    x,y,z = [v/1000 for v in loc_mm]
    w,d,h = [max(v,0.1)/1000 for v in dims_mm]
    vertices = [(x+sx*w/2, y+sy*d/2, z+sz*h/2) for sx,sy,sz in
                [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]]
    faces = [(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)]
    mesh = bpy.data.meshes.new(name+'_mesh')
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    c.objects.link(obj)
    finish = (meta or {}).get('finish_type')
    tone = (meta or {}).get('finish_tone')
    if finish and tone:
        obj.data.materials.append(cabinet_finish_material(finish,tone,(meta or {}).get('finish_role','PANEL')))
    else:
        obj.data.materials.append(cabinet_door_glass_material() if mat_key == 'GLASS' else countertop_stone_material(mat_key) if mat_key in ('COUNTER_TERRAZZO','COUNTER_GRANITE') else backsplash_tile_material() if mat_key == 'BACKSPLASH' else material(mat_key))
    assign_auto_uv(obj)
    if meta:
        for k,v in meta.items(): obj[k] = v
    return obj


def panel_with_rectangular_cutout(c, name, loc_mm, dims_mm, opening_x_mm,
                                 opening_y_mm, opening_w_mm, opening_d_mm, mat_key, meta=None):
    """Watertight slab with a genuine through-cutout, no bpy.ops/Boolean required.

    Coordinates and UVs are in world metres, matching regular cabinet panels.
    Four top ring faces, four bottom ring faces and vertical cutout/outer walls.
    """
    x,y,z=(v/1000.0 for v in loc_mm)
    width,depth,thickness=(v/1000.0 for v in dims_mm)
    ox,oy,ow,od=(v/1000.0 for v in
                 (opening_x_mm,opening_y_mm,opening_w_mm,opening_d_mm))
    if (ow<=0 or od<=0 or
        abs(ox)+ow/2 >= width/2 or abs(oy)+od/2 >= depth/2):
        raise ValueError('Sink cutout must be completely inside its panel')
    outer=[(-width/2,-depth/2),(width/2,-depth/2),
           (width/2,depth/2),(-width/2,depth/2)]
    inner=[(ox-ow/2,oy-od/2),(ox+ow/2,oy-od/2),
           (ox+ow/2,oy+od/2),(ox-ow/2,oy+od/2)]
    vertices=[]
    for zz in (z-thickness/2,z+thickness/2):
        for loop in (outer,inner):
            vertices.extend((x+xx,y+yy,zz) for xx,yy in loop)
    faces=[]
    for i in range(4):
        nxt=(i+1)%4
        faces.extend([
            (8+i,8+nxt,12+nxt,12+i), # top stone surface
            (i,4+i,4+nxt,nxt),        # underside
            (i,nxt,8+nxt,8+i),        # outside vertical edge
            (4+i,12+i,12+nxt,4+nxt) # inside sink cutout wall
        ])
    mesh=bpy.data.meshes.new(name+'_mesh')
    mesh.from_pydata(vertices,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    c.objects.link(obj)
    finish=(meta or {}).get('finish_type')
    tone=(meta or {}).get('finish_tone')
    if finish and tone:
        obj.data.materials.append(cabinet_finish_material(
            finish,tone,(meta or {}).get('finish_role','PANEL')))
    else:
        mat=(countertop_stone_material(mat_key)
             if mat_key in ('COUNTER_TERRAZZO','COUNTER_GRANITE')
             else material(mat_key))
        obj.data.materials.append(mat)
    assign_auto_uv(obj)
    if meta:
        for key,value in meta.items(): obj[key]=value
    return obj


def panel_with_sink_cutouts(c,name,loc_mm,dims_mm,openings,mat_key,meta=None):
    """Produce one closed solid with one or two separate rectangular sink holes.

    A single opening follows the original v3.8 mesh exactly. Two openings use
    a common XY grid, shared vertex indices and vertical faces only on boundary
    edges. This avoids non-manifold seams and does not require Blender booleans.
    Each opening is (center_x,center_y,width,depth) relative to panel center.
    """
    if len(openings)==1:
        return panel_with_rectangular_cutout(c,name,loc_mm,dims_mm,*openings[0],mat_key,meta)
    if len(openings)!=2:
        raise ValueError('One or two sink openings are required')
    width,depth,thick=map(float,dims_mm)
    ox,oy,oz=map(float,loc_mm)
    holes=[]
    for x,y,w,d in openings:
        x,y,w,d=map(float,(x,y,w,d))
        if w<=0 or d<=0 or abs(x)+w/2>=width/2 or abs(y)+d/2>=depth/2:
            raise ValueError('Sink cutout must be completely inside its panel')
        holes.append((x-w/2,x+w/2,y-d/2,y+d/2))
    a,b=holes
    if a[0]<b[1] and b[0]<a[1] and a[2]<b[3] and b[2]<a[3]:
        raise ValueError('Sink cutouts must not overlap')
    xs=sorted({-width/2,width/2,*[q for a,b,_,_ in holes for q in (a,b)]})
    ys=sorted({-depth/2,depth/2,*[q for _,_,a,b in holes for q in (a,b)]})
    filled=set()
    for i in range(len(xs)-1):
        for j in range(len(ys)-1):
            mx=(xs[i]+xs[i+1])/2
            my=(ys[j]+ys[j+1])/2
            if not any(x0<mx<x1 and y0<my<y1 for x0,x1,y0,y1 in holes):
                filled.add((i,j))
    vertices=[]; vertex_ids={}; faces=[]
    def vid(i,j,top):
        key=(i,j,top)
        if key not in vertex_ids:
            vertex_ids[key]=len(vertices)
            vertices.append(((ox+xs[i])/1000,(oy+ys[j])/1000,
                             (oz+(thick/2 if top else -thick/2))/1000))
        return vertex_ids[key]
    for i,j in sorted(filled):
        corners=((i,j),(i+1,j),(i+1,j+1),(i,j+1))
        faces.append(tuple(vid(a,b,True) for a,b in corners))
        faces.append(tuple(vid(a,b,False) for a,b in reversed(corners)))
        for neighbour,edge in (
            ((i,j-1),(corners[0],corners[1])),
            ((i+1,j),(corners[1],corners[2])),
            ((i,j+1),(corners[2],corners[3])),
            ((i-1,j),(corners[3],corners[0]))):
            if neighbour not in filled:
                start,end=edge
                faces.append((vid(*start,False),vid(*end,False),
                              vid(*end,True),vid(*start,True)))
    mesh=bpy.data.meshes.new(name+'_mesh')
    mesh.from_pydata(vertices,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    c.objects.link(obj)
    finish=(meta or {}).get('finish_type')
    tone=(meta or {}).get('finish_tone')
    if finish and tone:
        obj.data.materials.append(cabinet_finish_material(
            finish,tone,(meta or {}).get('finish_role','PANEL')))
    else:
        obj.data.materials.append(countertop_stone_material(mat_key)
            if mat_key in ('COUNTER_TERRAZZO','COUNTER_GRANITE') else material(mat_key))
    assign_auto_uv(obj)
    if meta:
        for key,value in meta.items(): obj[key]=value
    return obj


def active_sink_specs(d):
    """Independently positioned sink fixtures; legacy one-sink files still work."""
    if not d.get('include_sink',False):
        return []
    if '_sink_specs' in d:
        return [dict(spec) for spec in d['_sink_specs']]
    count=int(d.get('sink_quantity',1))
    if count not in (1,2):
        raise ValueError('Sink Models must be 1 or 2')
    specs=[dict(index=1,run=d.get('sink_run','MAIN'),
                width=d['sink_width'],depth=d['sink_depth'],
                bowl_depth=d['sink_bowl_depth'],x_offset=d['sink_x_offset'],
                front_setback=d['sink_front_setback'])]
    if count==2:
        specs.append(dict(index=2,run=d.get('sink2_run','MAIN'),
                          width=d.get('sink2_width',500.0),
                          depth=d.get('sink2_depth',400.0),
                          bowl_depth=d.get('sink2_bowl_depth',180.0),
                          x_offset=d.get('sink2_x_offset',550.0),
                          front_setback=d.get('sink2_front_setback',90.0)))
    return specs


def sink_cutout_info(d,spec=None):
    """Opening center / size in local cabinet run coordinates, millimetres."""
    if spec is None:
        spec=active_sink_specs(d)[0]
    front=-d['depth']/2-d['countertop_front_overhang']
    return (float(spec['x_offset']),
            front+float(spec['front_setback'])+float(spec['depth'])/2,
            float(spec['width']),float(spec['depth']))


def layout_backsplash_segments(d):
    """Continuous rear-wall and side-wall returns, with clean butt joints.

    Main run spans the complete rear wall. Side-wall panels extend behind the
    main run to the wall corner, rather than stopping at the carcass junction.
    No panels overlap and no backsplash is charged twice in the BOQ.
    """
    shape=d.get('layout_shape','STRAIGHT')
    if shape=='STRAIGHT' or not d.get('include_backsplash') or d['cabinet_type'] not in FLOOR_TYPES:
        return []
    w,dep=d['width'],d['depth']
    thick,height=d['backsplash_thickness'],d['backsplash_height']
    base_z=d['installation_height']+d['height']+(
        d['countertop_thickness'] if d.get('include_countertop',True) else 0)
    z=base_z+height/2
    segments=[('Main Rear Wall', (0,dep/2-thick/2,z),(w,thick,height),w)]
    sides=[d['l_corner_side']] if shape=='L' else ['LEFT','RIGHT']
    for side in sides:
        length=d['return_left_length' if side=='LEFT' else 'return_right_length']
        # Returns are flush with the side-wall plane, and stop at the main
        # rear panel's front face; this eliminates overlapping double panels.
        xmin=-w/2 if side=='LEFT' else w/2-thick
        x=xmin+thick/2
        y_start=-length+dep/2
        y_end=dep/2-thick
        segment_length=y_end-y_start
        segments.append((side.title()+' Side Wall',
                         (x,(y_start+y_end)/2,z),
                         (thick,segment_length,height),segment_length))
    return segments



def on_price_update(self, context):
    """Pricing changes must refresh the displayed BOQ, not rebuild the meshes."""
    if context is None or globals().get('_LOADING_SETTINGS',False): return
    try:
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D': area.tag_redraw()
    except (AttributeError, RuntimeError):
        pass


def ensure_price_library(scene):
    """Migrate v4.7 prices once per .blend, without resetting saved cabinet data.

    Former Kitchen rates become the shared catalog. If Wall had different
    historical rates, a Wall project override is enabled automatically so the
    old Wall BOQ still produces the same totals until the user unifies prices.
    """
    if scene.get('igz_price_library_initialized_v48'): return
    global _LOADING_SETTINGS
    old_loading = _LOADING_SETTINGS
    _LOADING_SETTINGS = True
    try:
        shared = scene.igz_price_library
        kitchen = scene.igz_cabinet
        wall = scene.igz_wall
        for key in PRICE_RATE_KEYS:
            val = float(getattr(kitchen, key, PRICE_DEFAULTS[key]))
            setattr(shared, key, val)
            setattr(scene.igz_kitchen_price_override, key, val)
            setattr(scene.igz_wall_price_override, key, float(getattr(wall, key, val)))
        shared.boq_currency = kitchen.boq_currency
        shared.fx_thb_per_sgd = kitchen.fx_thb_per_sgd
        shared.fx_thb_per_usd = kitchen.fx_thb_per_usd
        wall_differs = any(abs(float(getattr(wall, key, PRICE_DEFAULTS[key]))
            - float(getattr(kitchen, key, PRICE_DEFAULTS[key]))) > 0.0000001
            for key in PRICE_RATE_KEYS)
        shared.wall_override_enabled = wall_differs
        shared.kitchen_override_enabled = False
        scene['igz_price_library_initialized_v48'] = True
    finally:
        _LOADING_SETTINGS = old_loading


def resolved_rates(scene, cabinet):
    """One central price source, with optional explicit project-only overrides."""
    ensure_price_library(scene)
    lib = scene.igz_price_library
    selected = (scene.igz_kitchen_price_override if cabinet == 'KITCHEN'
                else scene.igz_wall_price_override)
    overridden = (lib.kitchen_override_enabled if cabinet == 'KITCHEN'
                  else lib.wall_override_enabled)
    source = selected if overridden else lib
    return {key: float(getattr(source, key)) for key in PRICE_RATE_KEYS}


def priced_settings(scene, p, cabinet):
    d = settings_dict(p)
    d.update(resolved_rates(scene, cabinet))
    return d


def price_library_payload(scene):
    """Portable vendor-independent price library; THB is the fixed base unit."""
    ensure_price_library(scene)
    lib = scene.igz_price_library
    return dict(schema='igz-material-price-library-v1', add_on_version='4.8.1',
                base_currency='THB', selected_currency=lib.boq_currency,
                fx_thb_per_sgd=float(lib.fx_thb_per_sgd),
                fx_thb_per_usd=float(lib.fx_thb_per_usd),
                rates_thb={key: float(getattr(lib,key)) for key in PRICE_RATE_KEYS})


def validate_library_payload(payload):
    """Strict JSON import; reject partial or invalid price lists transactionally."""
    if not isinstance(payload, dict) or payload.get('schema') != 'igz-material-price-library-v1':
        raise ValueError('Unsupported Price Library JSON schema')
    if payload.get('base_currency') != 'THB':
        raise ValueError('Imported rates must be in THB')
    rates = payload.get('rates_thb')
    if not isinstance(rates, dict) or set(rates) != set(PRICE_RATE_KEYS):
        raise ValueError('Price library must contain every known rate ID')
    for name, value in rates.items():
        if not isinstance(value, (int,float)) or isinstance(value, bool) or not math.isfinite(value) or value < 0:
            raise ValueError('Invalid rate for '+name)
        if name == 'waste_percent' and value > 100:
            raise ValueError('Panel waste cannot exceed 100%')
    if payload.get('selected_currency') not in ('THB','SGD','USD'):
        raise ValueError('Invalid selected currency')
    for key in ('fx_thb_per_sgd','fx_thb_per_usd'):
        value=payload.get(key)
        if not isinstance(value,(int,float)) or isinstance(value,bool) or not math.isfinite(value) or value<=0:
            raise ValueError('Invalid FX rate: '+key)
    return payload

def settings_dict(p):
    d = {key:getattr(p,key) for key in (
        'cabinet_type','front_style','width','depth','height','carcass_thickness','back_thickness',
        'shelf_count','door_count','door_columns','door_rows','door_gap','back_inset','shelf_clearance',
        'vertical_divisions','horizontal_divisions','show_handles','use_nose_gap','nose_gap_height',
        'plinth_height','edge_rate','carcass_rate','back_rate','door_rate',
        'hinge_rate','handle_rate','nose_gap_rate','shelf_support_rate','labor_rate','waste_percent',
        'plinth_rate','kickstand_rate','hinges_per_door','show_plinth','support_type','plinth_setback',
        'base_type','installation_height','mount_bracket_rate','mount_rail_rate',
        'include_backsplash','backsplash_height','backsplash_thickness','backsplash_rate','door_open_angle',
        'enable_drawers','drawer_run','drawer_column','drawer_count','drawer_box_thickness',
        'drawer_bottom_thickness','drawer_slide_clearance','drawer_depth','drawer_extension',
        'drawer_motion_mode','drawer_slide_rate','drawer_push_rate','drawer_handle_rate',
        'drawer_multi_bank_mode',
        'corner_smart_enabled','corner_auto_filler','corner_min_filler_mm',
        'corner_max_filler_mm','corner_manual_left_mm','corner_manual_right_mm',
        'carcass_finish','carcass_tone','door_finish','door_tone','door_style',
        'shaker_frame_width','shaker_recess_depth','shaker_glass_thickness','shaker_glass_rate',
        'wood_laminate_rate','color_laminate_rate',
        'layout_shape','l_corner_side','return_left_length','return_right_length',
        'layout_align_dividers','customize_return_runs',
        'return_left_door_columns','return_right_door_columns',
        'return_left_door_rows','return_right_door_rows',
        'return_left_vertical_divisions','return_right_vertical_divisions',
        'return_left_horizontal_divisions','return_right_horizontal_divisions',
        'return_left_door_style','return_right_door_style',
        'return_left_frame_width','return_right_frame_width',
        'include_sink','sink_quantity','sink_run','sink_width','sink_depth','sink_bowl_depth',
        'sink_x_offset','sink_front_setback',
        'sink2_run','sink2_width','sink2_depth','sink2_bowl_depth',
        'sink2_x_offset','sink2_front_setback','countertop_cost_basis',
        'sink_unit_rate','sink_install_rate','sink_cutout_rate',
        'include_countertop','countertop_material','countertop_thickness','countertop_front_overhang',
        'countertop_side_overhang','countertop_composite_rate','countertop_quartz_rate','countertop_granite_rate','countertop_terrazzo_rate','wall_back_offset')}
    d['shelf_count'] = 0  # Legacy-only; removed from cabinet construction workflow.
    d['shelf_clearance'] = 0.0
    # Serializable per-bank settings, shared by model, BOQ, saved models and preview.
    # The original single-bank properties above are retained for saved projects.
    d['drawer_banks'] = [dict(run=b.run, column=int(b.column), count=int(b.count),
        hardware=b.hardware, pulls=[float(getattr(b, f'pull_{i}'))
        for i in range(1,7)]) for b in p.drawer_banks]
    return d


# New keys are filled in for projects generated by earlier add-on versions.
COMPAT_DEFAULTS = {
    'vertical_divisions': 0, 'horizontal_divisions': 0,
    'show_handles': True, 'use_nose_gap': False,
    'nose_gap_height': 25.0, 'nose_gap_rate': 120.0,
    'door_columns': 2, 'door_rows': 1, 'front_style': 'CLOSED',
    'show_plinth': True, 'plinth_height': 100.0, 'support_type': 'PLINTH',
    'plinth_setback': 60.0, 'kickstand_rate': 120.0,
    'base_type': 'PLINTH', 'installation_height': 0.0,
    'mount_bracket_rate': 150.0, 'mount_rail_rate': 250.0,
    'include_backsplash': False, 'backsplash_height': 500.0,
    'backsplash_thickness': 10.0, 'backsplash_rate': 950.0, 'door_open_angle': 0.0,
    'carcass_finish':'WOOD','carcass_tone':'OAK','door_finish':'COLOR','door_tone':'WHITE',
    'enable_drawers':False,'drawer_run':'MAIN','drawer_column':1,'drawer_count':3,
    'drawer_box_thickness':15.0,'drawer_bottom_thickness':6.0,
    'drawer_slide_clearance':13.0,'drawer_depth':400.0,
    'drawer_extension':0.0,'drawer_motion_mode':'HANDLE',
    'drawer_slide_rate':450.0,'drawer_push_rate':180.0,'drawer_handle_rate':150.0,
    'drawer_multi_bank_mode':False,'drawer_banks':[],
    'corner_smart_enabled':False,'corner_auto_filler':True,
    'corner_min_filler_mm':45.0,'corner_max_filler_mm':425.0,
    'corner_manual_left_mm':45.0,'corner_manual_right_mm':45.0,
    'door_style':'FLAT','shaker_frame_width':65.0,'shaker_recess_depth':4.0,
    'shaker_glass_thickness':5.0,'shaker_glass_rate':850.0,
    'wood_laminate_rate':1250.0,'color_laminate_rate':1100.0,
    'layout_shape':'STRAIGHT', 'l_corner_side':'LEFT',
    'layout_align_dividers':True, 'customize_return_runs':False,
    'return_left_door_columns':2,'return_right_door_columns':2,
    'return_left_door_rows':1,'return_right_door_rows':1,
    'return_left_vertical_divisions':0,'return_right_vertical_divisions':0,
    'return_left_horizontal_divisions':0,'return_right_horizontal_divisions':0,
    'return_left_door_style':'INHERIT','return_right_door_style':'INHERIT',
    'return_left_frame_width':65.0,'return_right_frame_width':65.0,
    'include_sink':False,'sink_quantity':1,'sink_run':'MAIN','sink_width':500.0,'sink_depth':400.0,
    'sink_bowl_depth':180.0,'sink_x_offset':0.0,'sink_front_setback':90.0,
    'sink2_run':'MAIN','sink2_width':500.0,'sink2_depth':400.0,
    'sink2_bowl_depth':180.0,'sink2_x_offset':550.0,'sink2_front_setback':90.0,
    'countertop_cost_basis':'GROSS','sink_unit_rate':3000.0,
    'sink_install_rate':900.0,'sink_cutout_rate':600.0,
    'return_left_length':1200.0, 'return_right_length':1200.0,
    'include_countertop': True, 'countertop_material': 'TERRAZZO', 'countertop_thickness': 20.0,
    'countertop_front_overhang': 20.0, 'countertop_side_overhang': 10.0,
    'countertop_composite_rate': 2800.0, 'countertop_quartz_rate': 4800.0,
    'countertop_granite_rate': 6200.0, 'countertop_terrazzo_rate': 3500.0, 'wall_back_offset': 0.0,
}


WALL_TYPES = {'WALL', 'WALL_OPEN'}
OPEN_TYPES = {'OPEN', 'WALL_OPEN'}
FLOOR_TYPES = {'BASE', 'OPEN', 'TALL'}


def effective_base_type(d):
    """Wall units cannot have floor supports; floor units may choose None."""
    if d['cabinet_type'] in WALL_TYPES:
        return 'NONE'
    return d.get('base_type', 'PLINTH' if d.get('show_plinth',True) else 'NONE')


def support_height(d):
    """Vertical distance between cabinet bottom and carcass bottom, in mm."""
    return d['plinth_height'] if effective_base_type(d) != 'NONE' else 0.0


def body_height(d):
    """Overall Cabinet Height includes plinth/legs, but not FFL installation elevation."""
    return d['height'] - support_height(d)


def cabinet_bottom_ffl(d):
    """Bottom of installation, measured from finished floor (Z=0)."""
    return float(d.get('installation_height',0.0))


def validate(d):
    for key, value in COMPAT_DEFAULTS.items():
        d.setdefault(key, value)
    w, dep, t, b = (d[k] for k in ('width','depth','carcass_thickness','back_thickness'))
    h = body_height(d)
    v, r = int(d['vertical_divisions']), int(d['horizontal_divisions'])
    if d['installation_height'] < 0: raise ValueError('Installation height cannot be below FFL')
    if d['cabinet_type'] not in FLOOR_TYPES | WALL_TYPES: raise ValueError('Unknown cabinet type')
    if d['base_type'] not in ('NONE','PLINTH','LEGS'): raise ValueError('Unknown base type')
    if w <= 2*t+20: raise ValueError('Width must exceed twice carcass thickness + 20mm')
    if dep <= b+d['back_inset']+30: raise ValueError('Depth too small for backboard and inset')
    if h <= 2*t+30: raise ValueError('Overall height minus base support is too small for the carcass')
    if effective_base_type(d) != 'NONE':
        if effective_base_type(d)=='PLINTH' and d['plinth_setback']*2+2*t >= dep:
            raise ValueError('Plinth setback is too large for cabinet depth')
        if effective_base_type(d)=='LEGS' and (w < 130 or dep < 130):
            raise ValueError('Cabinet is too small for four adjustable feet')
    bay_w = (w - 2*t - v*t)/(v+1)
    bay_h = (h - 2*t - r*t)/(r+1)
    if bay_w <= 35: raise ValueError('Too many vertical divisions for cabinet width')
    if bay_h <= 35: raise ValueError('Too many horizontal divisions for cabinet height')
    if d['shelf_count'] and bay_w <= 2*d['shelf_clearance']+20:
        raise ValueError('Compartments too narrow for adjustable shelves')
    if d['shelf_count'] * (v+1) * (r+1) > 300:
        raise ValueError('Too many shelves (max 300 across all compartments)')
    sinks=active_sink_specs(d)
    if sinks and d['cabinet_type'] in FLOOR_TYPES:
        if not d.get('include_countertop',True):
            raise ValueError('Enable Kitchen Countertop to include a sink')
        if d['countertop_cost_basis'] not in ('GROSS','NET'):
            raise ValueError('Unknown countertop pricing basis')
        if len(sinks)>2:
            raise ValueError('Maximum 2 sink models per kitchen layout')
        ct_w=w+2*d['countertop_side_overhang']
        ct_d=dep+d['countertop_front_overhang']
        ct_y=-d['countertop_front_overhang']/2
        top_recess=min(35.0,dep*.20) if d.get('use_nose_gap') else 0.0
        top_y=top_recess/2
        holes=[]
        for spec in sinks:
            ox,oy,sw,sd=sink_cutout_info(d,spec)
            if sw<=50 or sd<=50 or float(spec['bowl_depth'])<=0:
                raise ValueError('Sink width, depth and bowl depth must be positive')
            # 35mm minimum border provides room for a real installation rim.
            if abs(ox)+sw/2+35 > ct_w/2 or abs(oy-ct_y)+sd/2+35 > ct_d/2:
                raise ValueError(f"Sink {spec['index']} too close to countertop edge")
            # Both sinks cut through the carcass top board as well.
            if abs(ox)+(sw+20)/2+12 > (w-2*t)/2 or \
               abs(oy-top_y)+(sd+20)/2+12 > (dep-top_recess)/2:
                raise ValueError(f"Sink {spec['index']} too close to cabinet top edge")
            holes.append((ox,oy,sw,sd))
        if len(holes)==2:
            x1,y1,w1,d1=holes[0]
            x2,y2,w2,d2=holes[1]
            # At least 35mm between two sink rims, including diagonal placement.
            if abs(x1-x2)<(w1+w2)/2+35 and abs(y1-y2)<(d1+d2)/2+35:
                raise ValueError('Two sinks overlap or are too close; move Sink 2')
    # Backward compatible: old saved cabinets used a single horizontal door count.
    # Door columns run left/right; door rows are stacked bottom/top.
    if d.get('front_style', 'OPEN' if d['cabinet_type'] in OPEN_TYPES else 'CLOSED') == 'OPEN':
        d['door_columns']=0
        d['door_rows']=0
        d['door_count']=0
    else:
        columns=int(d['door_columns'])
        rows=int(d['door_rows'])
        if columns < 1 or rows < 1:
            raise ValueError('Door Columns and Door Rows must each be at least 1')
        if columns * rows > 64:
            raise ValueError('Maximum 64 doors per cabinet')
        gap=d['door_gap']
        door_w=(w-(columns+1)*gap)/columns
        nose_h=d['nose_gap_height'] if d['use_nose_gap'] else 0
        door_h=(h-(rows+1)*gap-rows*nose_h)/rows
        if door_w <= 35: raise ValueError('Too many door columns for cabinet width')
        if door_h <= 50: raise ValueError('Too many door rows or Nose Gap too large')
        style=d.get('door_style','FLAT')
        if style not in ('FLAT','SHAKER_RECESSED','SHAKER_GLASS','SHAKER_DOUBLE'):
            raise ValueError('Unknown door panel style')
        if style != 'FLAT':
            fw=float(d['shaker_frame_width'])
            panel_rows=2 if style=='SHAKER_DOUBLE' else 1
            if fw < 15.0 or door_w-2*fw < 25.0 or (door_h-(panel_rows+1)*fw)/panel_rows < 25.0:
                raise ValueError('Shaker frame width too large for door size; reduce Frame Width or number of doors')
            if not (0.0 < d['shaker_recess_depth'] < t-1.0):
                raise ValueError('Shaker recess must be smaller than the door thickness')
            if style=='SHAKER_GLASS' and d['shaker_glass_thickness'] > t:
                raise ValueError('Shaker glass thickness cannot exceed door thickness')
        d['door_count']=columns*rows  # legacy-compatible total, not the UI control
    if d.get('enable_drawers',False):
        if d['cabinet_type'] in WALL_TYPES or d['front_style']=='OPEN':
            raise ValueError('Pull-out drawers require a closed kitchen base cabinet')
        # Door rows and fixed horizontal partitions belong to the *swing-door*
        # bays. A drawer bank spans its complete vertical bay and does not
        # receive those fixed partitions. The number of drawer fronts remains
        # independently adjustable for each drawer bank.
        if d['vertical_divisions'] != d['door_columns']-1:
            raise ValueError('Drawers require vertical dividers = door columns - 1')
        g=compartment_geometry(d)
        box_t=float(d['drawer_box_thickness'])
        clearance=float(d['drawer_slide_clearance'])
        inner_width=g['bay_w']-2*clearance
        body_depth=float(d['drawer_depth'])
        if inner_width <= 2*box_t+35:
            raise ValueError('Drawer bay too narrow for slides and drawer box panels')
        if body_depth > g['usable_depth']-30 or body_depth < 120:
            raise ValueError('Drawer depth must be 120mm to usable depth minus 30mm')
        seen=set()
        for bank in configured_drawer_banks(d):
            col=int(bank['column'])
            if col<1 or col>int(d['door_columns']):
                raise ValueError(f'Drawer column {col} outside run (1-{d["door_columns"]}). Adjust the drawer bank column')
            if col in seen:
                raise ValueError(f'More than one drawer bank assigned to column {col}; select another column')
            seen.add(col)
            count=int(bank['count'])
            if count<1 or count>6:
                raise ValueError('Each drawer bank must contain 1-6 drawers')
            face_height=(h-(count+1)*d['door_gap']-
                         (d['nose_gap_height'] if d['use_nose_gap'] else 0))/count
            if face_height < 90 or face_height <= 2*box_t+30:
                raise ValueError(f'Too many drawers in column {col} for available cabinet height')
            for idx,pull in enumerate(bank['pulls'][:count],1):
                if not 0<=float(pull)<=drawer_safe_travel_mm(body_depth)+1e-5:
                    raise ValueError(f'Column {col}, drawer {idx}: Pull-out exceeds safe travel')
            bay_center=g['bay_centers_x'][col-1]
            for sink in active_sink_specs(d):
                sx=float(sink['x_offset'])
                if abs(sx-bay_center) < (float(sink['width'])+g['bay_w'])/2+15:
                    raise ValueError(f'Sink intersects drawer column {col}; move the sink or drawer bank')
    return d


def compartment_geometry(d):
    w, dep, t, b = (d[k] for k in ('width','depth','carcass_thickness','back_thickness'))
    h = body_height(d)
    v, r = int(d['vertical_divisions']), int(d['horizontal_divisions'])
    inner_w, inner_h = w-2*t, h-2*t
    bay_w=(inner_w-v*t)/(v+1)
    bay_h=(inner_h-r*t)/(r+1)
    usable_depth=dep-d['back_inset']-b
    back_y=dep/2-d['back_inset']-b/2
    inner_front_y=-dep/2
    inner_back_y=back_y-b/2
    shelf_y=(inner_front_y+inner_back_y)/2
    bay_centers_x=[-inner_w/2+(i+.5)*bay_w+i*t for i in range(v+1)]
    div_centers_x=[-inner_w/2+(i+1)*bay_w+(i+.5)*t for i in range(v)]
    row_centers_z=[t+(j+.5)*bay_h+j*t for j in range(r+1)]
    horizontal_centers_z=[t+(j+1)*bay_h+(j+.5)*t for j in range(r)]
    return locals()


def drawer_safe_travel_mm(depth):
    """Maximum physically modeled travel: leave at least 35 mm of runner engagement."""
    depth=max(0.0,float(depth))
    return max(0.0,min(900.0, depth-35.0, depth*0.95))


def configured_drawer_banks(d):
    """Build the active drawer-bank recipe for 3D and BOQ.

    Older v4.5/v4.6 projects may still use the single-bank settings. These
    continue to load. The UI migrates them to individual independent pulls.
    V4.7 intentionally models ONLY handle-operated full-extension runners.
    """
    if not d.get('enable_drawers',False):
        return []
    max_travel=drawer_safe_travel_mm(d['drawer_depth'])
    if d.get('drawer_multi_bank_mode',False):
        return [dict(column=int(b['column']),count=int(b['count']),
                     hardware='HANDLE',
                     pulls=[min(max(0.0,float(v)),max_travel)
                            for v in b.get('pulls',[0.0]*6)])
                for b in d.get('drawer_banks',[])]
    return [dict(column=int(d['drawer_column']),count=int(d['drawer_count']),
                 hardware='HANDLE',
                 pulls=[min(max(0.0,float(d['drawer_extension'])),max_travel)]*int(d['drawer_count']))]


def drawer_bank_columns(d):
    return {b['column'] for b in configured_drawer_banks(d)}


def fixed_horizontal_bays(d):
    """1-based bays allowed to contain fixed horizontal dividers.

    When a drawer occupies a door column its complete carcass-height volume
    must remain clear of fixed horizontal dividers. In drawer mode the
    vertical partitions must align with door seams, so bay N = door column N.
    For old non-drawer jobs, preserve the original r * (v + 1) model and BOQ.
    """
    return tuple(i for i in range(1, int(d['vertical_divisions'])+2)
                 if i not in drawer_bank_columns(d))


def drawer_specs(d):
    """3D and BOQ share exactly the same recipe; each drawer has own pull mm."""
    if not d.get('enable_drawers',False): return
    g=compartment_geometry(d)
    h=body_height(d)
    gap=float(d['door_gap'])
    top_gap=float(d['nose_gap_height']) if d['use_nose_gap'] else 0.0
    box_t=float(d['drawer_box_thickness'])
    bottom_t=float(d['drawer_bottom_thickness'])
    slide_clearance=float(d['drawer_slide_clearance'])
    outer_w=g['bay_w']-2*slide_clearance
    depth=float(d['drawer_depth'])
    door_w=(d['width']-(d['door_columns']+1)*gap)/d['door_columns']
    for bank in configured_drawer_banks(d):
        col=int(bank['column'])-1
        count=int(bank['count'])
        face_h=(h-(count+1)*gap-top_gap)/count
        front_cx=-d['width']/2+gap+door_w*(col+0.5)+gap*col
        bay_cx=g['bay_centers_x'][col]
        for n in range(count):
            ext=float(bank['pulls'][n])
            face_bottom=gap+n*(face_h+gap)
            center_z=face_bottom+face_h/2
            side_h=max(55.0,min(face_h-30.0,face_h*.72))
            z_bottom=max(d['carcass_thickness']+8.0,face_bottom+gap+10.0)
            if z_bottom+side_h>h-d['carcass_thickness']-8.0:
                side_h=max(45.0,h-d['carcass_thickness']-8.0-z_bottom)
            yield dict(index=n+1, front_x=front_cx,box_x=bay_cx,
                       front_y=-d['depth']/2-d['carcass_thickness']/2-ext,
                       face_h=face_h,face_z=center_z,box_z=z_bottom,side_h=side_h,
                       box_w=outer_w,box_d=depth,box_t=box_t,bottom_t=bottom_t,
                       ext=ext,drawer_column=col+1,hardware=bank['hardware'])


def calculate(d):
    d=validate(dict(d))
    g=compartment_geometry(d)
    w,dep,t,b=(d[k] for k in ('width','depth','carcass_thickness','back_thickness'))
    h=body_height(d)
    v,r=d['vertical_divisions'],d['horizontal_divisions']
    inner_w,inner_h=g['inner_w'],g['inner_h']
    bay_w,bay_h=g['bay_w'],g['bay_h']
    usable_depth=g['usable_depth']
    parts=[]
    def part(category, name, cut_l, cut_w, thick, qty, edges=(), unit='m2', rate=0.0, unit_qty=None):
        # A complete drawer takeover leaves zero hinged doors; omit empty
        # BOQ lines rather than exporting zero-quantity doors and hardware.
        if qty == 0:
            return
        edge_len = sum((cut_l if edge in ('L1','L2') else cut_w) for edge in edges)/1000 * qty
        area=cut_l*cut_w*qty/1e6 if unit=='m2' else 0.0
        quantity=(area if unit=='m2' else qty) if unit_qty is None else unit_qty
        cost=quantity*rate
        parts.append(dict(category=category,name=name,length_mm=round(cut_l,3),width_mm=round(cut_w,3),thickness_mm=thick,
                          pieces=qty,unit=unit,quantity=round(quantity,4),unit_rate=rate,material_cost=round(cost,2),
                          edge_m=round(edge_len,4),edge_sides=','.join(edges)))
    finish_rates={'WOOD':d['wood_laminate_rate'],'COLOR':d['color_laminate_rate']}
    carcass_rate=finish_rates[d['carcass_finish']]
    door_rate=finish_rates[d['door_finish']]
    # Option A: Top and bottom fit between full-height side panels.
    part('CARCASS',d['carcass_finish'].title()+' Laminate Side Panel',h,dep,t,2,('L1',),rate=carcass_rate)
    # A recessed top panel leaves finger access above the handleless door.
    top_recess = min(35.0, dep * .20) if d['door_count'] and d['use_nose_gap'] else 0.0
    part('CARCASS','Top Panel',inner_w,dep-top_recess,t,1,('L1',),rate=carcass_rate)
    part('CARCASS','Bottom Panel',inner_w,dep,t,1,('L1',),rate=carcass_rate)
    part('BACK',f"Back Panel (Matching Side Finish: {d['carcass_finish'].title()} / {d['carcass_tone'].title()})",inner_w,inner_h,b,1,rate=d['back_rate'])
    if v:
        part('CARCASS','Vertical Divider',inner_h,usable_depth,t,v,('L1',),rate=carcass_rate)
    if r:
        active_horizontal_bays=fixed_horizontal_bays(d)
        if active_horizontal_bays:
            part('CARCASS','Horizontal Divider',bay_w,usable_depth,t,
                 r*len(active_horizontal_bays),('L1',),rate=carcass_rate)
    if d['shelf_count']:
        n=d['shelf_count']*(v+1)*(r+1)
        part('CARCASS','Adjustable Shelf (per compartment)',bay_w-2*d['shelf_clearance'],usable_depth,t,n,('L1',),rate=carcass_rate)
        part('HARDWARE','Shelf Support',0,0,0,n*4,unit='pcs',rate=d['shelf_support_rate'])
    if d['door_count']:
        gap=d['door_gap']
        cols, rows=d['door_columns'],d['door_rows']
        dw=(w-(cols+1)*gap)/cols
        nose_h=d['nose_gap_height'] if d['use_nose_gap'] else 0
        dh=(h-(rows+1)*gap-rows*nose_h)/rows
        # Every selected drawer column replaces ALL swing-door rows in that
        # column, not just one door. Keep BOQ, hinges and handles in sync.
        door_total=(cols-len(drawer_bank_columns(d)))*rows
        style=d.get('door_style','FLAT')
        if style=='FLAT':
            # Original slab doors and BOQ stay exactly as in v3.6.0.
            part('DOOR',f"{d['door_finish'].title()} Laminate Door Panel ({cols} columns x {rows} rows)",dh,dw,t,door_total,
                 ('L1','L2','W1','W2'),rate=door_rate)
        else:
            fw=d['shaker_frame_width']
            panel_rows=2 if style=='SHAKER_DOUBLE' else 1
            panel_h=(dh-(panel_rows+1)*fw)/panel_rows
            panel_w=dw-2*fw
            # Two full-height stiles, two perimeter rails, and optional center rail.
            # Edge banding adds up to the outer perimeter of the assembled door.
            part('DOOR','Shaker Vertical Stiles',dh,fw,t,2*door_total,
                 ('L1','W1','W2'),rate=door_rate)
            part('DOOR','Shaker Top & Bottom Rails',panel_w,fw,t,2*door_total,
                 ('L1',),rate=door_rate)
            if panel_rows==2:
                part('DOOR','Shaker Middle Rail',panel_w,fw,t,door_total,rate=door_rate)
            if style=='SHAKER_GLASS':
                part('GLASS','Shaker Glass Center Panel',panel_h,panel_w,
                     d['shaker_glass_thickness'],door_total,rate=d['shaker_glass_rate'])
            else:
                part('DOOR','Shaker Recessed Center Panel' if panel_rows==1 else 'Shaker Double Recessed Center Panels',
                     panel_h,panel_w,t-d['shaker_recess_depth'],panel_rows*door_total,rate=door_rate)
        part('HARDWARE','Hinge',0,0,0,door_total*d['hinges_per_door'],unit='pcs',rate=d['hinge_rate'])
        if d['show_handles'] and not d['use_nose_gap']:
            part('HARDWARE','Handle',0,0,0,door_total,unit='pcs',rate=d['handle_rate'])
        if d['use_nose_gap']:
            # One horizontal finger-pull rail behind the top of EACH door row.
            # In mixed drawer/door mode, rail segments are fitted only behind
            # swing-door bays. A full-width rail would intersect drawer boxes.
            rail_width=bay_w if drawer_bank_columns(d) else inner_w
            rail_segments=(len(fixed_horizontal_bays(d)) if drawer_bank_columns(d) else 1)
            if rail_segments:
                part('HARDWARE','Nose Gap Finger-Pull Rail (per door row)',
                     rail_width,0,0,rows*rail_segments,unit='m',
                     unit_qty=rail_width*rows*rail_segments/1000,
                     rate=d['nose_gap_rate'])
    if d.get('enable_drawers',False):
        face_w=(w-(d['door_columns']+1)*d['door_gap'])/d['door_columns']
        for bank in configured_drawer_banks(d):
            drs=[dr for dr in drawer_specs(d) if dr['drawer_column']==bank['column']]
            if not drs: continue
            n=len(drs); first=drs[0]; prefix=f'Drawer C{bank["column"]}'
            part('DRAWER_FRONT',prefix+' Flat Front (matching door finish)',first['face_h'],face_w,t,n,
                 ('L1','L2','W1','W2'),rate=door_rate)
            part('DRAWER_BOX',prefix+' Box Side Panels',first['box_d'],first['side_h'],first['box_t'],n*2,
                 ('L1',),rate=carcass_rate)
            inside_w=first['box_w']-2*first['box_t']
            part('DRAWER_BOX',prefix+' Box Front & Back',inside_w,first['side_h'],first['box_t'],n*2,
                 ('L1',),rate=carcass_rate)
            part('DRAWER_BOTTOM',prefix+' Bottom Panel',inside_w,first['box_d']-2*first['box_t'],
                 first['bottom_t'],n,rate=d['back_rate'])
            part('HARDWARE',prefix+' Full-Extension Slide Pair',0,0,0,n,
                 unit='pair',rate=d['drawer_slide_rate'])
            # v4.7 only offers handle-operated runners; legacy PUSH/NONE
            # projects load with handles instead of obsolete latch modes.
            part('HARDWARE',prefix+' Drawer Handle',0,0,0,n,
                 unit='pcs',rate=d['drawer_handle_rate'])
    if effective_base_type(d) != 'NONE':
        ph=d['plinth_height']
        if effective_base_type(d)=='PLINTH':
            t_plinth=18.0
            setback=d['plinth_setback']
            # Four vertical panels: all touch the floor (Z=0) and support the carcass at Z=ph.
            front_back_w=w-2*t_plinth
            side_len=dep-setback*2
            part('PLINTH','Front Toe-Kick Panel',front_back_w,ph,t_plinth,1,
                 unit='m',unit_qty=front_back_w/1000,rate=d['plinth_rate'])
            part('PLINTH','Rear Support Plinth',front_back_w,ph,t_plinth,1,
                 unit='m',unit_qty=front_back_w/1000,rate=d['plinth_rate'])
            part('PLINTH','Side Plinth Returns',side_len,ph,t_plinth,2,
                 unit='m',unit_qty=2*side_len/1000,rate=d['plinth_rate'])
        else:
            part('KICKSTAND','Adjustable Kickstand / Cabinet Foot',0,0,0,4,
                 unit='pcs',rate=d['kickstand_rate'])
    if d.get('include_countertop', True) and d['cabinet_type'] in FLOOR_TYPES:
        ct_w = w + 2*d['countertop_side_overhang']
        ct_d = dep + d['countertop_front_overhang']
        rates = {'TERRAZZO': d['countertop_terrazzo_rate'], 'COMPOSITE': d['countertop_composite_rate'],
                 'QUARTZ': d['countertop_quartz_rate'], 'GRANITE': d['countertop_granite_rate'], 'WOOD': d['wood_laminate_rate']}
        label = {'TERRAZZO': 'Terrazzo', 'COMPOSITE': 'Composite Solid Surface', 'QUARTZ': 'Engineered Quartz',
                 'GRANITE': 'Natural Granite', 'WOOD': 'Wood Laminate'}[d['countertop_material']]
        part('COUNTERTOP', label+' Countertop', ct_w, ct_d, d['countertop_thickness'], 1,
             rate=rates[d['countertop_material']])
        for spec in active_sink_specs(d):
            n=spec['index']
            sw,sd=float(spec['width']),float(spec['depth'])
            if d.get('countertop_cost_basis','GROSS')=='NET':
                # Deduct each individual opening only with NET contract pricing.
                part('COUNTERTOP',f'Sink {n} Opening Area Deduction (NET only)',
                     sw,sd,d['countertop_thickness'],1,
                     unit_qty=-sw*sd/1e6,rate=rates[d['countertop_material']])
            part('SINK',f'Sink {n} Supply (one basin)',0,0,0,1,
                 unit='pcs',rate=d['sink_unit_rate'])
            part('CUTOUT',f'Sink {n} Countertop Cutout / Fabrication',0,0,0,1,
                 unit='pcs',rate=d['sink_cutout_rate'])
            part('SINK',f'Sink {n} Installation / Sealant',0,0,0,1,
                 unit='pcs',rate=d['sink_install_rate'])
    if d['include_backsplash'] and d['cabinet_type'] in FLOOR_TYPES:
        part('BACKSPLASH','Backsplash Panel',w,d['backsplash_height'],d['backsplash_thickness'],1,
             rate=d['backsplash_rate'])
    if d['cabinet_type'] in WALL_TYPES:
        part('MOUNT','Wall Hanging Brackets',0,0,0,2,unit='pcs',rate=d['mount_bracket_rate'])
        part('MOUNT','Wall Mounting Rail',w,0,0,1,unit='m',unit_qty=w/1000,rate=d['mount_rail_rate'])
    filler_width=float(d.get('_corner_filler_width_mm',0.0))
    if filler_width>0.01:
        part('CARCASS','Corner Clearance Filler Panel',h,filler_width,t,1,
             ('L1','L2','W1','W2'),rate=carcass_rate)
    part('LABOR','Cabinet Assembly',0,0,0,1,unit='set',rate=d['labor_rate'])
    panel_cost=sum(p['material_cost'] for p in parts if p['category'] in ('CARCASS','BACK','DOOR','GLASS','BACKSPLASH','COUNTERTOP','DRAWER_FRONT','DRAWER_BOX','DRAWER_BOTTOM'))
    edge_m=sum(p['edge_m'] for p in parts)
    edge_cost=edge_m*d['edge_rate']
    waste=panel_cost*d['waste_percent']/100
    subtotal=sum(p['material_cost'] for p in parts)+edge_cost+waste
    totals={'panel_cost':round(panel_cost,2),'edge_m':round(edge_m,3),'edge_cost':round(edge_cost,2),
            'waste_cost':round(waste,2),'total':round(subtotal,2),'panel_area_m2':round(sum(p['quantity'] for p in parts if p['unit']=='m2'),3)}
    return d,parts,totals


def automatic_return_door_columns(d, run_width):
    """Match return leaf width to the main run, instead of making tiny leaves.

    E.g. a 2400 mm main run with 3 doors has ~800 mm leaves; an 850 mm
    return should have 1 leaf, not 3 leaves with just 1 interior divider.
    """
    main_columns=max(1, int(d['door_columns']))
    main_width=float(d['width'])
    # Use proportional module count to keep return and main leaf widths similar.
    # Floor/ceiling sizing from the original implementation could force 3
    # narrow doors on a return even while the carcass had only 2 compartments.
    return max(1, min(8, int(math.floor(run_width*main_columns/main_width+0.5))))


def _layout_modules_raw(d):
    """Layout with shared carcass depth and optional per-return detailing.

    Main run owns corners; return lengths include the main cabinet depth.
    All run BOQs and 3D objects use the same derived per-run settings.
    """
    d=dict(d)
    for key,value in COMPAT_DEFAULTS.items(): d.setdefault(key,value)
    shape=d.get('layout_shape','STRAIGHT')
    if shape not in ('STRAIGHT','L','U'):
        raise ValueError('Unknown cabinet layout')
    w,dep,t=d['width'],d['depth'],d['carcass_thickness']
    if shape=='STRAIGHT':
        if d.get('enable_drawers',False) and d.get('drawer_multi_bank_mode',False):
            if any(b['run']!='MAIN' for b in d.get('drawer_banks',[])):
                raise ValueError('Straight layout only supports drawer banks on MAIN')
        return [('MAIN',dict(d),0.0,0.0,0.0)]
    sides=([d.get('l_corner_side','LEFT')] if shape=='L' else ['LEFT','RIGHT'])
    if shape=='U' and w < 2*dep+2*t+40:
        raise ValueError('U layout: Main width must exceed twice the depth plus clearance')
    if shape=='L' and w < dep+2*t+40:
        raise ValueError('L layout: Main width must exceed depth plus clearance')
    available_runs=['MAIN']+sides
    if d.get('enable_drawers',False):
        if d.get('drawer_multi_bank_mode',False):
            if any(b['run'] not in available_runs for b in d.get('drawer_banks',[])):
                raise ValueError('One or more drawer bank runs do not exist in this layout')
        elif d.get('drawer_run','MAIN') not in available_runs:
            raise ValueError('Drawer run is not available in this layout')
    sinks=active_sink_specs(d)
    for spec in sinks:
        if spec['run'] not in available_runs:
            raise ValueError(f"Sink {spec['index']} run is not present in this L/U layout")
    primary=dict(d)
    if d.get('drawer_multi_bank_mode',False):
        primary['drawer_banks']=[dict(b) for b in d.get('drawer_banks',[]) if b['run']=='MAIN']
        primary['enable_drawers']=bool(d.get('enable_drawers',False)) and bool(primary['drawer_banks'])
    else:
        primary['enable_drawers']=bool(d.get('enable_drawers',False)) and d.get('drawer_run','MAIN')=='MAIN'
    # In L/U layouts, each door seam should correspond to an interior bay
    # boundary.  Keep the source UI properties untouched so saved projects and
    # straight cabinets retain their independent manual divider settings.
    align=bool(d.get('layout_align_dividers', True)) and d.get('front_style','CLOSED')!='OPEN'
    if align:
        primary['vertical_divisions']=max(0,int(primary['door_columns'])-1)
    # For curved-free modular L/U, construct the continuous perimeter
    # backsplash once at layout level, not separately on the three modules.
    primary['include_backsplash']=False
    primary['_sink_specs']=[spec for spec in sinks if spec['run']=='MAIN']
    primary['include_sink']=bool(primary['_sink_specs'])
    modules=[('MAIN',primary,0.0,0.0,0.0)]
    for side in sides:
        length=float(d['return_left_length' if side=='LEFT' else 'return_right_length'])
        filler_mm=float(d.get('_corner_filler_widths',{}).get(side,0.0))
        run=length-dep-filler_mm
        if run <= 2*t+40:
            raise ValueError(f'{side.title()} return must exceed cabinet depth by at least {2*t+40:g} mm')
        sub=dict(d)
        if d.get('drawer_multi_bank_mode',False):
            sub['drawer_banks']=[dict(b) for b in d.get('drawer_banks',[]) if b['run']==side]
            sub['enable_drawers']=bool(d.get('enable_drawers',False)) and bool(sub['drawer_banks'])
        else:
            sub['enable_drawers']=bool(d.get('enable_drawers',False)) and d.get('drawer_run','MAIN')==side
        sub['width']=run
        sub['_corner_filler_width_mm']=filler_mm
        sub['include_backsplash']=False
        sub['_sink_specs']=[spec for spec in sinks if spec['run']==side]
        sub['include_sink']=bool(sub['_sink_specs'])
        if d.get('customize_return_runs',False):
            suffix='left' if side=='LEFT' else 'right'
            for property_name in ('door_columns','door_rows','vertical_divisions','horizontal_divisions'):
                sub[property_name]=int(d[f'return_{suffix}_{property_name}'])
            selected_style=d[f'return_{suffix}_door_style']
            if selected_style!='INHERIT':
                sub['door_style']=selected_style
                sub['shaker_frame_width']=d[f'return_{suffix}_frame_width']
            # When alignment is enabled, the number of return door frames is
            # authoritative.  A return with N leaves has N-1 full-height
            # partitions; the manual divider input is used only when OFF.
            if align:
                sub['vertical_divisions']=max(0,int(sub['door_columns'])-1)
        else:
            # Scale by the main door width.  Always derive a matching number
            # of vertical partitions for auto returns (even in manual mode,
            # since there is no separate return override when this is off).
            sub['door_columns']=automatic_return_door_columns(d,run)
            sub['vertical_divisions']=(max(0,int(sub['door_columns'])-1)
                if d.get('front_style','CLOSED')!='OPEN'
                else min(int(d['vertical_divisions']),max(0,int(run//350)-1)))
        sub['layout_shape']='STRAIGHT'
        x=(-w/2+dep/2) if side=='LEFT' else (w/2-dep/2)
        y=-length/2-filler_mm/2
        angle=math.pi/2 if side=='LEFT' else -math.pi/2
        modules.append(('RETURN_'+side,sub,x,y,angle))
    return modules



def _corner_raw_with_fillers(d, widths):
    """Instantiate modules at the actual shortened return widths (mm)."""
    temp=dict(d,_corner_filler_widths=widths)
    modules=_layout_modules_raw(temp)
    # Legacy single-bank save-files get exactly one collision-test bank.
    normalized=[]
    for name,run,x,y,angle in modules:
        run=dict(run)
        if run.get('enable_drawers') and not run.get('drawer_multi_bank_mode'):
            col=int(run['drawer_column'])
            n=int(run['drawer_count'])
            travel=min(float(run['drawer_extension']),drawer_safe_travel_mm(run['drawer_depth']))
            run['drawer_banks']=[dict(column=col,count=n,hardware='HANDLE',pulls=[travel]*6)]
            run['drawer_multi_bank_mode']=True
        normalized.append((name,run,x,y,angle))
    return normalized


def corner_layout_plan(d):
    """Non-destructive per-junction clearance plan; disabled means v4.8.4 geometry.

    AUTO finds the smallest 5 mm filler increment that clears full slide
    design travel (independent of live pull sliders). If no filler can
    clear the motion, the active 3D motion is reduced, not the saved UI request.
    AABB envelopes intentionally err on the safe side for close-corner details.
    """
    if not d.get('corner_smart_enabled',False) or d.get('layout_shape','STRAIGHT')=='STRAIGHT':
        return dict(fill={},notes=[],modules=_layout_modules_raw(d))
    sides=[d.get('l_corner_side','LEFT')] if d['layout_shape']=='L' else ['LEFT','RIGHT']
    minimum=max(0.,float(d.get('corner_min_filler_mm',45.)))
    maximum=max(minimum,float(d.get('corner_max_filler_mm',425.)))
    fillers={}
    notes=[]
    for side in sides:
        length=float(d['return_left_length' if side=='LEFT' else 'return_right_length'])
        # Reserve room for a return carcass and valid door front. A custom
        # multi-door return might require a wider minimum; validation handles it.
        remaining=length-float(d['depth'])
        max_available=max(0.,remaining-(2*float(d['carcass_thickness'])+85.))
        cap=min(maximum,max_available)
        lower=min(minimum,cap)
        if d.get('corner_auto_filler',True):
            chosen=cap
            # Try the minimum first, increasing in 5 mm increments.
            values=[lower]
            candidate=math.ceil(lower/5)*5
            while candidate<cap-0.1:
                if candidate>lower+0.1: values.append(float(candidate))
                candidate+=5
            if cap not in values: values.append(cap)
            for width in values:
                temp={**fillers,side:width}
                trial=_corner_raw_with_fillers(d,temp)
                # Size against the installed slide's FULL design extension,
                # not the current animation slider. Dragging a drawer must
                # NOT change the cabinet widths or the BOQ quantities.
                design=[]
                for nm,unit,ux,uy,ang in trial:
                    unit=dict(unit,door_open_angle=0.)
                    if unit.get('enable_drawers'):
                        target=drawer_safe_travel_mm(unit['drawer_depth'])
                        unit['drawer_banks']=[dict(bank,pulls=[target]*6)
                                              for bank in unit.get('drawer_banks',[])]
                    design.append((nm,unit,ux,uy,ang))
                # Only evaluate this corner; swing angle is capped separately
                # by its actual live value once filler dimensions are fixed.
                relevant=[m for m in design if m[0] in ('MAIN','RETURN_'+side)]
                if not corner_safety.problems(relevant,d,{side:width}):
                    chosen=width
                    break
            fillers[side]=round(chosen,3)
        else:
            wanted=float(d.get('corner_manual_'+side.lower()+'_mm',45.))
            fillers[side]=round(min(max(0.,wanted),cap),3)
            if fillers[side]+0.01 < wanted:
                notes.append(f'{side} filler capped by available return length')
    modules=_corner_raw_with_fillers(d,fillers)
    modules,clamps=corner_safety.enforce(modules,d,fillers)
    notes.extend(clamps)
    for side,f in fillers.items():
        notes.insert(0,f'{side} corner filler: {f:.0f} mm')
    return dict(fill=fillers,notes=notes,modules=modules)


def layout_modules(d):
    return corner_layout_plan(d)['modules']


def calculate_layout(d):
    """Add all run cut lists, retaining which run each BOQ component belongs to."""
    modules=layout_modules(d)
    all_parts=[]
    totals={'panel_cost':0.0,'edge_m':0.0,'edge_cost':0.0,'waste_cost':0.0,
            'total':0.0,'panel_area_m2':0.0}
    for name, run, _, _, _ in modules:
        _, parts, sub_totals=calculate(run)
        for item in parts:
            part=dict(item)
            if len(modules)>1: part['name']=name.replace('_',' ').title()+' | '+part['name']
            all_parts.append(part)
        for key in totals: totals[key]+=sub_totals[key]
    for label,center,dims,linear_mm in layout_backsplash_segments(d):
        area=linear_mm*d['backsplash_height']/1e6
        cost=area*d['backsplash_rate']
        all_parts.append(dict(category='BACKSPLASH',name=label+' | Backsplash Panel',
            length_mm=round(linear_mm,3),width_mm=d['backsplash_height'],
            thickness_mm=d['backsplash_thickness'],pieces=1,unit='m2',
            quantity=round(area,4),unit_rate=d['backsplash_rate'],
            material_cost=round(cost,2),edge_m=0.0,edge_sides=''))
        totals['panel_cost']+=cost
        totals['panel_area_m2']+=area
        waste=cost*d['waste_percent']/100
        totals['waste_cost']+=waste
        totals['total']+=cost+waste
    totals={key:round(value,3 if key in ('edge_m','panel_area_m2') else 2)
            for key,value in totals.items()}
    return dict(d),all_parts,totals




def validate_model_report(base, wall, kitchen_enabled=True, wall_enabled=True):
    """Non-destructive parameter/BOQ validation; returns structured findings.

    ERROR: geometry/BOQ construction fails. WARNING: physically questionable
    construction requiring review. INFO: useful nonblocking configuration notes.
    Does not create, change, or remove any Blender meshes or user settings.
    """
    findings=[]
    def add(severity,unit,run,message):
        findings.append(dict(severity=severity,unit=unit,run=run,message=message))

    for unit, original, enabled in (('Kitchen',base,kitchen_enabled),('Wall',wall,wall_enabled)):
        if not enabled:
            add('INFO',unit,'ALL','Disabled; not included in validation or BOQ')
            continue
        d=dict(original)
        try:
            modules=layout_modules(d)
        except (ValueError, KeyError, TypeError, ZeroDivisionError) as exc:
            add('ERROR',unit,'LAYOUT',str(exc))
            continue
        validated=[]
        for run_name, run, _, _, _ in modules:
            try:
                checked,parts,totals=calculate(run)
                validated.append((run_name,checked,parts,totals))
            except (ValueError, KeyError, TypeError, ZeroDivisionError) as exc:
                add('ERROR',unit,run_name,str(exc))
                continue
            if checked['front_style']=='CLOSED':
                cols=int(checked['door_columns'])
                divisions=int(checked['vertical_divisions'])
                if divisions != cols-1:
                    add('WARNING',unit,run_name,
                        f'{cols} door columns / {divisions} vertical dividers: '
                        f'consider {cols-1} dividers to align door seams')
                leaf_width=(checked['width']-(cols+1)*checked['door_gap'])/cols
                if leaf_width > 650:
                    add('WARNING',unit,run_name,
                        f'Door leaf ~{leaf_width:.0f} mm wide; verify hinge load and manufacturer limits')
                if leaf_width < 250:
                    add('WARNING',unit,run_name,
                        f'Door leaf ~{leaf_width:.0f} mm wide; verify hardware and access')
                if checked['door_open_angle']>0 and checked['layout_shape']=='STRAIGHT' and d.get('layout_shape') in ('L','U'):
                    add('INFO',unit,run_name,
                        'Open return doors: visually verify corner clearance against adjacent cabinet')
            # Compare sink cutout with internal vertical partitions. The sink
            # is cut through the top, but cabinet divisions are not trimmed.
            if checked['cabinet_type'] in FLOOR_TYPES:
                specs=active_sink_specs(checked)
                if specs:
                    geo=compartment_geometry(checked)
                    board_t=float(checked['carcass_thickness'])
                    for spec in specs:
                        ox,oy,sw,sd=sink_cutout_info(checked,spec)
                        for divider_x in geo['div_centers_x']:
                            if abs(ox-divider_x)<sw/2+board_t/2+10:
                                add('WARNING',unit,run_name,
                                    f"Sink {spec['index']} cutout crosses vertical divider at "
                                    f'X={divider_x:.0f} mm; check basin/carcass clearance')
                                break
                        # Sink models extend below the top; a fixed shelf or
                        # partition at the top may interfere with basin depth.
                        bowl=float(spec['bowl_depth'])
                        if bowl>body_height(checked)-2*board_t:
                            add('WARNING',unit,run_name,
                                f"Sink {spec['index']} bowl depth exceeds usable cabinet height")
            if checked.get('include_backsplash') and checked['cabinet_type'] in FLOOR_TYPES:
                if checked.get('backsplash_height',0)<=0 or checked.get('backsplash_thickness',0)<=0:
                    add('ERROR',unit,run_name,'Backsplash height and thickness must be positive')
            if totals['total']<0 or not math.isfinite(totals['total']):
                add('ERROR',unit,run_name,'Invalid BOQ total')

        if len(validated)!=len(modules):
            add('ERROR',unit,'BOQ','One or more runs could not be calculated')
            continue
        try:
            _,all_parts,layout_totals=calculate_layout(d)
            if not math.isfinite(layout_totals['total']) or layout_totals['total']<0:
                add('ERROR',unit,'BOQ','Combined BOQ total is invalid')
            # Verify no duplicated backsplash line items in the BOQ.
            backsplash=[x for x in all_parts if x['category']=='BACKSPLASH']
            if d.get('layout_shape') in ('L','U') and d.get('include_backsplash') and d['cabinet_type'] in FLOOR_TYPES:
                expected=len(layout_backsplash_segments(d))
                if len(backsplash)!=expected:
                    add('ERROR',unit,'BOQ',
                        f'Expected {expected} backsplash segments but BOQ contains {len(backsplash)}')
                names=[x['name'] for x in backsplash]
                if len(set(names))!=len(names):
                    add('ERROR',unit,'BOQ','Duplicate backsplash segment names in BOQ')
            for item in all_parts:
                if item['pieces']<0 or ((item['quantity']<0 or item['material_cost']<0) and not (item['category']=='COUNTERTOP' and 'Deduction (NET only)' in item['name'])):
                    add('ERROR',unit,'BOQ','Unexpected negative quantity or material cost: '+item['name'])
                    break
            if d.get('layout_shape') in ('L','U'):
                add('INFO',unit,'CORNERS',
                    'Modular returns share plan corners; visually confirm fillers, door swing and panel junctions')
                if d.get('corner_smart_enabled',False):
                    safety=corner_layout_plan(d)
                    for side,mm in safety['fill'].items():
                        add('INFO',unit,'CORNER FILLER',f'{side}: {mm:.1f} mm filler counted in BOQ')
                    for note in safety['notes']:
                        if 'safe pull' in note or 'swing C' in note or 'capped' in note:
                            add('WARNING',unit,'CORNER CLEARANCE',note)
                for warning in layout_drawer_collision_warnings(d):
                    add('WARNING',unit,'DRAWER CORNER',warning)
        except (ValueError, KeyError, TypeError, ZeroDivisionError) as exc:
            add('ERROR',unit,'BOQ',str(exc))

    if kitchen_enabled and wall_enabled:
        if wall['installation_height'] < base['installation_height']+base['height']:
            add('WARNING','Kitchen + Wall','ELEVATION',
                'Wall cabinet bottom is below the kitchen cabinet top; check vertical overlap')
        elif (wall['installation_height'] - (base['installation_height']+base['height']))<300:
            add('WARNING','Kitchen + Wall','ELEVATION',
                'Vertical clearance above kitchen cabinet is under 300 mm; review worktop accessibility')
    return findings


def make_layout(parent, d, cab_id, preview=False):
    """Keep legacy straight cabinet unchanged; compose rotated returns for L/U."""
    modules=layout_modules(d)
    if len(modules)==1:
        return make_cabinet(parent,d,cab_id,preview)
    _,all_parts,totals=calculate_layout(d)
    root=collection(('PREVIEW_'+cab_id if preview else cab_id),parent)
    root['igz_cabinet_id']=cab_id
    root['igz_layout_root']=True
    root['igz_params']=json.dumps(d)
    root['igz_price_snapshot_thb']=json.dumps({k: float(d[k]) for k in PRICE_RATE_KEYS if k in d})
    root['igz_boq']=json.dumps(all_parts)
    root['igz_totals']=json.dumps(totals)
    root['igz_preview']=preview
    root['igz_placement_y_mm']=0.0
    for name,run,x,y,angle in modules:
        sub, _=make_cabinet(root,run,cab_id+'_'+name,preview)
        transform=Matrix.Translation(Vector((x/1000.0,y/1000.0,0.0))) @ Matrix.Rotation(angle,4,'Z')
        for obj in sub.objects:
            # Mesh vertices use local cabinet coordinates. Matrix locates each
            # module without changing any local door/hinge geometry.
            obj.matrix_world=transform @ obj.matrix_world
            if obj.name.startswith('Drawer_'):
                obj['igz_drawer_run']=name
                # Traceable 3D objects for main/left/right BOQ inspection.
                obj['igz_drawer_column']=int(obj.name.split('_')[1][1:])
        sub['igz_module_name']=name
    # Separate, finish-matched vertical filler panels at each corner junction.
    # The return itself is shortened by the same width in _layout_modules_raw.
    for side in (['LEFT','RIGHT'] if d.get('layout_shape')=='U' else
                 [d.get('l_corner_side','LEFT')]):
        matching=next((run for name,run,*_ in modules if name=='RETURN_'+side),None)
        if not matching: continue
        f=float(matching.get('_corner_filler_width_mm',0.0))
        if f<=0.01: continue
        t=float(d['carcass_thickness']); dep=float(d['depth']); w=float(d['width'])
        inside=(-w/2+dep) if side=='LEFT' else (w/2-dep)
        cx=inside-t/2 if side=='LEFT' else inside+t/2
        fy=-dep/2-f/2
        hz=body_height(d)
        z=cabinet_bottom_ffl(d)+support_height(d)+hz/2
        fill_c=collection(cab_id+'_SMART_CORNER_FILLERS',root)
        obj=cube(fill_c,'Corner_Filler_'+side,(cx,fy,z),(t,f,hz),'CARCASS',{
            'finish_type':d['carcass_finish'],'finish_tone':d['carcass_tone'],
            'finish_role':'CARCASS','component_type':'Corner Filler',
            'material_code':'CARCASS','cabinet_id':cab_id,
            'cut_length_mm':round(hz,3),'cut_width_mm':round(f,3),
            'thickness_mm':round(t,3),'is_preview':preview,
            'igz_corner_filler_side':side})
    for idx,(label,center,dims,length) in enumerate(layout_backsplash_segments(d)):
        bs_c=collection(cab_id+'_CONTINUOUS_BACKSPLASH',root)
        bs_c['igz_cabinet_id']=cab_id
        bs_c['igz_preview']=preview
        obj=cube(bs_c,'Backsplash_'+label.replace(' ','_'),center,dims,'BACKSPLASH',{
            'cabinet_id':cab_id,'component_type':'Backsplash',
            'material_code':'BACKSPLASH','is_preview':preview,
            'cut_length_mm':round(length,3),
            'cut_width_mm':d['backsplash_height'],
            'thickness_mm':d['backsplash_thickness']})
    return root,totals


def currency_settings(scene):
    """Return (ISO currency, THB per selected currency unit). Manual rate."""
    ensure_price_library(scene)
    p=scene.igz_price_library
    code=p.boq_currency
    if code=='SGD': return code, max(0.000001,float(p.fx_thb_per_sgd))
    if code=='USD': return code, max(0.000001,float(p.fx_thb_per_usd))
    return 'THB',1.0


def money_label(scene, amount_thb):
    currency, divisor=currency_settings(scene)
    return f'{currency} {amount_thb/divisor:,.2f}'


def make_cabinet(parent, d, cab_id, preview=False):
    d,parts,totals=calculate(d)
    g=compartment_geometry(d)
    w,dep,t,b=(d[k] for k in ('width','depth','carcass_thickness','back_thickness'))
    h=body_height(d)
    inner_w,inner_h=g['inner_w'],g['inner_h']
    bay_w,bay_h=g['bay_w'],g['bay_h']
    usable_depth=g['usable_depth']
    shelf_y=g['shelf_y']
    # Give each preview cabinet its own collection: moving the wall cabinet
    # must never move the kitchen model or overwrite its preview metadata.
    c=collection(('PREVIEW_' + cab_id if preview else cab_id),parent)
    c['igz_cabinet_id']=cab_id
    c['igz_params']=json.dumps(d)
    c['igz_price_snapshot_thb']=json.dumps({k: float(d[k]) for k in PRICE_RATE_KEYS if k in d})
    c['igz_boq']=json.dumps(parts)
    c['igz_totals']=json.dumps(totals)
    c['igz_preview']=preview
    c['igz_floor_z_mm']=0.0
    c['igz_installation_height_mm']=cabinet_bottom_ffl(d)
    c['igz_cabinet_top_ffl_mm']=cabinet_bottom_ffl(d)+d['height']
    c['igz_base_support_height_mm']=support_height(d)
    c['igz_overall_height_mm']=d['height']
    base_z=support_height(d)
    install_z=cabinet_bottom_ffl(d)
    idx=0
    def piece(label, pos, dims, key, cut_l,cut_w,thick,edge_sides='', leaf_id=None):
        nonlocal idx
        idx+=1
        # All carcass / doors / hardware sit ABOVE the floor-mounted base support.
        pos=(pos[0],pos[1],pos[2]+install_z+(0 if key in ('PLINTH','KICKSTAND') else base_z))
        finish_role = 'DOOR' if key=='DOOR' else 'CARCASS' if key in ('CARCASS', 'BACK') else 'COUNTERTOP' if key=='COUNTER_WOOD' else None
        finish_meta = ({'finish_type':d['door_finish'] if key=='DOOR' else 'WOOD' if key=='COUNTER_WOOD' else d['carcass_finish'],
                        'finish_tone':d['door_tone'] if key=='DOOR' else d['carcass_tone'],
                        'finish_role':finish_role} if finish_role else {})
        obj=cube(c, label, pos,dims,key,{**finish_meta,
            'component_id':f'{cab_id}_{idx:03d}', 'cabinet_id':cab_id,
            'component_type':label.split('_')[0], 'material_code':key,
            'cut_length_mm':round(cut_l,3),'cut_width_mm':round(cut_w,3),
            'thickness_mm':thick,'edge_sides':edge_sides,'is_preview':preview})
        if leaf_id is not None:
            obj['igz_door_leaf']=leaf_id
        return obj
    piece('Side_Left',(-w/2+t/2,0,h/2),(t,dep,h),'CARCASS',h,dep,t,'L1')
    piece('Side_Right',(w/2-t/2,0,h/2),(t,dep,h),'CARCASS',h,dep,t,'L1')
    top_recess = min(35.0, dep * .20) if d['door_count'] and d['use_nose_gap'] else 0.0
    sinks=active_sink_specs(d) if d['cabinet_type'] in FLOOR_TYPES else []
    if sinks:
        idx+=1
        top_holes=[]
        for spec in sinks:
            sx,sy,sw,sd=sink_cutout_info(d,spec)
            top_holes.append((sx,sy-top_recess/2,sw+20,sd+20))
        panel_with_sink_cutouts(c,'Top_Panel',(0,top_recess/2,
            h-t/2+install_z+base_z),(inner_w,dep-top_recess,t),
            top_holes,'CARCASS',{
                'finish_type':d['carcass_finish'],'finish_tone':d['carcass_tone'],
                'finish_role':'CARCASS','component_id':f'{cab_id}_{idx:03d}',
                'cabinet_id':cab_id,'component_type':'Top','material_code':'CARCASS',
                'cut_length_mm':inner_w,'cut_width_mm':dep-top_recess,
                'thickness_mm':t,'edge_sides':'L1','is_preview':preview})
    else:
        piece('Top_Panel',(0,top_recess/2,h-t/2),(inner_w,dep-top_recess,t),'CARCASS',inner_w,dep-top_recess,t,'L1')
    piece('Bottom_Panel',(0,0,t/2),(inner_w,dep,t),'CARCASS',inner_w,dep,t,'L1')
    back_y=g['back_y']
    piece('Back_Panel',(0,back_y,h/2),(inner_w,b,inner_h),'BACK',inner_w,inner_h,b)
    # Structural vertical partitions run between the top and bottom, not through them.
    for i,x in enumerate(g['div_centers_x']):
        piece(f'Vertical_Divider_{i+1:02d}',(x,shelf_y,h/2),(t,usable_depth,inner_h),'CARCASS',inner_h,usable_depth,t,'L1')
    # A bank of drawers must have its entire vertical storage cavity clear.
    # Build fixed horizontal partitions only in the remaining swing-door bays.
    # This mirrors the actual panel quantities in calculate().
    horizontal_bays=set(fixed_horizontal_bays(d))
    for j,z in enumerate(g['horizontal_centers_z']):
        for i,x in enumerate(g['bay_centers_x']):
            if (i+1) not in horizontal_bays:
                continue
            piece(f'Horizontal_Divider_R{j+1:02d}_C{i+1:02d}',(x,shelf_y,z),(bay_w,usable_depth,t),'CARCASS',bay_w,usable_depth,t,'L1')
    # Adjustable shelves are generated independently inside every compartment.
    for j,row_z in enumerate(g['row_centers_z']):
        row_low=row_z-bay_h/2
        for i,x in enumerate(g['bay_centers_x']):
            for k in range(d['shelf_count']):
                z=row_low+(k+1)*bay_h/(d['shelf_count']+1)
                shelf_width=bay_w-2*d['shelf_clearance']
                piece(f'Shelf_R{j+1:02d}_C{i+1:02d}_{k+1:02d}',(x,shelf_y,z),
                      (shelf_width,usable_depth,t),'CARCASS',shelf_width,usable_depth,t,'L1')
                for side in (-1,1):
                    for fb in (-1,1):
                        sx=x+side*(shelf_width/2-10)
                        sy=shelf_y+fb*(usable_depth/2-25)
                        piece(f'ShelfSupport_R{j+1:02d}_C{i+1:02d}_{k+1:02d}_{side}_{fb}',
                              (sx,sy,z-t/2-3),(8,12,6),'HARDWARE',0,0,0)
    if d['door_count']:
        drawers_in_columns=drawer_bank_columns(d)
        gap=d['door_gap']
        cols, rows=d['door_columns'],d['door_rows']
        nose_h=d['nose_gap_height'] if d['use_nose_gap'] else 0
        door_w=(w-(cols+1)*gap)/cols
        door_h=(h-(rows+1)*gap-rows*nose_h)/rows
        front_y=-dep/2-t/2
        for row in range(rows):
            # Wall cabinets: finger recess BELOW each door row (bottom-edge pull).
            # Kitchen base cabinets retain the original top-edge finger recess.
            wall_bottom_nose = d['cabinet_type'] in WALL_TYPES and d['use_nose_gap']
            door_bottom=gap+row*(door_h+nose_h+gap)+(nose_h if wall_bottom_nose else 0)
            door_top=door_bottom+door_h
            z=door_bottom+door_h/2
            for col in range(cols):
                if col+1 in drawers_in_columns: continue
                x=-w/2+gap+door_w*(col+.5)+gap*col
                label=f'R{row+1:02d}_C{col+1:02d}'
                style=d.get('door_style','FLAT')
                if style=='FLAT':
                    piece(f'Door_{label}',(x,front_y,z),(door_w,t,door_h),
                          'DOOR',door_h,door_w,t,'L1,L2,W1,W2',leaf_id=label)
                else:
                    fw=d['shaker_frame_width']
                    panel_rows=2 if style=='SHAKER_DOUBLE' else 1
                    panel_width=door_w-2*fw
                    panel_height=(door_h-(panel_rows+1)*fw)/panel_rows
                    recess=d['shaker_recess_depth']
                    # Frame is full door thickness. The center panel's rear
                    # stays flush with the back, so its face is recessed.
                    for side,dx in [('L',-1),('R',1)]:
                        sx=x+dx*(door_w-fw)/2
                        piece(f'Door_{label}_Stile_{side}',(sx,front_y,z),(fw,t,door_h),
                              'DOOR',door_h,fw,t,leaf_id=label)
                    for side,dz in [('Bottom',-1),('Top',1)]:
                        sz=z+dz*(door_h-fw)/2
                        piece(f'Door_{label}_Rail_{side}',(x,front_y,sz),(panel_width,t,fw),
                              'DOOR',panel_width,fw,t,leaf_id=label)
                    if panel_rows==2:
                        piece(f'Door_{label}_Rail_Middle',(x,front_y,z),(panel_width,t,fw),
                              'DOOR',panel_width,fw,t,leaf_id=label)
                    for j in range(panel_rows):
                        pz=z if panel_rows==1 else z + (-1 if j==0 else 1)*(panel_height+fw)/2
                        if style=='SHAKER_GLASS':
                            glass_t=d['shaker_glass_thickness']
                            piece(f'Door_{label}_Glass_Center',(x,front_y,pz),(panel_width,glass_t,panel_height),
                                  'GLASS',panel_height,panel_width,glass_t,leaf_id=label)
                        else:
                            panel_t=t-recess
                            panel_y=-dep/2-panel_t/2
                            piece(f'Door_{label}_Recessed_Panel_{j+1:02d}',
                                  (x,panel_y,pz),(panel_width,panel_t,panel_height),
                                  'DOOR',panel_height,panel_width,panel_t,leaf_id=label)
                if d['show_handles'] and not d['use_nose_gap']:
                    # Pair adjacent door handles towards the middle of each pair.
                    handle_x=x+(door_w*.30 if col%2==0 else -door_w*.30)
                    piece(f'Handle_{label}',
                          (handle_x,front_y-t/2-8,door_bottom+door_h*.72),
                          (10,16,min(100,door_h*.5)),'HARDWARE',0,0,0,leaf_id=label)
                for j in range(d['hinges_per_door']):
                    margin=min(90,door_h*.25)
                    hinge_z=door_bottom+margin+j*max(0,door_h-2*margin)/max(1,d['hinges_per_door']-1)
                    hinge_x=x+(-door_w/2+18 if col%2==0 else door_w/2-18)
                    piece(f'Hinge_{label}_{j+1:02d}',(hinge_x,front_y+t/2+8,hinge_z),
                          (18,18,30),'HARDWARE',0,0,0)
            if d['use_nose_gap']:
                # Wall: recessed opening below door; kitchen: above door.
                rail_z=(door_bottom-nose_h/2) if wall_bottom_nose else (door_top+nose_h/2)
                if drawers_in_columns:
                    for col in fixed_horizontal_bays(d):
                        x=g['bay_centers_x'][col-1]
                        piece(f'Nose_Gap_Recess_Rail_R{row+1:02d}_C{col:02d}',
                              (x,-dep/2+16,rail_z),
                              (bay_w,12,nose_h),'NOSE_GAP',bay_w,0,0)
                else:
                    piece(f'Nose_Gap_Recess_Rail_R{row+1:02d}',
                          (0,-dep/2+16,rail_z),
                          (inner_w,12,nose_h),'NOSE_GAP',inner_w,0,0)
    # Independent drawer construction. Open/close is a translational slide,
    # unlike door rotation; stationary slide guides remain attached to carcass.
    if d.get('enable_drawers',False):
        for dr in drawer_specs(d):
            n=dr['index']; tag=f'Drawer_C{dr["drawer_column"]:02d}_{n:02d}'
            cx=dr['box_x']; z0=dr['box_z']; sh=dr['side_h']; thick=dr['box_t']
            bw=dr['box_w']; bd=dr['box_d']; bt=dr['bottom_t']; shift=dr['ext']
            y0=-dep/2+bd/2-shift
            piece(tag+'_Front',(dr['front_x'],dr['front_y'],dr['face_z']),
                  ((w-(d['door_columns']+1)*d['door_gap'])/d['door_columns'],t,dr['face_h']),
                  'DOOR',dr['face_h'],(w-(d['door_columns']+1)*d['door_gap'])/d['door_columns'],t,'L1,L2,W1,W2')
            for side,sgn in (('Left',-1),('Right',1)):
                sx=cx+sgn*(bw-thick)/2
                piece(tag+'_Box_Side_'+side,(sx,y0,z0+sh/2),(thick,bd,sh),
                      'CARCASS',bd,sh,thick,'L1')
                # Two-piece telescopic runner approximation: fixed cabinet
                # guide and moving slide member, priced together as one pair.
                guide_x=cx+sgn*(bw/2+max(3, float(d['drawer_slide_clearance'])/2))
                guide_z=z0+16
                piece(tag+'_Fixed_Runner_'+side,(guide_x,-dep/2+bd/2,guide_z),
                      (7,bd,18),'HARDWARE',0,0,0)
                piece(tag+'_Moving_Runner_'+side,(cx+sgn*(bw/2+2),y0,guide_z),
                      (5,bd*.88,13),'HARDWARE',0,0,0)
            cross_w=bw-2*thick
            for end,sgn in (('Front',-1),('Back',1)):
                piece(tag+'_Box_'+end,(cx,y0+sgn*(bd-thick)/2,z0+sh/2),
                      (cross_w,thick,sh),'CARCASS',cross_w,sh,thick,'L1')
            piece(tag+'_Bottom',(cx,y0,z0+bt/2),
                  (cross_w,bd-2*thick,bt),'BACK',cross_w,bd-2*thick,bt)
            piece(tag+'_Handle',(dr['front_x'],dr['front_y']-t/2-10,dr['face_z']),
                  (min(130.0,bw*.45),18,12),'HARDWARE',0,0,0)
    if effective_base_type(d) != 'NONE':
        ph=d['plinth_height']
        if effective_base_type(d)=='PLINTH':
            # Top of all plinth pieces is Z=ph; bottom is exactly Z=0.
            tp=18.0
            setback=d['plinth_setback']
            front_y=-dep/2+setback
            rear_y=dep/2-setback
            span_y=rear_y-front_y
            for label,yy in [('Front_Toe_Kick',front_y),('Rear_Plinth',rear_y)]:
                piece(label,(0,yy,ph/2),(w-2*tp,tp,ph),'PLINTH',w-2*tp,ph,tp)
            for label,xx in [('Left_Plinth_Return',-w/2+tp/2),('Right_Plinth_Return',w/2-tp/2)]:
                piece(label,(xx,(front_y+rear_y)/2,ph/2),(tp,span_y,ph),'PLINTH',span_y,ph,tp)
        else:
            # Four adjustable support feet. Pads contact floor at Z=0.
            # Support columns extend from the pads to the underside of the carcass.
            inset=65.0
            for side,x in [('L',-w/2+inset),('R',w/2-inset)]:
                for end,y in [('F',-dep/2+inset),('B',dep/2-inset)]:
                    label=f'{side}_{end}'
                    foot_pad_h=min(12.0,ph*.15)
                    piece('Kickstand_FootPad_'+label,(x,y,foot_pad_h/2),
                          (55,55,foot_pad_h),'KICKSTAND',0,0,0)
                    piece('Kickstand_Stem_'+label,(x,y,(ph+foot_pad_h)/2),
                          (34,34,ph-foot_pad_h),'KICKSTAND',0,0,0)
    if d.get('include_countertop', True) and d['cabinet_type'] in FLOOR_TYPES:
        ct_key = 'COUNTER_' + d['countertop_material']
        ct_w = w + 2*d['countertop_side_overhang']
        ct_d = dep + d['countertop_front_overhang']
        # The top is a separate mesh and BOQ item; its rear edge is flush with the carcass rear.
        ct_y=-d['countertop_front_overhang']/2
        ct_z=h+d['countertop_thickness']/2
        if sinks:
            countertop_holes=[]
            for spec in sinks:
                sx,sy,sw,sd=sink_cutout_info(d,spec)
                countertop_holes.append((sx,sy-ct_y,sw,sd))
            idx+=1
            first=sinks[0]
            meta={
                'component_id':f'{cab_id}_{idx:03d}', 'cabinet_id':cab_id,
                'component_type':'Kitchen','material_code':ct_key,
                'cut_length_mm':ct_w,'cut_width_mm':ct_d,
                'thickness_mm':d['countertop_thickness'],
                'edge_sides':'','is_preview':preview,
                'igz_sink_count':len(sinks),
                'igz_sink_cutout_width_mm':first['width'],
                'igz_sink_cutout_depth_mm':first['depth'],
                'igz_sink_cutout_area_m2':round(sum(
                    spec['width']*spec['depth'] for spec in sinks)/1e6,5),
                'igz_countertop_pricing':d['countertop_cost_basis']}
            if ct_key=='COUNTER_WOOD':
                meta.update(finish_type='WOOD',finish_tone=d['carcass_tone'],
                            finish_role='COUNTERTOP')
            panel_with_sink_cutouts(c,'Kitchen_Countertop',
                (0,ct_y,ct_z+install_z+base_z),(ct_w,ct_d,d['countertop_thickness']),
                countertop_holes,ct_key,meta)
            # One separate stainless-steel basin/rim assembly per sink model.
            # Fixture pricing, installation and cutout are counted per basin.
            top=h+d['countertop_thickness']
            wall_t=2.0
            rim=12.0
            for spec in sinks:
                sx,sy,sw,sd=sink_cutout_info(d,spec)
                deep=float(spec['bowl_depth'])
                prefix='Sink_' if spec['index']==1 else f"Sink_{spec['index']:02d}_"
                piece(prefix+'Bowl_Bottom',(sx,sy,top-deep+wall_t/2),
                      (sw,sd,wall_t),'SINK',0,0,0)
                for edge,yy in (('Front',sy-sd/2+wall_t/2),('Rear',sy+sd/2-wall_t/2)):
                    piece(prefix+'Bowl_Wall_'+edge,(sx,yy,top-deep/2),
                          (sw,wall_t,deep),'SINK',0,0,0)
                for edge,xx in (('Left',sx-sw/2+wall_t/2),('Right',sx+sw/2-wall_t/2)):
                    piece(prefix+'Bowl_Wall_'+edge,(xx,sy,top-deep/2),
                          (wall_t,sd,deep),'SINK',0,0,0)
                for edge,yy in (('Front',sy-sd/2),('Rear',sy+sd/2)):
                    piece(prefix+'Rim_'+edge,(sx,yy,top+1),
                          (sw+2*rim,2*rim,2),'SINK',0,0,0)
                for edge,xx in (('Left',sx-sw/2),('Right',sx+sw/2)):
                    piece(prefix+'Rim_'+edge,(xx,sy,top+1),
                          (2*rim,sd,2),'SINK',0,0,0)
        else:
            piece('Kitchen_Countertop', (0,ct_y,ct_z),
                  (ct_w,ct_d,d['countertop_thickness']), ct_key, ct_w, ct_d,
                  d['countertop_thickness'])
    if d['include_backsplash'] and d['cabinet_type'] in FLOOR_TYPES:
        piece('Backsplash_Panel',(0,dep/2-d['backsplash_thickness']/2,
              h+(d['countertop_thickness'] if d.get('include_countertop',True) else 0)+d['backsplash_height']/2),
              (w,d['backsplash_thickness'],d['backsplash_height']),
              'BACKSPLASH',w,d['backsplash_height'],d['backsplash_thickness'])
    # Independent kitchen/wall opening values are read from their own
    # PropertyGroup (scene.igz_cabinet / scene.igz_wall).
    # Swing each leaf outwards around its OUTER hinge, not the centre seam.
    if d['door_count'] and d['door_open_angle'] > 0.00001:
        from mathutils import Matrix, Vector
        angle = d['door_open_angle']
        gap = d['door_gap']
        cols, rows = d['door_columns'], d['door_rows']
        dw = (w-(cols+1)*gap)/cols
        for row in range(rows):
            for col in range(cols):
                label = f'R{row+1:02d}_C{col+1:02d}'
                # Pairing: left door hinges at its left edge, right at right edge.
                side = -1 if col % 2 == 0 else 1
                # Smart Corner may restrict only this particular swing leaf.
                # Other leaves on the same run keep their requested opening.
                leaf_angle=float(d.get('_corner_leaf_angles',{}).get(str(col+1),angle))
                if leaf_angle<=0.00001: continue
                cx = -w/2 + gap + dw*(col+.5) + gap*col
                pivot_x = (cx + side*dw/2)/1000
                # Swing around the hinge line at the CABINET FRONT plane / rear face
                # of the door, not the outer/front face of the leaf. This removes the
                # visible open-state gap and keeps the door opening tight to the carcass.
                pivot_y = (-dep/2)/1000
                pivot = Vector((pivot_x,pivot_y,0))
                rot = Matrix.Rotation(side*leaf_angle,4,'Z').to_3x3()
                # Rotate every piece belonging to this door leaf as ONE rigid
                # assembly: flat slab, Shaker stiles/rails/panels and handle.
                # Hinges deliberately stay on the stationary cabinet.
                for obj in c.objects:
                    if obj.get('igz_door_leaf') != label:
                        continue
                    for vertex in obj.data.vertices:
                        vertex.co = pivot + rot @ (vertex.co-pivot)
                    obj.data.update()
    if d['cabinet_type'] in WALL_TYPES:
        # Simplified visualization of the wall mounting kit, at rear of cabinet.
        rail_z=h-70
        piece('Wall_Mounting_Rail',(0,dep/2+10,rail_z),
              (w,20,25),'MOUNT',w,0,0)
        for side,x in [('L',-w/2+65),('R',w/2-65)]:
            piece('Wall_Bracket_'+side,(x,dep/2+22,rail_z),
                  (45,28,55),'MOUNT',0,0,0)
    return c,totals


# Screenshot-matched default configuration (November 12, 2026).
# Used once for a newly initialized scene and when the preset button is pressed.
# Kitchen and wall runs use different LEFT return lengths and nose-gap settings.
DEFAULT_L_MODEL_COMMON = {
    'enabled': True,
    'front_style': 'CLOSED',
    'layout_shape': 'L',
    'l_corner_side': 'LEFT',
    'layout_align_dividers': True,
    'customize_return_runs': False,
    'width': 1800.0,
    'door_columns': 4,
    'door_rows': 1,
    'door_gap': 3.0,
    'vertical_divisions': 3,
    'horizontal_divisions': 0,
    'door_style': 'FLAT',
    'door_finish': 'WOOD',
    'door_tone': 'WHITE',
    'carcass_finish': 'WOOD',
    'carcass_tone': 'OAK',
    'carcass_thickness': 18.0,
    'back_thickness': 6.0,
    'back_inset': 12.0,
    'hinges_per_door': 2,
    'show_handles': False,
    'door_open_angle': 0.0,
}

DEFAULT_L_MODEL_KITCHEN = {
    'cabinet_type': 'BASE',
    'return_left_length': 1500.0,
    'return_right_length': 1800.0,
    'depth': 600.0,
    'height': 900.0,
    'installation_height': 0.0,
    'base_type': 'PLINTH',
    'plinth_height': 50.0,
    'plinth_setback': 60.0,
    'use_nose_gap': False,
    'include_countertop': True,
    'countertop_material': 'QUARTZ',
    'countertop_thickness': 20.0,
    'include_backsplash': True,
    'backsplash_height': 530.0,
    'include_sink': False,
    'sink_quantity': '1',
    'wall_back_offset': 0.0,
}

DEFAULT_L_MODEL_WALL = {
    'cabinet_type': 'WALL',
    'return_left_length': 1800.0,
    'return_right_length': 1800.0,
    'depth': 350.0,
    'height': 720.0,
    'installation_height': 1450.0,
    'base_type': 'NONE',
    'use_nose_gap': True,
    'nose_gap_height': 25.0,
    'include_countertop': False,
    'include_backsplash': False,
    'include_sink': False,
}


def apply_default_l_model(scene):
    """Apply the pictured starter layout, leaving unit prices and currency alone."""
    for unit, extra in ((scene.igz_cabinet, DEFAULT_L_MODEL_KITCHEN),
                        (scene.igz_wall, DEFAULT_L_MODEL_WALL)):
        for name, val in {**DEFAULT_L_MODEL_COMMON, **extra}.items():
            setattr(unit, name, val)


def ensure_pair_defaults(scene):
    """Initialize the wall independently once per scene; preserve settings in .blend."""
    if scene.get('igz_pair_initialized'):
        # One-time v2.9 migration: existing .blend files keep the v2.5 WOOD
        # enum value, even though the property default is now TERRAZZO.
        if not scene.get('igz_countertop_terrazzo_migrated_v29'):
            p = scene.igz_cabinet
            if p.countertop_material == 'WOOD':
                p.countertop_material = 'TERRAZZO'
            scene['igz_countertop_terrazzo_migrated_v29'] = True
        return
    scene['igz_pair_initialized'] = True
    apply_default_l_model(scene)
    # This new scene already explicitly selects its countertop material.
    scene['igz_countertop_terrazzo_migrated_v29'] = True


def pair_settings(scene):
    base = priced_settings(scene, scene.igz_cabinet, 'KITCHEN')
    wall = priced_settings(scene, scene.igz_wall, 'WALL')
    base['cabinet_type'] = 'BASE'
    wall['cabinet_type'] = 'WALL'
    wall['include_backsplash'] = False
    wall['include_sink'] = False
    wall['base_type'] = 'NONE'
    return base, wall



def wall_cabinet_y_offset_mm(base, wall):
    """Place wall-unit rear flush with the wall plane at the base cabinet rear.

    The backsplash is a separate panel in FRONT of that wall plane, so its
    thickness must not push the upper cabinet away from the wall.
    """
    return (base['depth'] - wall['depth']) / 2.0 + base.get('wall_back_offset', 0.0)



def offset_cabinet_y_mm(c, offset_mm):
    """Translate only the meshes belonging to a single cabinet collection."""
    for obj in c.all_objects:
        obj.location.y += offset_mm / 1000.0
    c['igz_placement_y_mm'] = offset_mm


def refresh_preview_now():
    global _REFRESHING
    if _REFRESHING: return
    _REFRESHING = True
    try:
        scene = bpy.context.scene
        if scene is None or not hasattr(scene,'igz_cabinet') or not hasattr(scene,'igz_wall'): return
        ensure_pair_defaults(scene)
        p = scene.igz_cabinet
        repair_drawer_controls(p)
        _, preview, _ = roots()
        base, wall = pair_settings(scene)
        # Validate both before deleting previous working geometry.
        if p.enabled: calculate_layout(dict(base))
        if scene.igz_wall.enabled: calculate_layout(dict(wall))
        remove_collection_contents(preview)
        if p.enabled:
            make_layout(preview, base, 'KITCHEN', True)
        if scene.igz_wall.enabled:
            cw, _ = make_layout(preview, wall, 'WALL', True)
            # Kitchen and wall live in separate preview collections, so only
            # the upper cabinet is moved to the rear wall plane.
            offset_cabinet_y_mm(cw, wall_cabinet_y_offset_mm(base, wall))
        p.status = '3D preview updated: only enabled cabinets'
    except Exception as e:
        try: scene.igz_cabinet.status = 'Live model: ' + str(e)[:160]
        except Exception: pass
        print('Integrazo cabinet pair update:',e)
    finally:
        _REFRESHING = False


def _timer():
    global _TIMER_PENDING
    _TIMER_PENDING=False
    try: refresh_preview_now()
    except Exception as e: print('Integrazo preview error:',e)
    return None


_LOADING_SETTINGS = False


def on_type_change(self, context):
    if not _LOADING_SETTINGS:
        defaults = {
            'BASE': (0.0,'PLINTH'),
            'OPEN': (0.0,'NONE'),
            'WALL_OPEN': (1400.0,'NONE'),
            'WALL': (1400.0,'NONE'),
            'TALL': (0.0,'PLINTH'),
        }
        elev, base = defaults.get(self.cabinet_type,(0.0,'NONE'))
        self.installation_height = elev
        self.base_type = base
        self.front_style = 'CLOSED'
    on_update(self,context)


def active_drawer_runs(layout):
    """The run names that physically exist in the requested cabinet layout."""
    shape=layout.get('layout_shape','STRAIGHT') if isinstance(layout,dict) else layout.layout_shape
    if shape=='U': return ('MAIN','LEFT','RIGHT')
    if shape=='L':
        side=layout.get('l_corner_side','LEFT') if isinstance(layout,dict) else layout.l_corner_side
        return ('MAIN',side)
    return ('MAIN',)


def layout_drawer_collision_warnings(d):
    """Conservative AABB review of pulled drawer boxes against OTHER L/U runs.

    A warning is advisory: preserve existing geometry and project settings.
    This catches a main-run drawer opening into a perpendicular corner return.
    """
    if not d.get('enable_drawers') or d.get('layout_shape')=='STRAIGHT':
        return []
    modules=layout_modules(d)
    if len(modules)<2: return []
    def world_bounds(xlo,xhi,ylo,yhi,tx,ty,angle):
        co,si=math.cos(angle),math.sin(angle)
        pts=[(tx+co*x-si*y, ty+si*x+co*y)
             for x in (xlo,xhi) for y in (ylo,yhi)]
        return (min(pt[0] for pt in pts),max(pt[0] for pt in pts),
                min(pt[1] for pt in pts),max(pt[1] for pt in pts))
    blockers={}
    for name,run,x,y,angle in modules:
        blockers[name]=world_bounds(-run['width']/2,run['width']/2,
                                    -run['depth']/2,run['depth']/2,x,y,angle)
    warnings=[]
    for name,run,x,y,angle in modules:
        if not run.get('enable_drawers'): continue
        for spec in drawer_specs(run):
            travel=float(spec['ext'])
            if travel<=0.01: continue
            # Moving box occupies this XY rectangle after extension.
            moving=world_bounds(spec['box_x']-spec['box_w']/2,
                                spec['box_x']+spec['box_w']/2,
                                -run['depth']/2-travel,
                                -run['depth']/2+spec['box_d']-travel,
                                x,y,angle)
            for other,bounds in blockers.items():
                if other==name: continue
                overlap_x=min(moving[1],bounds[1])-max(moving[0],bounds[0])
                overlap_y=min(moving[3],bounds[3])-max(moving[2],bounds[2])
                if overlap_x>1 and overlap_y>1:
                    message=(f'{name} C{spec["drawer_column"]} drawer {spec["index"]}: '
                             f'{travel:.0f} mm pull may collide with {other}; '
                             'review corner clearance or choose another bay')
                    if message not in warnings: warnings.append(message)
                    break
    return warnings


def run_columns_for_ui(p,run):
    """Number of available cabinet door bays; returns use real L/U sizing."""
    if run=='MAIN': return max(1,int(p.door_columns))
    if p.layout_shape=='STRAIGHT' or (p.layout_shape=='L' and run!=p.l_corner_side):
        return 0
    if p.customize_return_runs:
        return int(getattr(p,'return_'+run.lower()+'_door_columns'))
    width=max(1.0,float(getattr(p,'return_'+run.lower()+'_length'))-p.depth)
    return automatic_return_door_columns({'door_columns':p.door_columns,'width':p.width},width)


def repair_drawer_controls(p):
    """Keep every drawer usable in the LIVE preview, including older projects.

    v4.7 uses one bank-based UI for all drawers; no more legacy single/multiple
    switching. Each independent pull is limited to the installed slide travel,
    so entering 900 mm with a 400 mm drawer never invalidates the preview.
    """
    if not p.enable_drawers: return
    if p.front_style!='CLOSED': return
    # Do not rewrite Door Rows or Horizontal Dividers: both are valid for
    # swing-door bays alongside drawers. The drawer columns intentionally
    # skip fixed partitions, while the remaining columns honor these values.
    if p.layout_shape=='STRAIGHT':
        if p.vertical_divisions!=p.door_columns-1:
            p.vertical_divisions=p.door_columns-1
    elif not p.layout_align_dividers:
        p.layout_align_dividers=True

    # Migrate v4.5 single-bank scenes into the same editable independent
    # bank system used for multiple banks. Existing v4.6 bank collections
    # are retained even if their previous mode checkbox was unchecked.
    if len(p.drawer_banks)==0:
        bank=p.drawer_banks.add()
        run=p.drawer_run
        if run_columns_for_ui(p,run)<1: run='MAIN'
        bank.run=run
        limit=run_columns_for_ui(p,run)
        bank.column=max(1,min(int(p.drawer_column),limit))
        bank.count=int(p.drawer_count)
        start=min(max(0.0,float(p.drawer_extension)),drawer_safe_travel_mm(p.drawer_depth))
        for index in range(1,bank.count+1):
            setattr(bank,f'pull_{index}',start)
    if not p.drawer_multi_bank_mode:
        p.drawer_multi_bank_mode=True
    # Keep old enum fields hidden for loading older .blend files; all newly
    # generated drawers use standard handles plus two-part slide runners.
    max_travel=drawer_safe_travel_mm(p.drawer_depth)
    occupied=set()
    valid_runs=['MAIN']
    if p.layout_shape=='U': valid_runs.extend(('LEFT','RIGHT'))
    elif p.layout_shape=='L': valid_runs.append(p.l_corner_side)
    for bank in p.drawer_banks:
        if run_columns_for_ui(p,bank.run)<=0:
            bank.run='MAIN'
        count=run_columns_for_ui(p,bank.run)
        if bank.column>count: bank.column=count
        if bank.column<1: bank.column=1
        location=(bank.run,bank.column)
        if location in occupied:
            alternatives=[(run,col) for run in [bank.run]+[r for r in valid_runs if r!=bank.run]
                          for col in range(1,run_columns_for_ui(p,run)+1)]
            free=next((item for item in alternatives if item not in occupied),None)
            if free is not None:
                bank.run,bank.column=free
                location=free
            # If no free bays exist, leave the duplicate visible. Validate
            # reports a clear column conflict instead of deleting saved data.
        occupied.add(location)
        if bank.hardware!='HANDLE': bank.hardware='HANDLE'
        for i in range(1,7):
            key=f'pull_{i}'
            value=float(getattr(bank,key))
            adjusted=max(0.0,min(value,max_travel))
            if abs(adjusted-value)>0.0001:
                setattr(bank,key,adjusted)


def on_update(self,context):
    global _TIMER_PENDING, _REFRESHING
    if _REFRESHING or _LOADING_SETTINGS or context is None or context.scene is None: return
    p=context.scene.igz_cabinet
    _REFRESHING=True
    try: repair_drawer_controls(p)
    finally: _REFRESHING=False
    if not _TIMER_PENDING:
        _TIMER_PENDING=True
        bpy.app.timers.register(_timer,first_interval=0.35)



class IGZPriceLibrary(bpy.types.PropertyGroup):
    """Scene-persistent material & hardware price catalog, separate from geometry."""
    wood_laminate_rate: FloatProperty(name='Wood Laminate (THB/m²)',description='Shared price ID: wood_laminate_rate; editable THB-based estimate',default=1250.0,min=0,update=on_price_update)
    color_laminate_rate: FloatProperty(name='Color Laminate (THB/m²)',description='Shared price ID: color_laminate_rate; editable THB-based estimate',default=1100.0,min=0,update=on_price_update)
    carcass_rate: FloatProperty(name='Legacy Carcass Rate (THB/m²)',description='Shared price ID: carcass_rate; editable THB-based estimate',default=850.0,min=0,update=on_price_update)
    back_rate: FloatProperty(name='Back Panel / Drawer Bottom (THB/m²)',description='Shared price ID: back_rate; editable THB-based estimate',default=280.0,min=0,update=on_price_update)
    door_rate: FloatProperty(name='Legacy Door Rate (THB/m²)',description='Shared price ID: door_rate; editable THB-based estimate',default=1100.0,min=0,update=on_price_update)
    shaker_glass_rate: FloatProperty(name='Shaker Glass (THB/m²)',description='Shared price ID: shaker_glass_rate; editable THB-based estimate',default=850.0,min=0,update=on_price_update)
    backsplash_rate: FloatProperty(name='Backsplash (THB/m²)',description='Shared price ID: backsplash_rate; editable THB-based estimate',default=950.0,min=0,update=on_price_update)
    countertop_composite_rate: FloatProperty(name='Composite Surface (THB/m²)',description='Shared price ID: countertop_composite_rate; editable THB-based estimate',default=2800.0,min=0,update=on_price_update)
    countertop_quartz_rate: FloatProperty(name='Quartz (THB/m²)',description='Shared price ID: countertop_quartz_rate; editable THB-based estimate',default=4800.0,min=0,update=on_price_update)
    countertop_terrazzo_rate: FloatProperty(name='Terrazzo (THB/m²)',description='Shared price ID: countertop_terrazzo_rate; editable THB-based estimate',default=3500.0,min=0,update=on_price_update)
    countertop_granite_rate: FloatProperty(name='Granite (THB/m²)',description='Shared price ID: countertop_granite_rate; editable THB-based estimate',default=6200.0,min=0,update=on_price_update)
    hinge_rate: FloatProperty(name='Hinge (THB/pc)',description='Shared price ID: hinge_rate; editable THB-based estimate',default=80.0,min=0,update=on_price_update)
    handle_rate: FloatProperty(name='Door Handle (THB/pc)',description='Shared price ID: handle_rate; editable THB-based estimate',default=150.0,min=0,update=on_price_update)
    drawer_slide_rate: FloatProperty(name='Drawer Slide Pair (THB/pair)',description='Shared price ID: drawer_slide_rate; editable THB-based estimate',default=450.0,min=0,update=on_price_update)
    drawer_handle_rate: FloatProperty(name='Drawer Handle (THB/pc)',description='Shared price ID: drawer_handle_rate; editable THB-based estimate',default=150.0,min=0,update=on_price_update)
    drawer_push_rate: FloatProperty(name='Legacy Push-to-Open (THB/set)',description='Shared price ID: drawer_push_rate; editable THB-based estimate',default=180.0,min=0,update=on_price_update)
    nose_gap_rate: FloatProperty(name='Nose Gap Rail (THB/m)',description='Shared price ID: nose_gap_rate; editable THB-based estimate',default=120.0,min=0,update=on_price_update)
    shelf_support_rate: FloatProperty(name='Shelf Support (THB/pc)',description='Shared price ID: shelf_support_rate; editable THB-based estimate',default=8.0,min=0,update=on_price_update)
    mount_bracket_rate: FloatProperty(name='Wall Mounting Bracket (THB/pc)',description='Shared price ID: mount_bracket_rate; editable THB-based estimate',default=150.0,min=0,update=on_price_update)
    mount_rail_rate: FloatProperty(name='Wall Mounting Rail (THB/m)',description='Shared price ID: mount_rail_rate; editable THB-based estimate',default=250.0,min=0,update=on_price_update)
    edge_rate: FloatProperty(name='Edge Banding (THB/m)',description='Shared price ID: edge_rate; editable THB-based estimate',default=30.0,min=0,update=on_price_update)
    plinth_rate: FloatProperty(name='Plinth (THB/m)',description='Shared price ID: plinth_rate; editable THB-based estimate',default=200.0,min=0,update=on_price_update)
    kickstand_rate: FloatProperty(name='Adjustable Foot (THB/pc)',description='Shared price ID: kickstand_rate; editable THB-based estimate',default=120.0,min=0,update=on_price_update)
    sink_unit_rate: FloatProperty(name='Sink Supply (THB/pc)',description='Shared price ID: sink_unit_rate; editable THB-based estimate',default=3000.0,min=0,update=on_price_update)
    sink_cutout_rate: FloatProperty(name='Sink Cutout / Fabrication (THB/pc)',description='Shared price ID: sink_cutout_rate; editable THB-based estimate',default=600.0,min=0,update=on_price_update)
    sink_install_rate: FloatProperty(name='Sink Installation (THB/pc)',description='Shared price ID: sink_install_rate; editable THB-based estimate',default=900.0,min=0,update=on_price_update)
    labor_rate: FloatProperty(name='Cabinet Assembly (THB/set)',description='Shared price ID: labor_rate; editable THB-based estimate',default=1200.0,min=0,update=on_price_update)
    waste_percent: FloatProperty(name='Panel Waste Allowance (%)',description='Shared price ID: waste_percent; editable THB-based estimate',default=10.0,min=0,max=100,update=on_price_update)
    boq_currency: EnumProperty(name='BOQ Currency',items=[
        ('THB','THB - Thai Baht','THB rate catalog'),
        ('SGD','SGD - Singapore Dollar','Converted using THB/SGD'),
        ('USD','USD - US Dollar','Converted using THB/USD')],default='THB',update=on_price_update)
    fx_thb_per_sgd: FloatProperty(name='THB per 1 SGD',default=25.0,min=0.000001,precision=4,update=on_price_update)
    fx_thb_per_usd: FloatProperty(name='THB per 1 USD',default=33.0,min=0.000001,precision=4,update=on_price_update)
    kitchen_override_enabled: BoolProperty(name='Kitchen Price Override',default=False,update=on_price_update)
    wall_override_enabled: BoolProperty(name='Wall Price Override',default=False,update=on_price_update)
    expand_library: BoolProperty(name='Material & Cost Library',default=True)
    expand_laminates: BoolProperty(name='Board / Laminate / Glass',default=True)
    expand_countertops: BoolProperty(name='Countertops',default=False)
    expand_hardware: BoolProperty(name='Hardware',default=False)
    expand_fabrication: BoolProperty(name='Fabrication / Installation',default=False)
    expand_overrides: BoolProperty(name='Project Price Overrides',default=False)
    expand_kitchen_override: BoolProperty(name='Kitchen Override Details',default=False)
    expand_wall_override: BoolProperty(name='Wall Override Details',default=False)

class IGZDrawerBank(bpy.types.PropertyGroup):
    """An independently costed pull-out drawer bank in a particular run/bay."""
    run: EnumProperty(name='Run',items=[('MAIN','Main','Rear run'),
        ('LEFT','Left Return','Left arm'),('RIGHT','Right Return','Right arm')],
        default='MAIN',update=on_update)
    column: IntProperty(name='Door Column',default=1,min=1,max=8,update=on_update)
    count: IntProperty(name='Drawers',default=3,min=1,max=6,update=on_update)
    hardware: EnumProperty(name='Opening (Legacy)',items=[
        ('HANDLE','Handle + Slides','Manual pull-out with handle and slides'),
        ('PUSH','Deprecated Push-to-Open','Converted to Handle + Slides'),
        ('NONE','Deprecated Slides Only','Converted to Handle + Slides')],default='HANDLE',update=on_update)
    pull_1: FloatProperty(name='Drawer 1 Pull (mm)',default=0,min=0,max=900,update=on_update)
    pull_2: FloatProperty(name='Drawer 2 Pull (mm)',default=0,min=0,max=900,update=on_update)
    pull_3: FloatProperty(name='Drawer 3 Pull (mm)',default=0,min=0,max=900,update=on_update)
    pull_4: FloatProperty(name='Drawer 4 Pull (mm)',default=0,min=0,max=900,update=on_update)
    pull_5: FloatProperty(name='Drawer 5 Pull (mm)',default=0,min=0,max=900,update=on_update)
    pull_6: FloatProperty(name='Drawer 6 Pull (mm)',default=0,min=0,max=900,update=on_update)


class IGZCabinetSettings(bpy.types.PropertyGroup):
    enabled: BoolProperty(name='Enable Cabinet', description='Include this cabinet in 3D model and BOQ', default=True, update=on_update)
    front_style: EnumProperty(name='Cabinet Front',items=[('CLOSED','Closed Doors','Doors and hardware'),('OPEN','Open Shelves','No front doors')],default='CLOSED',update=on_update)
    cabinet_type: EnumProperty(name='Cabinet Type',items=[
        ('BASE','Kitchen Cabinet','Floor-standing kitchen cabinet'),
        ('WALL','Wall Cabinet','Wall-mounted cabinet')],default='BASE',update=on_type_change)
    installation_height: FloatProperty(name='Bottom Height from FFL (mm)',
        description='Elevation of bottom of cabinet installation above finished floor (Z=0)',
        default=0.0,min=0,max=6000,precision=1,update=on_update)
    base_type: EnumProperty(name='Base Type',items=[
        ('NONE','None','No plinth or adjustable legs'),
        ('PLINTH','Toe Kick / Plinth','Recessed floor plinth'),
        ('LEGS','Adjustable Legs','Four adjustable floor legs')],default='PLINTH',update=on_update)
    layout_shape: EnumProperty(name='Plan Layout',items=[('STRAIGHT','Straight','Single straight run'),('L','L Shape','Main run with one side return'),('U','U Shape','Main run with left and right returns')],default='STRAIGHT',update=on_update)
    l_corner_side: EnumProperty(name='L Return Side',items=[('LEFT','Left','Return on left when facing the cabinets'),('RIGHT','Right','Return on right when facing the cabinets')],default='LEFT',update=on_update)
    return_left_length: FloatProperty(name='Left Return Total (mm)',description='Total side-wall run from rear-wall plane, including main cabinet depth',default=1200,min=150,max=10000,update=on_update)
    return_right_length: FloatProperty(name='Right Return Total (mm)',description='Total side-wall run from rear-wall plane, including main cabinet depth',default=1200,min=150,max=10000,update=on_update)
    layout_align_dividers: BoolProperty(
        name='Match Dividers to Door Columns',
        description='For L/U layouts, use one interior vertical divider at every door seam (N doors = N-1 dividers) on main and customized return runs. Disable to edit divider counts independently',
        default=True,update=on_update)
    corner_smart_enabled: BoolProperty(name='Smart Corner Collision Prevention',
        description='Optional conservative collision checks; add corner fillers and limit unsafe drawer/door travel without changing your requested settings',
        default=False,update=on_update)
    corner_auto_filler: BoolProperty(name='Auto Size Corner Filler',
        description='Find the smallest filler width that clears requested door/drawer sweep up to the maximum permitted',
        default=True,update=on_update)
    corner_min_filler_mm: FloatProperty(name='Minimum Filler (mm)',default=45,min=0,max=600,update=on_update)
    corner_max_filler_mm: FloatProperty(name='Maximum Auto Filler (mm)',default=425,min=0,max=1000,update=on_update)
    corner_manual_left_mm: FloatProperty(name='Left Filler (mm)',default=45,min=0,max=1000,update=on_update)
    corner_manual_right_mm: FloatProperty(name='Right Filler (mm)',default=45,min=0,max=1000,update=on_update)
    customize_return_runs: BoolProperty(name='Custom Return Run Details',
        description='Override automatic door/frame counts and door styles for each L/U return',
        default=False,update=on_update)
    return_left_door_columns: IntProperty(name='Left Return Door Frames',default=2,min=1,max=8,update=on_update)
    return_right_door_columns: IntProperty(name='Right Return Door Frames',default=2,min=1,max=8,update=on_update)
    return_left_door_rows: IntProperty(name='Left Return Door Rows',default=1,min=1,max=8,update=on_update)
    return_right_door_rows: IntProperty(name='Right Return Door Rows',default=1,min=1,max=8,update=on_update)
    return_left_vertical_divisions: IntProperty(name='Left Return Vertical Dividers',default=0,min=0,max=7,update=on_update)
    return_right_vertical_divisions: IntProperty(name='Right Return Vertical Dividers',default=0,min=0,max=7,update=on_update)
    return_left_horizontal_divisions: IntProperty(name='Left Return Horizontal Dividers',default=0,min=0,max=6,update=on_update)
    return_right_horizontal_divisions: IntProperty(name='Right Return Horizontal Dividers',default=0,min=0,max=6,update=on_update)
    return_left_door_style: EnumProperty(name='Left Return Door Style',items=[
        ('INHERIT','Same as Main','Follow main door style and frame details'),
        ('FLAT','Flat Panel','Modern slab door'),
        ('SHAKER_RECESSED','Shaker Recessed','Framed door with recessed center'),
        ('SHAKER_GLASS','Shaker Glass','Framed glass-front door'),
        ('SHAKER_DOUBLE','Shaker Double','Double recessed panel')],default='INHERIT',update=on_update)
    return_right_door_style: EnumProperty(name='Right Return Door Style',items=[
        ('INHERIT','Same as Main','Follow main door style and frame details'),
        ('FLAT','Flat Panel','Modern slab door'),
        ('SHAKER_RECESSED','Shaker Recessed','Framed door with recessed center'),
        ('SHAKER_GLASS','Shaker Glass','Framed glass-front door'),
        ('SHAKER_DOUBLE','Shaker Double','Double recessed panel')],default='INHERIT',update=on_update)
    return_left_frame_width: FloatProperty(name='Left Shaker Frame Width (mm)',default=65,min=15,max=160,update=on_update)
    return_right_frame_width: FloatProperty(name='Right Shaker Frame Width (mm)',default=65,min=15,max=160,update=on_update)
    width: FloatProperty(name='Width (mm)',default=900,min=100,max=10000,precision=1,update=on_update)
    depth: FloatProperty(name='Depth (mm)',default=600,min=100,max=3000,precision=1,update=on_update)
    height: FloatProperty(name='Height (mm)',default=720,min=100,max=5000,precision=1,update=on_update)
    carcass_thickness: FloatProperty(name='Carcass (mm)',default=18,min=3,max=80,update=on_update)
    back_thickness: FloatProperty(name='Backboard (mm)',default=6,min=2,max=40,update=on_update)
    shelf_count: IntProperty(name='Legacy Shelves per Compartment',default=0,min=0,max=8,update=on_update)
    vertical_divisions: IntProperty(name='Vertical Dividers',description='Number of full-height dividers splitting cabinet into columns (L/U layouts optionally match to door columns)',default=0,min=0,max=7,update=on_update)
    horizontal_divisions: IntProperty(name='Horizontal Dividers',description='Fixed horizontal partitions per door bay. When pull-out drawers are used, their bays are kept clear',default=0,min=0,max=6,update=on_update)
    # Retained for old .blend files; new controls are door_columns and door_rows.
    door_count: IntProperty(name='Legacy Door Count',default=2,min=0,max=64)
    door_columns: IntProperty(name='Door Columns (Left / Right)',description='Number of door leaves across cabinet width',default=2,min=1,max=8,update=on_update)
    door_rows: IntProperty(name='Door Rows (Bottom / Top)',description='Number of swing-door leaves stacked vertically in door bays; drawer front count is set independently per bank',default=1,min=1,max=8,update=on_update)
    door_gap: FloatProperty(name='Door Gap (mm)',default=3,min=1,max=15,update=on_update)
    show_handles: BoolProperty(name='Show Handles',description='Add physical handles and include handles in BOQ (disabled when Nose Gap is active)',default=True,update=on_update)
    use_nose_gap: BoolProperty(name='Use Nose Gap (Handleless)',description='Kitchen: finger-pull gap above doors; Wall: finger-pull gap below doors; handles are suppressed',default=False,update=on_update)
    nose_gap_height: FloatProperty(name='Nose Gap Height (mm)',description='Clearance for fingers at the top of the door',default=25,min=12,max=70,update=on_update)
    back_inset: FloatProperty(name='Back Inset (mm)',default=12,min=0,max=80,update=on_update)
    shelf_clearance: FloatProperty(name='Legacy Shelf Side Clearance (mm)',default=0,min=0,max=15,update=on_update)
    show_plinth: BoolProperty(name='Include Floor Support',description='Raise the carcass on a plinth or adjustable kickstands, with the base starting at Z=0',default=True,update=on_update)
    support_type: EnumProperty(name='Floor Support Type',items=[('PLINTH','Toe Kick / Plinth','Four panel support ring with recessed front toe kick'),('KICKSTAND','Adjustable Kickstands','Four independent adjustable cabinet legs')],default='PLINTH',update=on_update)
    plinth_height: FloatProperty(name='Plinth / Kickstand Height (mm)',description='Floor-to-carcass height; INCLUDED in Overall Cabinet Height',default=100,min=20,max=250,update=on_update)
    plinth_setback: FloatProperty(name='Plinth Setback (mm)',description='Front/rear toe-kick recess from cabinet edges',default=60,min=20,max=200,update=on_update)

    carcass_finish: EnumProperty(name='Carcass Laminate',items=[('WOOD','Wood Laminate','Procedural wood-grain laminate'),('COLOR','Color Laminate','Solid color laminate')],default='WOOD',update=on_update)
    carcass_tone: EnumProperty(name='Carcass Color / Wood',items=[('OAK','Natural Oak',''),('ASH','Light Ash',''),('WALNUT','Dark Walnut',''),('WHITE','Warm White',''),('GREY','Soft Grey',''),('SAGE','Sage Green',''),('BLUE','Slate Blue',''),('CHARCOAL','Charcoal','')],default='OAK',update=on_update)
    door_finish: EnumProperty(name='Door Laminate',items=[('WOOD','Wood Laminate','Procedural wood-grain laminate'),('COLOR','Color Laminate','Solid color laminate')],default='WOOD',update=on_update)
    door_tone: EnumProperty(name='Door Color / Wood',items=[('OAK','Natural Oak',''),('ASH','Light Ash',''),('WALNUT','Dark Walnut',''),('WHITE','Warm White',''),('GREY','Soft Grey',''),('SAGE','Sage Green',''),('BLUE','Slate Blue',''),('CHARCOAL','Charcoal','')],default='WHITE',update=on_update)
    door_style: EnumProperty(name='Door Panel Style',description='Flat slab or constructed Shaker frame-and-panel door',items=[
        ('FLAT','Modern Flat Panel','Original full-thickness slab door'),
        ('SHAKER_RECESSED','Shaker Recessed Panel','Five-piece framed door with recessed center'),
        ('SHAKER_GLASS','Shaker Glass Panel','Framed door with transparent center glass'),
        ('SHAKER_DOUBLE','Shaker Double Panel','Two recessed panels separated by a center rail')],
        default='FLAT',update=on_update)
    shaker_frame_width: FloatProperty(name='Shaker Frame Width (mm)',description='Face width of Shaker stiles and rails',default=65,min=15,max=160,update=on_update)
    shaker_recess_depth: FloatProperty(name='Panel Recess (mm)',description='Distance center panel sits back from Shaker frame front face',default=4,min=1,max=18,update=on_update)
    shaker_glass_thickness: FloatProperty(name='Glass Thickness (mm)',default=5,min=3,max=12,update=on_update)
    shaker_glass_rate: FloatProperty(name='Glass THB/m²',description='Editable glass material rate in THB per square meter; currency conversion follows BOQ selector',default=850,min=0,update=on_update)
    wood_laminate_rate: FloatProperty(name='Wood Laminate THB/m²',default=1250,min=0,update=on_update)
    color_laminate_rate: FloatProperty(name='Color Laminate THB/m²',default=1100,min=0,update=on_update)
    include_backsplash: BoolProperty(name='Include Backsplash',default=False,update=on_update)
    backsplash_height: FloatProperty(name='Backsplash Height (mm)',default=500,min=50,max=2500,update=on_update)
    backsplash_thickness: FloatProperty(name='Backsplash Thickness (mm)',default=10,min=2,max=80,update=on_update)
    backsplash_rate: FloatProperty(name='Backsplash THB/m²',default=950,min=0,update=on_update)
    include_countertop: BoolProperty(name='Include Kitchen Countertop',default=True,update=on_update)
    include_sink: BoolProperty(name='Include Sink',description='Add one or two separately modeled basins and countertop openings, including BOQ costs',default=False,update=on_update)
    sink_quantity: EnumProperty(name='Sink Models',items=[
        ('1','1 Sink','Single basin with one cutout'),
        ('2','2 Sinks','Two separately positioned basins and cutouts')],default='1',update=on_update)
    sink_run: EnumProperty(name='Sink Position / Run',items=[
        ('MAIN','Main Rear Run','Center or adjust on the back-wall run'),
        ('LEFT','Left Return','Place sink on L/U left return'),
        ('RIGHT','Right Return','Place sink on L/U right return')],default='MAIN',update=on_update)
    sink_width: FloatProperty(name='Sink Cutout Width (mm)',default=500,min=100,max=1200,update=on_update)
    sink_depth: FloatProperty(name='Sink Cutout Depth (mm)',default=400,min=100,max=900,update=on_update)
    sink_bowl_depth: FloatProperty(name='Sink Bowl Depth (mm)',default=180,min=60,max=400,update=on_update)
    sink_x_offset: FloatProperty(name='Sink Offset Along Run (mm)',description='Offset from the center of the selected run, negative left, positive right',default=0,min=-5000,max=5000,update=on_update)
    sink_front_setback: FloatProperty(name='Sink Cutout from Front Edge (mm)',description='Distance from the outer countertop front edge to the front edge of the sink opening',default=90,min=0,max=1500,update=on_update)
    sink2_run: EnumProperty(name='Sink 2 Position / Run',items=[
        ('MAIN','Main Cabinet','Sink 2 on main straight run'),
        ('LEFT','Left Return','Sink 2 on left return in L/U'),
        ('RIGHT','Right Return','Sink 2 on right return in L/U')],default='MAIN',update=on_update)
    sink2_width: FloatProperty(name='Sink 2 Cutout Width (mm)',default=500,min=100,max=1200,update=on_update)
    sink2_depth: FloatProperty(name='Sink 2 Cutout Depth (mm)',default=400,min=100,max=900,update=on_update)
    sink2_bowl_depth: FloatProperty(name='Sink 2 Bowl Depth (mm)',default=180,min=60,max=400,update=on_update)
    sink2_x_offset: FloatProperty(name='Sink 2 Offset Along Run (mm)',default=550,min=-5000,max=5000,update=on_update)
    sink2_front_setback: FloatProperty(name='Sink 2 Cutout from Front Edge (mm)',default=90,min=0,max=1500,update=on_update)
    countertop_cost_basis: EnumProperty(name='Countertop Cost Basis',items=[
        ('GROSS','Gross Slab Area','Recommended: charge full blank slab including the sink offcut'),
        ('NET','Net Area Less Opening','Deduct sink opening area only where measurement terms require it')],
        default='GROSS',update=on_update)
    sink_unit_rate: FloatProperty(name='Sink Supply THB/pc',description='Editable sink fixture supply price (not a live quote)',default=3000,min=0,update=on_update)
    sink_cutout_rate: FloatProperty(name='Sink Cutout THB/pc',description='Fabrication charge for opening and polishing/sealing the countertop',default=600,min=0,update=on_update)
    sink_install_rate: FloatProperty(name='Sink Installation THB/pc',description='Installation and sealing allowance (excludes plumbing unless separately priced)',default=900,min=0,update=on_update)
    countertop_material: EnumProperty(name='Countertop Material',items=[
        ('TERRAZZO','Terrazzo (Default)','Procedural terrazzo stone countertop'),
        ('COMPOSITE','Composite Solid Surface','Composite solid-surface top'),
        ('QUARTZ','Engineered Quartz','Quartz composite stone top'),
        ('GRANITE','Natural Granite','Natural granite stone top'),
        ('WOOD','Wood Laminate','Wood laminate countertop with automatic UV')],default='TERRAZZO',update=on_update)
    countertop_thickness: FloatProperty(name='Countertop Thickness (mm)',default=20,min=8,max=80,update=on_update)
    countertop_front_overhang: FloatProperty(name='Front Overhang (mm)',default=20,min=0,max=100,update=on_update)
    countertop_side_overhang: FloatProperty(name='Side Overhang (mm)',default=10,min=0,max=100,update=on_update)
    countertop_composite_rate: FloatProperty(name='Composite THB/m²',default=2800,min=0,update=on_update)
    countertop_quartz_rate: FloatProperty(name='Quartz THB/m²',default=4800,min=0,update=on_update)
    countertop_terrazzo_rate: FloatProperty(name='Terrazzo THB/m²',default=3500,min=0,update=on_update)
    countertop_granite_rate: FloatProperty(name='Granite THB/m²',default=6200,min=0,update=on_update)
    expand_countertop: BoolProperty(name='Kitchen Countertop',default=True)
    wall_back_offset: FloatProperty(name='Wall Rear Offset (mm)',description='Additional distance behind kitchen cabinet rear plane',default=0,min=0,max=300,update=on_update)
    enable_drawers: BoolProperty(name='Enable Real Drawer Bank',default=False,update=on_update)
    drawer_multi_bank_mode: BoolProperty(name='Multiple Drawer Banks / Independent Pull',
        description='Assign many drawer banks, each with its own column and independent drawer pull sliders',
        default=False,update=on_update)
    drawer_banks: CollectionProperty(type=IGZDrawerBank)
    drawer_run: EnumProperty(name='Drawer Run',items=[('MAIN','Main Run',''),('LEFT','Left Return',''),('RIGHT','Right Return','')],default='MAIN',update=on_update)
    drawer_column: IntProperty(name='Drawer Column',default=1,min=1,max=8,update=on_update)
    drawer_count: IntProperty(name='Number of Drawers',default=3,min=1,max=6,update=on_update)
    drawer_box_thickness: FloatProperty(name='Drawer Side Thickness (mm)',default=15,min=9,max=25,update=on_update)
    drawer_bottom_thickness: FloatProperty(name='Drawer Bottom Thickness (mm)',default=6,min=3,max=18,update=on_update)
    drawer_slide_clearance: FloatProperty(name='Slide Clearance Each Side (mm)',default=13,min=8,max=25,update=on_update)
    drawer_depth: FloatProperty(name='Drawer Box Depth (mm)',default=400,min=120,max=1000,update=on_update)
    drawer_extension: FloatProperty(name='Drawer Pull-Out (mm)',description='0 = closed, positive = drawer pulled towards user',default=0,min=0,max=900,update=on_update)
    drawer_motion_mode: EnumProperty(name='Legacy Drawer Opening Hardware',items=[('HANDLE','Handle + Slides','Manual pull out'),('PUSH','Deprecated Push-to-Open','Converted to Handle + Slides'),('NONE','Deprecated Slides Only','Converted to Handle + Slides')],default='HANDLE',update=on_update)
    drawer_slide_rate: FloatProperty(name='Slide Pair THB / Drawer',default=450,min=0,update=on_update)
    drawer_push_rate: FloatProperty(name='Push-to-Open Set THB',default=180,min=0,update=on_update)
    drawer_handle_rate: FloatProperty(name='Drawer Handle THB',default=150,min=0,update=on_update)
    door_open_angle: FloatProperty(name='Door Opening Angle',description='Swing door fronts in 3D; does not change the BOQ',default=0,min=0,max=1.919862177,subtype='ANGLE',update=on_update)
    expand_dimensions: BoolProperty(name='Dimensions',default=True)
    expand_wall_dimensions: BoolProperty(name='Wall Cabinet Section',default=True)
    expand_carcass: BoolProperty(name='Carcass & Doors',default=False)
    expand_backsplash: BoolProperty(name='Backsplash',default=False)
    expand_preview: BoolProperty(name='Live Preview',default=False)
    boq_currency: EnumProperty(name='BOQ Currency',items=[('THB','THB - Thai Baht','Keep original prices'),('SGD','SGD - Singapore Dollar','Convert BOQ using editable THB per SGD'),('USD','USD - US Dollar','Convert BOQ using editable THB per USD')],default='THB',update=on_update)
    fx_thb_per_sgd: FloatProperty(name='THB per 1 SGD',description='Manual illustrative exchange rate, not a live market quote',default=25.0,min=0.000001,precision=4,update=on_update)
    fx_thb_per_usd: FloatProperty(name='THB per 1 USD',description='Manual illustrative exchange rate, not a live market quote',default=33.0,min=0.000001,precision=4,update=on_update)
    expand_prices: BoolProperty(name='Unit Prices',default=False)
    expand_generate: BoolProperty(name='Generate & Edit',default=True)
    expand_boq: BoolProperty(name='Detailed BOQ',default=True)
    live_preview: BoolProperty(name='Live 3D Preview',default=True,update=on_update)
    carcass_rate: FloatProperty(name='Carcass THB/m²',default=850,min=0,update=on_update)
    back_rate: FloatProperty(name='Back THB/m²',default=280,min=0,update=on_update)
    door_rate: FloatProperty(name='Door THB/m²',default=1100,min=0,update=on_update)
    edge_rate: FloatProperty(name='Edge THB/m',default=30,min=0,update=on_update)
    hinge_rate: FloatProperty(name='Hinge THB/pc',default=80,min=0,update=on_update)
    handle_rate: FloatProperty(name='Handle THB/pc',default=150,min=0,update=on_update)
    nose_gap_rate: FloatProperty(name='Nose Gap Rail THB/m',default=120,min=0,update=on_update)
    shelf_support_rate: FloatProperty(name='Shelf Support THB/pc',default=8,min=0,update=on_update)
    labor_rate: FloatProperty(name='Assembly THB/set',default=1200,min=0,update=on_update)
    plinth_rate: FloatProperty(name='Plinth THB/m',default=200,min=0,update=on_update)
    kickstand_rate: FloatProperty(name='Kickstand THB/pc',default=120,min=0,update=on_update)
    mount_bracket_rate: FloatProperty(name='Wall Bracket THB/pc',default=150,min=0,update=on_update)
    mount_rail_rate: FloatProperty(name='Wall Rail THB/m',default=250,min=0,update=on_update)
    waste_percent: FloatProperty(name='Panel Waste %',default=10,min=0,max=100,update=on_update)
    hinges_per_door: IntProperty(name='Hinges per Door',default=2,min=2,max=6,update=on_update)
    status: StringProperty(name='Status',default='Ready')
    selected_cabinet: StringProperty(name='Editing Cabinet ID',default='')


class IGZ_OT_starter_pair(bpy.types.Operator):
    bl_idname='igz_cabinet.create_starter_pair'
    bl_label='Create Kitchen + Wall Cabinet Example'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.igz_cabinet
        _,preview,generated=roots()
        base=priced_settings(context.scene, p, 'KITCHEN')
        base.update(cabinet_type='BASE',front_style='CLOSED',countertop_material='TERRAZZO',include_countertop=True,include_backsplash=True,width=1800.0,depth=600.0,height=900.0,installation_height=0.0,base_type='PLINTH',plinth_height=100.0,vertical_divisions=1,horizontal_divisions=0,door_columns=2,door_rows=1,use_nose_gap=False,show_handles=True)
        wall=dict(base)
        wall.update(resolved_rates(context.scene, 'WALL'))
        wall.update(cabinet_type='WALL',front_style='CLOSED',include_countertop=False,depth=350.0,height=720.0,installation_height=1450.0,base_type='NONE',vertical_divisions=1,horizontal_divisions=0)
        try:
            calculate(dict(base)); calculate(dict(wall))
            base_id=PREFIX+uuid.uuid4().hex[:8].upper()
            wall_id=PREFIX+uuid.uuid4().hex[:8].upper()
            cb=make_cabinet(generated,base,base_id)
            cw=make_cabinet(generated,wall,wall_id)
            # Keep generated examples aligned exactly like the live preview.
            offset_cabinet_y_mm(cw, wall_cabinet_y_offset_mm(base, wall))
            cb['igz_starter_example']=True
            cw['igz_starter_example']=True
        except Exception as e:
            self.report({'ERROR'},'Starter example failed: '+str(e)); return {'CANCELLED'}
        remove_collection_contents(preview)
        p.live_preview=False
        p.selected_cabinet=base_id
        p.status='Kitchen + Wall examples created. Select component and Load Selected Settings to edit.'
        self.report({'INFO'},p.status)
        return {'FINISHED'}


class IGZ_OT_default_l_model(bpy.types.Operator):
    bl_idname = 'igz_cabinet.default_l_model'
    bl_label = 'Load Default L Kitchen'
    bl_description = 'Load the screenshot-matched left-return L kitchen and wall settings; preserve currency and BOQ price rates'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _REFRESHING
        # Batch updates so intermediate states do not enqueue partial previews.
        previous_refreshing = _REFRESHING
        _REFRESHING = True
        try:
            apply_default_l_model(context.scene)
            context.scene['igz_pair_initialized'] = True
            context.scene['igz_countertop_terrazzo_migrated_v29'] = True
        finally:
            _REFRESHING = previous_refreshing
        refresh_preview_now()
        self.report({'INFO'}, 'Default L-shaped kitchen and wall cabinets loaded')
        return {'FINISHED'}


class IGZ_OT_import_web_json(bpy.types.Operator):
    bl_idname = 'igz_cabinet.import_web_json'
    bl_label = 'Import Web App Project (.json)'
    bl_description = ('Load a kitchen + wall cabinet project exported from the BOQ web app '
                      '("Export to Blender"). Replaces the current cabinet settings and shared prices')
    bl_options = {'REGISTER', 'UNDO'}
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        global _REFRESHING, _LOADING_SETTINGS
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                plan = web_import.plan_web_import(json.load(f))
        except Exception as ex:
            self.report({'ERROR'}, str(ex)); return {'CANCELLED'}
        scene = context.scene
        ensure_price_library(scene)
        failed = []
        def apply(target, values):
            for key, val in values.items():
                try:
                    setattr(target, key, val)
                except Exception as ex:
                    failed.append(f'{key}: {ex}')
        prev_refresh, prev_loading = _REFRESHING, _LOADING_SETTINGS
        _REFRESHING = True
        try:
            apply(scene.igz_cabinet, plan['base'])
            scene.igz_cabinet.drawer_banks.clear()
            for b in plan['banks']:
                item = scene.igz_cabinet.drawer_banks.add()
                apply(item, dict(run=b['run'], column=b['column'], count=b['count'], hardware='HANDLE'))
                for i, v in enumerate(b['pulls'], 1):
                    apply(item, {f'pull_{i}': v})
            if plan['wall']:
                apply(scene.igz_wall, plan['wall'])
            else:
                scene.igz_wall.enabled = False
            _LOADING_SETTINGS = True
            apply(scene.igz_price_library, plan['rates'])
            scene.igz_price_library.kitchen_override_enabled = False
            scene.igz_price_library.wall_override_enabled = False
            scene['igz_pair_initialized'] = True
        finally:
            _REFRESHING, _LOADING_SETTINGS = prev_refresh, prev_loading
        refresh_preview_now()
        for line in plan['skipped'] + plan['notes'] + failed:
            print('BOQ web import:', line)
        extra = len(plan['skipped']) + len(failed)
        self.report({'WARNING'} if extra else {'INFO'},
                    'Web project imported' + (f'; {extra} item(s) not applied, see the system console' if extra else ''))
        return {'FINISHED'}


class IGZ_OT_add_drawer_bank(bpy.types.Operator):
    bl_idname='igz_cabinet.add_drawer_bank'
    bl_label='Add Drawer Bank'
    bl_description='Create an independently controlled drawer bank in an unused column on the selected run'
    bl_options={'REGISTER','UNDO'}
    target_run: EnumProperty(name='Cabinet Run',items=[
        ('AUTO','Automatic','First available drawer bay'),
        ('MAIN','Main Run','Add to the main cabinet run'),
        ('LEFT','Left Return','Add to the left cabinet return'),
        ('RIGHT','Right Return','Add to the right cabinet return')],default='AUTO')
    def execute(self,context):
        p=context.scene.igz_cabinet
        existing={(b.run,int(b.column)) for b in p.drawer_banks}
        active=active_drawer_runs(p)
        if self.target_run!='AUTO' and self.target_run not in active:
            self.report({'WARNING'},f'{self.target_run} run is not present in the current {p.layout_shape} layout')
            return {'CANCELLED'}
        runs=active if self.target_run=='AUTO' else (self.target_run,)
        destination=None
        for run in runs:
            for col in range(1,run_columns_for_ui(p,run)+1):
                if (run,col) not in existing:
                    destination=(run,col)
                    break
            if destination: break
        if destination is None:
            self.report({'WARNING'},'No empty drawer columns remain in the selected run')
            return {'CANCELLED'}
        bank=p.drawer_banks.add()
        bank.run,bank.column=destination
        bank.count=p.drawer_count
        bank.hardware='HANDLE'
        p.enable_drawers=True
        p.drawer_multi_bank_mode=True
        repair_drawer_controls(p)
        refresh_preview_now()
        self.report({'INFO'},f'Drawer bank added: {destination[0]} column {destination[1]}')
        return {'FINISHED'}

class IGZ_OT_remove_drawer_bank(bpy.types.Operator):
    bl_idname='igz_cabinet.remove_drawer_bank'
    bl_label='Remove Drawer Bank'
    bl_options={'REGISTER','UNDO'}
    index: IntProperty(default=0,min=0)
    def execute(self,context):
        banks=context.scene.igz_cabinet.drawer_banks
        if self.index >= len(banks): return {'CANCELLED'}
        banks.remove(self.index)
        if len(banks)==0:
            context.scene.igz_cabinet.enable_drawers=False
        refresh_preview_now()
        return {'FINISHED'}


class IGZ_OT_preview(bpy.types.Operator):
    bl_idname='igz_cabinet.preview'
    bl_label='Refresh Live Preview'
    bl_options={'REGISTER'}
    def execute(self,context):
        refresh_preview_now()
        self.report({'INFO'},context.scene.igz_cabinet.status)
        return {'FINISHED'}


class IGZ_OT_clear_preview(bpy.types.Operator):
    bl_idname='igz_cabinet.clear_preview'
    bl_label='Clear Preview'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        _,preview,_=roots()
        context.scene.igz_cabinet.live_preview=False
        remove_collection_contents(preview)
        context.scene.igz_cabinet.status='Preview cleared'
        return {'FINISHED'}


class IGZ_OT_generate(bpy.types.Operator):
    bl_idname='igz_cabinet.generate'
    bl_label='Generate Cabinet'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.igz_cabinet
        try: d,_,totals=calculate_layout(priced_settings(context.scene,p, 'WALL' if p.cabinet_type in WALL_TYPES else 'KITCHEN'))
        except Exception as e:
            self.report({'ERROR'},str(e)); return {'CANCELLED'}
        _,preview,generated=roots()
        cab_id=PREFIX+uuid.uuid4().hex[:8].upper()
        make_layout(generated,d,cab_id)
        remove_collection_contents(preview)
        p.live_preview=False
        p.selected_cabinet=cab_id
        p.status=f'Generated {cab_id}. Edit values, then click Apply Changes to Cabinet.'
        self.report({'INFO'},p.status)
        return {'FINISHED'}


def find_cabinet(obj):
    if obj is None: return None
    for c in obj.users_collection:
        if c.get('igz_cabinet_id') and not c.get('igz_preview'):
            # Multi-run layout parts belong to a child module collection.
            # Load/save settings against the shared layout root, not the child.
            for parent in bpy.data.collections:
                if c in parent.children and parent.get('igz_layout_root'):
                    return parent
            return c
    return None


class IGZ_OT_edit(bpy.types.Operator):
    bl_idname='igz_cabinet.load_selected'
    bl_label='Load Selected Cabinet Settings'
    bl_options={'REGISTER'}
    def execute(self,context):
        c=find_cabinet(context.active_object)
        if c is None:
            self.report({'WARNING'},'Select a generated cabinet component first'); return {'CANCELLED'}
        d=json.loads(c['igz_params'])
        p=context.scene.igz_cabinet
        p.live_preview=False
        d.setdefault('front_style','OPEN' if d.get('cabinet_type') in OPEN_TYPES else 'CLOSED')
        # Map legacy types to the two current cabinet categories.
        if d.get('cabinet_type') in ('OPEN','TALL'): d['cabinet_type']='BASE'
        elif d.get('cabinet_type') == 'WALL_OPEN': d['cabinet_type']='WALL'
        # Migrate old saved cabinets with only door_count to a single door row.
        if 'door_columns' not in d:
            d['door_columns']=max(1,int(d.get('door_count',2)))
        if 'door_rows' not in d:
            d['door_rows']=1
        # Old v1.6 cabinets had only show_plinth + support_type and no installation height.
        if 'base_type' not in d:
            d['base_type'] = ('PLINTH' if d.get('support_type','PLINTH')=='PLINTH' else 'LEGS') if d.get('show_plinth',d.get('cabinet_type')=='BASE') and d.get('cabinet_type')=='BASE' else 'NONE'
        if 'installation_height' not in d:
            # Preserve the actual geometry placement of old wall cabinets (Z=0).
            d['installation_height']=0.0
        global _LOADING_SETTINGS
        _LOADING_SETTINGS=True
        try:
            # CollectionProperty items cannot be assigned with setattr.
            # Rebuild individual drawer banks from the saved model's JSON.
            for k,v in d.items():
                if k!='drawer_banks' and k not in PRICE_RATE_KEYS and k not in (
                        'boq_currency','fx_thb_per_sgd','fx_thb_per_usd') and hasattr(p,k):
                    setattr(p,k,v)
            p.drawer_banks.clear()
            for item in d.get('drawer_banks',[]):
                bank=p.drawer_banks.add()
                bank.run=item.get('run','MAIN')
                bank.column=int(item.get('column',1))
                bank.count=int(item.get('count',3))
                bank.hardware=item.get('hardware','HANDLE')
                for n,pull in enumerate(item.get('pulls',[])[:6],1):
                    setattr(bank,f'pull_{n}',float(pull))
        finally:
            _LOADING_SETTINGS=False
        if p.enable_drawers:
            global _REFRESHING
            _REFRESHING=True
            try: repair_drawer_controls(p)
            finally: _REFRESHING=False
        # Older projects may contain adjustable shelf settings. Preserve their
        # saved geometry until the user explicitly applies changes; after that,
        # only structural horizontal dividers generate horizontal boards.
        p.shelf_count=0
        p.shelf_clearance=0.0
        p.selected_cabinet=c['igz_cabinet_id']
        p.status='Loaded '+p.selected_cabinet
        return {'FINISHED'}


class IGZ_OT_update_existing(bpy.types.Operator):
    bl_idname='igz_cabinet.update_existing'
    bl_label='Update Loaded Cabinet'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.igz_cabinet
        cab_id=p.selected_cabinet
        active=find_cabinet(context.active_object)
        if active is not None:
            cab_id=active.get('igz_cabinet_id',cab_id)
            p.selected_cabinet=cab_id
        if not cab_id:
            self.report({'WARNING'},'Select a cabinet component and Load Selected Cabinet Settings first'); return {'CANCELLED'}
        _,preview,generated=roots()
        old=bpy.data.collections.get(cab_id)
        if old is None or old.get('igz_preview'):
            self.report({'ERROR'},'Existing cabinet not found'); return {'CANCELLED'}
        try: d,_,totals=calculate_layout(priced_settings(context.scene,p, 'WALL' if p.cabinet_type in WALL_TYPES else 'KITCHEN'))
        except Exception as e:
            self.report({'ERROR'},str(e)); return {'CANCELLED'}
        # Preserve the previously generated wall cabinet's rear-wall
        # alignment when applying changes. v3.5.2 stored placement as mesh
        # object translations; new models also store an explicit offset.
        old_y_mm = 0.0
        if d['cabinet_type'] in WALL_TYPES:
            saved_offset = old.get('igz_placement_y_mm')
            if saved_offset is not None:
                old_y_mm = float(saved_offset)
            elif old.objects:
                old_y_mm = next(iter(old.objects)).location.y * 1000.0
            # Keep the same rear-wall plane even when wall cabinet depth
            # changes; otherwise a resized cabinet would develop a gap.
            old_params = json.loads(old.get('igz_params', '{}'))
            old_y_mm += (float(old_params.get('depth', d['depth'])) - d['depth']) / 2.0
        remove_collection_contents(old)
        bpy.data.collections.remove(old)
        updated, _ = make_layout(generated,d,cab_id)
        if d['cabinet_type'] in WALL_TYPES:
            offset_cabinet_y_mm(updated, old_y_mm)
        remove_collection_contents(preview)
        p.live_preview=False
        p.status=f'Updated {cab_id} | {money_label(context.scene,totals["total"])}'
        return {'FINISHED'}



class IGZ_OT_validate_model(bpy.types.Operator):
    bl_idname='igz_cabinet.validate_model'
    bl_label='Validate Model'
    bl_description='Inspect dimensions, door/divider alignment, sink clearances and BOQ without editing the model'
    bl_options={'REGISTER'}

    def invoke(self,context,event):
        try:
            base,wall=pair_settings(context.scene)
            self._findings=validate_model_report(base,wall,
                context.scene.igz_cabinet.enabled,context.scene.igz_wall.enabled)
        except Exception as exc:
            self._findings=[dict(severity='ERROR',unit='Both',run='SETTINGS',message=str(exc))]
        return context.window_manager.invoke_props_dialog(self,width=750)

    def draw(self,context):
        layout=self.layout
        findings=getattr(self,'_findings',[])
        errors=sum(x['severity']=='ERROR' for x in findings)
        warnings=sum(x['severity']=='WARNING' for x in findings)
        layout.label(text=f'Model validation: {errors} errors, {warnings} warnings',
                     icon='ERROR' if errors else 'INFO')
        if not findings:
            layout.label(text='No automated issues detected; physical fabrication review is still required',icon='CHECKMARK')
        else:
            for x in findings:
                box=layout.box()
                row=box.row(align=True)
                row.label(text=x['severity']+' | '+x['unit']+' / '+x['run'],
                          icon='ERROR' if x['severity']=='ERROR' else 'INFO')
                box.label(text=x['message'][:110])
        layout.separator()
        layout.label(text='Diagnostic only: no geometry, settings or BOQ changes')

    def execute(self,context):
        findings=getattr(self,'_findings',[])
        errors=sum(x['severity']=='ERROR' for x in findings)
        warnings=sum(x['severity']=='WARNING' for x in findings)
        self.report({'WARNING'} if errors else {'INFO'},
                    f'Model validation: {errors} errors, {warnings} warnings')
        return {'FINISHED'}



class IGZ_OT_export_price_library(bpy.types.Operator):
    bl_idname='igz_cabinet.export_price_library'
    bl_label='Export Price Library JSON'
    bl_description='Save all central THB prices and currency choices for reuse in another .blend'
    filepath: StringProperty(subtype='FILE_PATH',default='Integrazo_Material_Price_Library.json')
    filter_glob: StringProperty(default='*.json',options={'HIDDEN'})
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self,context):
        try:
            data=price_library_payload(context.scene)
            with open(bpy.path.ensure_ext(self.filepath,'.json'),'w',encoding='utf-8') as f:
                json.dump(data,f,indent=2,ensure_ascii=False)
            self.report({'INFO'},'Price Library saved (rates in THB)')
            return {'FINISHED'}
        except Exception as ex:
            self.report({'ERROR'},str(ex));return {'CANCELLED'}


class IGZ_OT_import_price_library(bpy.types.Operator):
    bl_idname='igz_cabinet.import_price_library'
    bl_label='Import Price Library JSON'
    bl_description='Replace shared rates/currency from JSON; project-specific overrides remain untouched'
    filepath: StringProperty(subtype='FILE_PATH',default='Integrazo_Material_Price_Library.json')
    filter_glob: StringProperty(default='*.json',options={'HIDDEN'})
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self,context):
        global _LOADING_SETTINGS
        try:
            with open(self.filepath,'r',encoding='utf-8') as f:
                data=validate_library_payload(json.load(f))
            ensure_price_library(context.scene)
            lib=context.scene.igz_price_library
            old_loading=_LOADING_SETTINGS
            _LOADING_SETTINGS=True
            try:
                for name,val in data['rates_thb'].items(): setattr(lib,name,val)
                for name in ('fx_thb_per_sgd','fx_thb_per_usd'):
                    setattr(lib,name,data[name])
                lib.boq_currency=data['selected_currency']
            finally:
                _LOADING_SETTINGS=old_loading
            on_price_update(lib,context)
            self.report({'INFO'},'Price Library imported; BOQ uses the new rates immediately')
            return {'FINISHED'}
        except Exception as ex:
            self.report({'ERROR'},str(ex));return {'CANCELLED'}


class IGZ_OT_unify_prices(bpy.types.Operator):
    bl_idname='igz_cabinet.use_shared_prices'
    bl_label='Use Shared Prices for Both Cabinets'
    bl_description='Disable project price overrides; kitchen and wall will use the same live central rates'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        lib=context.scene.igz_price_library
        lib.kitchen_override_enabled=False
        lib.wall_override_enabled=False
        on_price_update(lib,context)
        self.report({'INFO'},'Kitchen and Wall now use the shared Price Library')
        return {'FINISHED'}

class IGZ_OT_view_boq(bpy.types.Operator):
    bl_idname='igz_cabinet.view_boq'
    bl_label='View Detailed BOQ'
    bl_options={'REGISTER'}
    def invoke(self,context,event):
        return context.window_manager.invoke_props_dialog(self,width=720)
    def draw(self,context):
        layout=self.layout
        try:
            base,wall=pair_settings(context.scene)
            code,divisor=currency_settings(context.scene)
            layout.label(text=f'BOQ currency: {code} | Manual rate: 1 {code} = {divisor:g} THB')
            grand=0.0
            total_area=total_edge=total_edge_cost=total_waste=0.0
            for unit_name, d, enabled in (('Kitchen Cabinet',base,context.scene.igz_cabinet.enabled),('Wall Cabinet',wall,context.scene.igz_wall.enabled)):
                if not enabled: continue
                _,parts,totals=calculate_layout(d)
                grand+=totals['total']
                total_area+=totals['panel_area_m2']; total_edge+=totals['edge_m']
                total_edge_cost+=totals['edge_cost']; total_waste+=totals['waste_cost']
                layout.label(text=unit_name+' — '+money_label(context.scene,totals['total']),icon='OUTLINER_COLLECTION')
                for part in parts:
                    row=layout.row(align=True)
                    row.label(text=part['name'])
                    row.label(text=f"{part['pieces']} pcs")
                    row.label(text=f"{part['length_mm']:g} x {part['width_mm']:g}")
                    row.label(text=money_label(context.scene,part['material_cost']))
            layout.separator()
            layout.label(text=f'Panels: {total_area:.3f} m² | Edge: {total_edge:.3f} m')
            layout.label(text='Edge: '+money_label(context.scene,total_edge_cost)+' | Waste: '+money_label(context.scene,total_waste))
            layout.label(text='COMBINED TOTAL: '+money_label(context.scene,grand))
        except Exception as e: layout.label(text=str(e),icon='ERROR')
    def execute(self,context): return {'FINISHED'}


class IGZ_OT_export_boq(bpy.types.Operator):
    bl_idname='igz_cabinet.export_boq'
    bl_label='Export Detailed BOQ CSV'
    bl_options={'REGISTER'}
    filepath: StringProperty(subtype='FILE_PATH',default='Integrazo_Cabinet_Detailed_BOQ.csv')
    filter_glob: StringProperty(default='*.csv',options={'HIDDEN'})
    export_all: BoolProperty(name='Export All Generated Cabinets',default=True)
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self,context):
        try:
            rows=[]
            summary_rows=[]
            code,divisor=currency_settings(context.scene)
            base,wall=pair_settings(context.scene)
            for cid,d,enabled in (('KITCHEN',base,context.scene.igz_cabinet.enabled),('WALL',wall,context.scene.igz_wall.enabled)):
                if not enabled: continue
                _,parts,totals=calculate_layout(d)
                rows.extend((cid,p) for p in parts)
                summary_rows.append((cid,totals))
            columns=['cabinet_id','category','name','length_mm','width_mm','thickness_mm',
                     'pieces','unit','quantity','currency','thb_per_currency','unit_rate',
                     'material_cost','unit_rate_thb','material_cost_thb','edge_m','edge_sides']
            path=bpy.path.ensure_ext(self.filepath,'.csv')
            with open(path,'w',newline='',encoding='utf-8-sig') as f:
                writer=csv.DictWriter(f,fieldnames=columns)
                writer.writeheader()
                for cid,p in rows:
                    rec={'cabinet_id':cid,**p}
                    rec.update(currency=code,thb_per_currency=divisor,
                               unit_rate_thb=p['unit_rate'],material_cost_thb=p['material_cost'],
                               unit_rate=round(p['unit_rate']/divisor,4),
                               material_cost=round(p['material_cost']/divisor,2))
                    writer.writerow(rec)
                for cid,t in summary_rows:
                    for category,name,unit,quantity,total in (
                        ('EDGE','Edge Banding Cost','m',t['edge_m'],t['edge_cost']),
                        ('WASTE','Panel Waste Allowance','set',1,t['waste_cost']),
                        ('TOTAL','Grand Total '+code,'set',1,t['total'])):
                        writer.writerow({'cabinet_id':cid,'category':category,'name':name,
                            'unit':unit,'quantity':quantity,'currency':code,
                            'thb_per_currency':divisor,'material_cost':round(total/divisor,2),
                            'material_cost_thb':total})
            self.report({'INFO'},'Exported '+str(len(rows))+' BOQ rows in '+code)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'},str(e)); return {'CANCELLED'}



class IGZ_OT_export_boq_excel(bpy.types.Operator):
    bl_idname='igz_cabinet.export_boq_excel'
    bl_label='Export Editable Excel BOQ (.xlsx)'
    bl_description='Export live Blender totals, automatic THB/SGD/USD conversion, editable rates and formulas for all cabinet runs'
    bl_options={'REGISTER'}
    filepath: StringProperty(subtype='FILE_PATH',default='Integrazo_Cabinet_Editable_BOQ.xlsx')
    filter_glob: StringProperty(default='*.xlsx',options={'HIDDEN'})
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self,context):
        try:
            from .boq_excel_export import export_boq_xlsx
            base, wall = pair_settings(context.scene)
            lines=[]
            blender_totals = {'KITCHEN':0.0,'WALL':0.0}
            for cid,params,enabled in (('KITCHEN',base,context.scene.igz_cabinet.enabled),
                                        ('WALL',wall,context.scene.igz_wall.enabled)):
                if not enabled:
                    continue
                _,parts,totals=calculate_layout(params)
                blender_totals[cid]=totals['total']
                lines.extend((cid,part) for part in parts)
            code,rate=currency_settings(context.scene)
            lib=context.scene.igz_price_library
            path=bpy.path.ensure_ext(self.filepath,'.xlsx')
            count=export_boq_xlsx(path,lines,base,wall,code,rate,
                blender_totals=blender_totals,
                fx_thb_per_sgd=float(lib.fx_thb_per_sgd),
                fx_thb_per_usd=float(lib.fx_thb_per_usd))
            self.report({'INFO'},f'Exported {count} editable BOQ rows with Excel formulas')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'},str(e))
            return {'CANCELLED'}



class IGZ_OT_reset(bpy.types.Operator):
    bl_idname='igz_cabinet.reset_settings'
    bl_label='Reset Input Values'
    bl_description='Reset editable cabinet dimensions and unit rates to defaults; existing cabinets are not deleted'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.igz_cabinet
        for key in settings_dict(p):
            try:
                prop=IGZCabinetSettings.bl_rna.properties.get(key)
                if prop is not None and not prop.is_readonly:
                    setattr(p,key,prop.default)
            except Exception:
                pass
        p.drawer_banks.clear()
        p.status='Default values restored. Existing cabinet geometry is unchanged.'
        return {'FINISHED'}

class IGZ_PT_panel(bpy.types.Panel):
    bl_label = 'BOQ-Cabinet Generator v4.9.0'
    bl_idname = 'IGZ_PT_cabinet'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'BOQ-Cabinet'

    def draw_unit(self, layout, p, label, is_wall=False):
        box = layout.box()
        expand_key = 'expand_dimensions' if not is_wall else 'expand_wall_dimensions'
        expanded = getattr(p, expand_key)
        box.prop(p, expand_key, text=label,
                 icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=False)
        box.prop(p, 'enabled', text='Enable ' + ('Wall Cabinet' if is_wall else 'Kitchen Cabinet'))
        if not expanded or not p.enabled: return
        box.label(text='Front Type: Closed Doors / Open Shelves')
        box.prop(p, 'front_style', text='Front Type')
        box.prop(p, 'layout_shape')
        if p.layout_shape=='L':
            box.prop(p,'l_corner_side')
            box.prop(p,'return_left_length' if p.l_corner_side=='LEFT' else 'return_right_length')
        elif p.layout_shape=='U':
            box.prop(p,'return_left_length')
            box.prop(p,'return_right_length')
        if p.layout_shape!='STRAIGHT':
            box.label(text='Main width; returns measured from rear wall')
            box.label(text='3D modules and BOQ include all runs')
            if p.front_style=='CLOSED':
                box.prop(p,'layout_align_dividers')
                if p.layout_align_dividers:
                    box.label(text=f'Main: {p.door_columns} doors / {max(0,p.door_columns-1)} vertical dividers')
            safety=box.box()
            safety.prop(p,'corner_smart_enabled')
            if p.corner_smart_enabled:
                safety.prop(p,'corner_auto_filler')
                if p.corner_auto_filler:
                    safety.prop(p,'corner_min_filler_mm')
                    safety.prop(p,'corner_max_filler_mm')
                else:
                    if p.layout_shape=='U' or p.l_corner_side=='LEFT':
                        safety.prop(p,'corner_manual_left_mm')
                    if p.layout_shape=='U' or p.l_corner_side=='RIGHT':
                        safety.prop(p,'corner_manual_right_mm')
                try:
                    overview=corner_layout_plan(settings_dict(p))
                    for side,filled in overview['fill'].items():
                        safety.label(text=f'{side.title()} filler: {filled:.0f} mm',icon='INFO')
                    for name,unit,*_ in overview['modules']:
                        if unit.get('enable_drawers'):
                            for bank in unit.get('drawer_banks',[]):
                                limits=bank.get('_corner_safe_limits_mm',[])
                                if limits:
                                    safety.label(text=f'{name} C{bank["column"]} max pull: {min(limits):.0f} mm')
                    for note in overview['notes']:
                        if 'safe pull' in note or 'swing C' in note or 'capped' in note:
                            safety.label(text=note[:93],icon='ERROR')
                except (ValueError,KeyError,TypeError,IndexError) as err:
                    safety.label(text=str(err)[:85],icon='ERROR')
                safety.label(text='Full slide travel sizes filler; swing limited')
                safety.label(text='Safe 3D motion; original sliders preserved')
                safety.label(text='Review real hinges/handles before fabrication')
            box.prop(p,'customize_return_runs')
            active_sides=([p.l_corner_side] if p.layout_shape=='L' else ['LEFT','RIGHT'])
            for side in active_sides:
                suffix=side.lower()
                detail=box.box()
                if p.customize_return_runs:
                    detail.label(text=side.title()+' Return: Frames & Detail')
                    detail.prop(p,'return_'+suffix+'_door_columns')
                    detail.prop(p,'return_'+suffix+'_door_rows')
                    if not (p.layout_align_dividers and p.front_style=='CLOSED'):
                        detail.prop(p,'return_'+suffix+'_vertical_divisions')
                    else:
                        n=getattr(p,'return_'+suffix+'_door_columns')
                        detail.label(text=f'{max(0,n-1)} vertical dividers (matched to {n} doors)')
                    detail.prop(p,'return_'+suffix+'_horizontal_divisions')
                    detail.prop(p,'return_'+suffix+'_door_style')
                    if getattr(p,'return_'+suffix+'_door_style').startswith('SHAKER'):
                        detail.prop(p,'return_'+suffix+'_frame_width')
                elif p.front_style=='CLOSED':
                    run=getattr(p,'return_'+suffix+'_length')-p.depth
                    if run>0 and p.width>0:
                        n=automatic_return_door_columns(
                            {'door_columns':p.door_columns,'width':p.width},run)
                        detail.label(text=f'{side.title()} Return (Auto): {n} doors / {n-1} dividers')
        for key in ('width','depth','height'):
            box.prop(p,key)
        if is_wall:
            box.prop(p,'installation_height',text='Bottom from FFL (mm)')
            box.label(text='Wall fixing: brackets + rail')
        else:
            box.prop(p,'base_type')
            if p.base_type != 'NONE':
                box.prop(p,'plinth_height')
                if p.base_type == 'PLINTH': box.prop(p,'plinth_setback')
        box.label(text='Laminate Materials (Auto UV)')
        box.prop(p,'carcass_finish')
        box.prop(p,'carcass_tone')
        if p.front_style=='CLOSED':
            box.prop(p,'door_style')
            box.prop(p,'door_finish')
            box.prop(p,'door_tone')
            if p.door_style!='FLAT':
                box.prop(p,'shaker_frame_width')
                if p.door_style=='SHAKER_GLASS':
                    box.prop(p,'shaker_glass_thickness')
                else:
                    box.prop(p,'shaker_recess_depth')
        box.label(text='Top & Bottom Between Side Panels')
        for key in ('carcass_thickness','back_thickness','back_inset'):
            box.prop(p,key)
        # In L/U matched mode, divider count comes from the door columns.
        # Do not show a stale editable value that has no effect on the model.
        if not (p.layout_shape!='STRAIGHT' and p.layout_align_dividers and p.front_style=='CLOSED'):
            box.prop(p,'vertical_divisions')
        box.prop(p,'horizontal_divisions')
        if p.front_style == 'CLOSED':
            box.label(text='Door Layout' if p.layout_shape=='STRAIGHT' else 'Main Run Door Layout')
            for key in ('door_columns','door_rows','door_gap','hinges_per_door'):
                box.prop(p,key)
            box.prop(p,'use_nose_gap')
            if p.use_nose_gap: box.prop(p,'nose_gap_height')
            else: box.prop(p,'show_handles')
            box.prop(p,'door_open_angle',text='Kitchen Door Opening' if not is_wall else 'Wall Door Opening',slider=True)
            box.label(text='Independent from the other cabinet',icon='LOCKED')
        if not is_wall and p.front_style=='CLOSED':
            drawer_ui=box.box()
            drawer_ui.label(text='Real Pull-Out Drawers & Hardware',icon='MOD_ARRAY')
            drawer_ui.prop(p,'enable_drawers')
            if p.enable_drawers:
                drawer_ui.label(text='Individual drawers + swing doors',icon='CHECKMARK')
                drawer_ui.operator('igz_cabinet.add_drawer_bank',text='Add Drawer Bank (Auto)',icon='ADD').target_run='AUTO'
                if p.layout_shape!='STRAIGHT':
                    drawer_ui.label(text='Add drawers to each L/U cabinet run:',icon='MOD_ARRAY')
                    for run in active_drawer_runs(p):
                        count=run_columns_for_ui(p,run)
                        used=sum(1 for bank in p.drawer_banks if bank.run==run)
                        line=drawer_ui.row(align=True)
                        name={'MAIN':'Main Run','LEFT':'Left Return','RIGHT':'Right Return'}[run]
                        line.label(text=f'{name}: {used}/{count} bays')
                        btn=line.row(align=True)
                        btn.enabled=used<count
                        btn.operator('igz_cabinet.add_drawer_bank',text='Add',icon='ADD').target_run=run
                for key in ('drawer_depth','drawer_box_thickness',
                            'drawer_bottom_thickness','drawer_slide_clearance'):
                    drawer_ui.prop(p,key)
                max_travel=drawer_safe_travel_mm(p.drawer_depth)
                drawer_ui.label(text=f'Max pull travel: {max_travel:.1f} mm',icon='INFO')
                for ix,bank in enumerate(p.drawer_banks):
                    detail=drawer_ui.box()
                    head=detail.row(align=True)
                    head.label(text=f'Bank {ix+1} - {bank.run} C{bank.column}',icon='MOD_ARRAY')
                    head.operator('igz_cabinet.remove_drawer_bank',text='',icon='X').index=ix
                    if p.layout_shape!='STRAIGHT': detail.prop(bank,'run')
                    detail.prop(bank,'column')
                    max_cols=run_columns_for_ui(p,bank.run)
                    detail.label(text=f'Available columns in run: {max_cols}')
                    detail.prop(bank,'count')
                    detail.label(text='Handles + fixed/moving runners')
                    detail.label(text='Pull each drawer independently (mm):')
                    for n in range(1,bank.count+1):
                        # Numeric fields are more reliable than Blender's 0..900
                        # sliders when the installed slides only permit ~365 mm.
                        detail.prop(bank,f'pull_{n}',text=f'Drawer {n} Pull (mm)')
                drawer_ui.label(text='Other door columns can still swing open')
                drawer_ui.label(text='Door Rows affect swing-door columns only',icon='INFO')
                drawer_ui.label(text='Horizontal Dividers skip drawer columns')
                if p.layout_shape!='STRAIGHT' and p.drawer_banks:
                    # Show corner clearance messages without preventing users
                    # from restoring or editing older saved L/U models.
                    try:
                        for warning in layout_drawer_collision_warnings(settings_dict(p))[:3]:
                            alert=drawer_ui.box()
                            alert.alert=True
                            alert.label(text='Corner drawer clearance',icon='ERROR')
                            alert.label(text=warning[:90])
                    except (ValueError,KeyError,IndexError,TypeError):
                        pass  # Actual validation and status still report geometry errors.

    def draw(self,context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        scene = context.scene
        if not hasattr(scene,'igz_cabinet') or not hasattr(scene,'igz_wall'):
            layout.label(text='Enable add-on to load cabinet settings',icon='ERROR')
            return
        ensure_price_library(scene)
        p = scene.igz_cabinet
        wall = scene.igz_wall
        model_header=layout.box()
        model_header.label(text='1. Cabinet Model & Configuration',icon='MESH_CUBE')
        layout.operator('igz_cabinet.default_l_model',
                        text='Load Default L Kitchen', icon='FILE_REFRESH')
        layout.operator('igz_cabinet.import_web_json',
                        text='Import Web App Project (.json)', icon='IMPORT')
        self.draw_unit(layout,p,'Kitchen Cabinet',False)
        self.draw_unit(layout,wall,'Wall Cabinet',True)
        box=layout.box()
        box.prop(p,'expand_countertop',text='Kitchen Countertop',
                 icon='TRIA_DOWN' if p.expand_countertop else 'TRIA_RIGHT',emboss=False)
        if p.expand_countertop and p.enabled:
            box.prop(p,'include_countertop', text='Include Countertop')
            if p.include_countertop:
                for key in ('countertop_material','countertop_thickness','countertop_front_overhang','countertop_side_overhang'):
                    box.prop(p,key)
                sinkbox=box.box()
                sinkbox.label(text='Sink / Countertop Cutout')
                sinkbox.prop(p,'include_sink')
                if p.include_sink:
                    sinkbox.prop(p,'sink_quantity')
                    one=sinkbox.box()
                    one.label(text='Sink 1 - Size and Position')
                    if p.layout_shape!='STRAIGHT': one.prop(p,'sink_run')
                    for key in ('sink_width','sink_depth','sink_bowl_depth',
                                'sink_x_offset','sink_front_setback'):
                        one.prop(p,key)
                    if p.sink_quantity=='2':
                        two=sinkbox.box()
                        two.label(text='Sink 2 - Independent Size and Position')
                        if p.layout_shape!='STRAIGHT': two.prop(p,'sink2_run')
                        for key in ('sink2_width','sink2_depth','sink2_bowl_depth',
                                    'sink2_x_offset','sink2_front_setback'):
                            two.prop(p,key)
                    sinkbox.prop(p,'countertop_cost_basis')
                    if p.countertop_cost_basis=='GROSS':
                        sinkbox.label(text='Gross slab billed; cutout added separately')
                    else:
                        sinkbox.label(text='Sink hole deducted; fabrication still added')
        box=layout.box()
        box.prop(p,'expand_backsplash',text='Backsplash',
                 icon='TRIA_DOWN' if p.expand_backsplash else 'TRIA_RIGHT',emboss=False)
        if p.expand_backsplash and p.enabled:
            box.prop(p,'include_backsplash', text='Include Backsplash')
            if p.include_backsplash:
                for key in ('backsplash_height','backsplash_thickness'):
                    box.prop(p,key)
        lib=scene.igz_price_library
        price_box=layout.box()
        price_box.prop(lib,'expand_library',text='2. Material & Cost Library',
                      icon='TRIA_DOWN' if lib.expand_library else 'TRIA_RIGHT',emboss=False)
        # v4.8.1: ALL pricing controls belong to expand_library. The v4.8.0
        # indentation error placed them inside the "override enabled" condition,
        # hiding the entire catalog for the normal shared-price configuration.
        if lib.expand_library:
            price_box.label(text='Shared THB rates for Kitchen + Wall')
            price_box.label(text='Change prices here: BOQ totals update live')
            if lib.wall_override_enabled or lib.kitchen_override_enabled:
                price_box.label(text='Project-specific price overrides are active',icon='INFO')

            currency_box=price_box.box()
            currency_box.label(text='Currency THB / SGD / USD')
            currency_box.prop(lib,'boq_currency',text='BOQ Currency')
            if lib.boq_currency=='SGD':
                currency_box.prop(lib,'fx_thb_per_sgd')
            elif lib.boq_currency=='USD':
                currency_box.prop(lib,'fx_thb_per_usd')
            currency_box.label(text='Manual FX rates; base prices stay in THB')

            # Display grouping is independent of the stored price IDs/JSON schema.
            # Legacy rates remain available in saved files, but are not shown
            # because new construction uses wood/color laminate prices.
            price_sections = (
                ('Board / Laminate Prices', 'expand_laminates',
                 ('wood_laminate_rate','color_laminate_rate','back_rate','backsplash_rate')),
                ('Countertop / Glass Prices', 'expand_countertops',
                 ('countertop_composite_rate','countertop_quartz_rate',
                  'countertop_terrazzo_rate','countertop_granite_rate','shaker_glass_rate')),
                ('Hinges / Drawer Slides / Handles', 'expand_hardware',
                 ('hinge_rate','handle_rate','drawer_slide_rate','drawer_handle_rate',
                  'nose_gap_rate','shelf_support_rate','mount_bracket_rate','mount_rail_rate')),
                ('Labour / Installation / Waste', 'expand_fabrication',
                 ('edge_rate','plinth_rate','kickstand_rate','sink_unit_rate',
                  'sink_cutout_rate','sink_install_rate','labor_rate','waste_percent')),
            )
            for title, field, keys in price_sections:
                sec=price_box.box()
                sec.prop(lib,field,text=title,emboss=False,
                         icon='TRIA_DOWN' if getattr(lib,field) else 'TRIA_RIGHT')
                if getattr(lib,field):
                    for key in keys:
                        sec.prop(lib,key)

            price_box.operator('igz_cabinet.export_price_library',
                               text='Export Price Library JSON',icon='EXPORT')
            price_box.operator('igz_cabinet.import_price_library',
                               text='Import Price Library JSON',icon='IMPORT')
            ov=price_box.box()
            ov.prop(lib,'expand_overrides',text='Project-Specific Price Overrides',
                emboss=False,icon='TRIA_DOWN' if lib.expand_overrides else 'TRIA_RIGHT')
            if lib.expand_overrides:
                ov.label(text='Enable only for special Kitchen / Wall rates')
                for label,enabled_key,detail_key,group in (
                    ('Kitchen','kitchen_override_enabled','expand_kitchen_override',scene.igz_kitchen_price_override),
                    ('Wall','wall_override_enabled','expand_wall_override',scene.igz_wall_price_override)):
                    item=ov.box()
                    item.prop(lib,enabled_key,text=label+' override')
                    if getattr(lib,enabled_key):
                        item.prop(lib,detail_key,text='Edit '+label+' rates',
                            emboss=False,icon='TRIA_DOWN' if getattr(lib,detail_key) else 'TRIA_RIGHT')
                        if getattr(lib,detail_key):
                            for price_items in PRICE_RATE_GROUPS.values():
                                for key,name,unit,_ in price_items:
                                    if key not in ('carcass_rate','door_rate','drawer_push_rate'):
                                        item.prop(group,key)
                ov.operator('igz_cabinet.use_shared_prices',
                            text='Use Shared Prices for Both',icon='LINKED')
        box=layout.box()
        box.prop(p,'expand_preview',text='Live 3D Model',
                 icon='TRIA_DOWN' if p.expand_preview else 'TRIA_RIGHT',emboss=False)
        if p.expand_preview:
            box.label(text='Auto updates both cabinets on parameter changes')
            box.operator('igz_cabinet.preview',text='Refresh Model',icon='FILE_REFRESH')
            box.label(text=p.status[:90])
            box.operator('igz_cabinet.validate_model',text='Validate Model',icon='VIEWZOOM')
        box=layout.box()
        box.prop(p,'expand_boq',text='3. BOQ & Export — Live Total',
                 icon='TRIA_DOWN' if p.expand_boq else 'TRIA_RIGHT',emboss=False)
        if p.expand_boq:
            code,divisor=currency_settings(scene)
            box.label(text='Price source: Shared Library / active overrides')
            box.label(text='Currency: '+code+' | 1 unit = '+str(round(divisor,4))+' THB')
            try:
                base, wall_d = pair_settings(scene)
                total=0.0
                if p.enabled:
                    _,_,bt=calculate_layout(base)
                    box.label(text='Kitchen: '+money_label(scene,bt['total']))
                    total += bt['total']
                if wall.enabled:
                    _,_,wt=calculate_layout(wall_d)
                    box.label(text='Wall: '+money_label(scene,wt['total']))
                    total += wt['total']
                if not p.enabled and not wall.enabled:
                    box.label(text='No cabinets enabled')
                box.label(text='Combined: '+money_label(scene,total))
            except Exception as e:
                box.label(text=str(e)[:85],icon='ERROR')
            box.operator('igz_cabinet.view_boq',text='View Detailed BOQ')
            box.operator('igz_cabinet.export_boq',text='Export BOQ CSV')
            box.operator('igz_cabinet.export_boq_excel',text='Export Editable Excel BOQ (.xlsx)',icon='EXPORT')


CLASSES=(IGZPriceLibrary,IGZDrawerBank,IGZCabinetSettings,
    IGZ_OT_default_l_model,IGZ_OT_import_web_json,IGZ_OT_add_drawer_bank,IGZ_OT_remove_drawer_bank,
    IGZ_OT_preview,IGZ_OT_validate_model,IGZ_OT_export_price_library,
    IGZ_OT_import_price_library,IGZ_OT_unify_prices,IGZ_OT_view_boq,
    IGZ_OT_export_boq,IGZ_OT_export_boq_excel,IGZ_PT_panel)


def _initial_preview():
    try:
        scene=bpy.context.scene
        if scene and hasattr(scene,'igz_cabinet') and hasattr(scene,'igz_wall'):
            refresh_preview_now()
    except Exception as exc:
        print('Integrazo Cabinet startup preview:', exc)
    return None

def register():
    for cls in CLASSES: bpy.utils.register_class(cls)
    bpy.types.Scene.igz_cabinet=PointerProperty(type=IGZCabinetSettings)
    bpy.types.Scene.igz_wall=PointerProperty(type=IGZCabinetSettings)
    bpy.types.Scene.igz_price_library=PointerProperty(type=IGZPriceLibrary)
    bpy.types.Scene.igz_kitchen_price_override=PointerProperty(type=IGZPriceLibrary)
    bpy.types.Scene.igz_wall_price_override=PointerProperty(type=IGZPriceLibrary)
    # Defer viewport object creation until Blender has a valid active scene.
    if not bpy.app.background and not bpy.app.timers.is_registered(_initial_preview):
        bpy.app.timers.register(_initial_preview, first_interval=1.0)


def unregister():
    global _TIMER_PENDING
    if bpy.app.timers.is_registered(_timer): bpy.app.timers.unregister(_timer)
    if bpy.app.timers.is_registered(_initial_preview): bpy.app.timers.unregister(_initial_preview)
    _TIMER_PENDING=False
    for key in ('igz_wall_price_override','igz_kitchen_price_override','igz_price_library'):
        if hasattr(bpy.types.Scene,key): delattr(bpy.types.Scene,key)
    if hasattr(bpy.types.Scene,'igz_wall'): del bpy.types.Scene.igz_wall
    if hasattr(bpy.types.Scene,'igz_cabinet'): del bpy.types.Scene.igz_cabinet
    for cls in reversed(CLASSES): bpy.utils.unregister_class(cls)

if __name__=='__main__':
    try: unregister()
    except Exception: pass
    register()
